/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import { deepEquals } from './deep-compare.js';

export const webext = self.browser;

// WKWebExtension lazily creates its storage databases. Concurrent first-use
// operations can race that creation on Safari and fail with an "unknown error";
// treating a failed read as an empty store can then overwrite valid settings.
// Keep one serialization/retry primitive here so the Safari realm workaround
// and all higher-level storage helpers share the same per-area queue.
const isSafari = webext.runtime.getURL('').startsWith('safari-web-extension:');
const safariStorageOperationTails = new Map();
export const safariLocalStorageSentinelKey = '__floorpSafariStorageSentinel';
let safariLocalStorageReady = false;

async function retrySafariStorageOperation(operation) {
    let lastError;
    for ( let attempt = 0; attempt < 5; attempt++ ) {
        try {
            return await operation();
        } catch(reason) {
            lastError = reason;
            const message = reason instanceof Error ? reason.message : `${reason}`;
            if ( /unknown error/i.test(message) === false || attempt === 4 ) {
                break;
            }
            await new Promise(resolve => {
                setTimeout(resolve, 50 * (2 ** attempt));
            });
        }
    }
    throw lastError;
}

async function ensureSafariLocalStorage() {
    if ( safariLocalStorageReady ) { return; }
    await retrySafariStorageOperation(( ) =>
        webext.storage.local.set({ [safariLocalStorageSentinelKey]: true })
    );
    safariLocalStorageReady = true;
}

export function runStorageOperation(areaName, operation) {
    if ( isSafari === false ) { return operation(); }
    const before = safariStorageOperationTails.get(areaName) || Promise.resolve();
    const current = before
        .catch(( ) => undefined)
        .then(async ( ) => {
            if ( areaName === 'local' ) {
                await ensureSafariLocalStorage();
            }
            return retrySafariStorageOperation(operation);
        });
    safariStorageOperationTails.set(areaName, current.catch(( ) => undefined));
    return current;
}

/******************************************************************************/

// Workaround for:
// https://github.com/uBlockOrigin/uBOL-home/issues/515
// https://bugs.webkit.org/show_bug.cgi?id=300236
//
// For each realm, we will force-reload registered rulesets once.

const { windows } = webext;
const  NORMAL_REALM = 0b01;
const PRIVATE_REALM = 0b10;
const ALL_REALMS = NORMAL_REALM | PRIVATE_REALM;

let seenRealms = 0b00;
let seenRealmsReady = runStorageOperation('session', ( ) =>
    webext.storage.session.get('safari.seenRealms')
).then(bin => {
    seenRealms |= bin?.['safari.seenRealms'] ?? 0;
});

async function resolveRealm(windowId) {
    if ( windowId === windows.WINDOW_ID_NONE ) { return 0; }
    let details;
    try {
        details = await windows.get(windowId, { windowTypes: [ 'normal' ] });
    } catch(reason) {
        let openWindows;
        try {
            openWindows = await windows.getAll({ windowTypes: [ 'normal' ] });
        } catch {
            throw reason;
        }
        if ( openWindows.some(window => window.id === windowId) ) {
            throw reason;
        }
        return 0;
    }
    const incognito = details?.incognito;
    if ( typeof incognito !== 'boolean' ) { return 0; }
    return incognito ? PRIVATE_REALM : NORMAL_REALM;
}

function compareIds(a, b) {
    if ( a.length !== b.length ) { return false; }
    const compare = (left, right) => left < right ? -1 : left > right ? 1 : 0;
    const left = a.slice().sort(compare);
    const right = b.slice().sort(compare);
    return left.every((id, index) => id === right[index]);
}

export function readNativeEnabledRulesets(
    api = nativeDNR,
    runtimeAPI = webext.runtime
) {
    return new Promise((resolve, reject) => {
        api.getEnabledRulesets(ids => {
            const lastError = runtimeAPI.lastError;
            if ( lastError ) {
                reject(new Error(lastError.message || `${lastError}`));
                return;
            }
            if ( Array.isArray(ids) === false ) {
                reject(new Error('Invalid enabled static DNR readback'));
                return;
            }
            resolve(ids);
        });
    });
}

async function forceEnableRulesets(currentRealm) {
    await seenRealmsReady;
    if ( seenRealms === ALL_REALMS ) { return false; }
    if ( currentRealm === 0 ) { return false; }
    if ( (seenRealms & currentRealm) !== 0 ) { return false; }
    const ids = await readNativeEnabledRulesets();
    if ( ids.length !== 0 ) {
        await nativeDNR.updateEnabledRulesets({
            disableRulesetIds: ids.slice(),
            enableRulesetIds: ids.slice(),
        });
        const confirmedIds = await readNativeEnabledRulesets();
        if ( compareIds(confirmedIds, ids) === false ) {
            throw new Error('Realm static DNR refresh readback mismatch');
        }
    }
    const nextSeenRealms = seenRealms | currentRealm;
    // Persist completion only after WebKit accepted the native DNR toggle.
    // If either step is interrupted, the next wake safely repeats the toggle.
    await runStorageOperation('session', ( ) =>
        webext.storage.session.set({ 'safari.seenRealms': nextSeenRealms })
    );
    seenRealms = nextSeenRealms;
    return true;
}

let realmRulesetUpdates = Promise.resolve();
let realmRulesetUpdateError;
let realmRulesetStartupError;
let isRealmRulesetStartupPending = true;
let releaseStartupGate;
const startupGate = new Promise(resolve => {
    releaseStartupGate = resolve;
});

export function releaseRealmRulesetStartupGate() {
    releaseStartupGate?.();
    releaseStartupGate = undefined;
}

windows.onFocusChanged.addListener(windowId => {
    const realmResolution = resolveRealm(windowId).then(
        currentRealm => ({ succeeded: true, currentRealm }),
        error => ({ succeeded: false, error })
    );
    const operation = realmRulesetUpdates
        .then(( ) => startupGate)
        .then(async ( ) => {
            const resolution = await realmResolution;
            if ( resolution.succeeded === false ) { throw resolution.error; }
            return forceEnableRulesets(resolution.currentRealm);
        });
    realmRulesetUpdates = operation.then(
        ( ) => { realmRulesetUpdateError = undefined; },
        reason => {
            realmRulesetUpdateError = reason;
            if ( isRealmRulesetStartupPending ) {
                realmRulesetStartupError ??= reason;
            }
        }
    );
});

export async function waitForRealmRulesetUpdates() {
    await seenRealmsReady;
    await startupGate;
    for (;;) {
        const pending = realmRulesetUpdates;
        await pending;
        if ( pending === realmRulesetUpdates ) { break; }
    }
    if ( isRealmRulesetStartupPending ) {
        isRealmRulesetStartupPending = false;
        if ( realmRulesetStartupError !== undefined ) {
            throw realmRulesetStartupError;
        }
    }
    if ( realmRulesetUpdateError !== undefined ) {
        throw realmRulesetUpdateError;
    }
}

export function resetSafariRealmReadiness() {
    seenRealms = 0b00;
    seenRealmsReady = Promise.resolve();
    realmRulesetUpdateError = undefined;
    realmRulesetStartupError = undefined;
}

/******************************************************************************/

// https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/declarativeNetRequest/

const nativeDNR = webext.declarativeNetRequest;

async function restoreEnabledRulesets(snapshot) {
    const current = new Set(await readNativeEnabledRulesets());
    const before = new Set(snapshot);
    const enableRulesetIds = snapshot.filter(id => current.has(id) === false);
    const disableRulesetIds = Array.from(current).filter(id => before.has(id) === false);
    if ( enableRulesetIds.length === 0 && disableRulesetIds.length === 0 ) {
        return;
    }
    await nativeDNR.updateEnabledRulesets({
        enableRulesetIds,
        disableRulesetIds,
    });
    const confirmed = await readNativeEnabledRulesets();
    if ( compareIds(confirmed, snapshot) === false ) {
        throw new Error('Static ruleset rollback readback mismatch');
    }
}

async function updateEnabledRulesetsAndResetRealms(options) {
    await seenRealmsReady;
    const rulesetSnapshot = await readNativeEnabledRulesets();
    const expectedRulesets = new Set(rulesetSnapshot);
    for ( const id of options.enableRulesetIds || [] ) {
        expectedRulesets.add(id);
    }
    for ( const id of options.disableRulesetIds || [] ) {
        expectedRulesets.delete(id);
    }
    const seenRealmsSnapshot = seenRealms;
    try {
        seenRealms = 0b00;
        await runStorageOperation('session', ( ) =>
            webext.storage.session.remove('safari.seenRealms')
        );
        // Invalidate the durable realm completion marker before mutating the
        // static rules. An eviction at either boundary can then only cause a
        // harmless extra realm refresh, never a skipped refresh for new rules.
        await nativeDNR.updateEnabledRulesets(options);
        const confirmedRulesets = await readNativeEnabledRulesets();
        if ( compareIds(confirmedRulesets, Array.from(expectedRulesets)) === false ) {
            throw new Error('Static ruleset update readback mismatch');
        }
    } catch(reason) {
        const rollbackErrors = [];
        try {
            await restoreEnabledRulesets(rulesetSnapshot);
        } catch(rollbackReason) {
            rollbackErrors.push(rollbackReason);
        }
        seenRealms = seenRealmsSnapshot;
        try {
            await runStorageOperation('session', ( ) => seenRealmsSnapshot === 0
                ? webext.storage.session.remove('safari.seenRealms')
                : webext.storage.session.set({
                    'safari.seenRealms': seenRealmsSnapshot,
                })
            );
        } catch(rollbackReason) {
            rollbackErrors.push(rollbackReason);
        }
        if ( rollbackErrors.length !== 0 ) {
            throw new AggregateError(
                [ reason, ...rollbackErrors ],
                'Static ruleset update and rollback both failed'
            );
        }
        throw reason;
    }
}

const isSupportedRule = r => {
    if ( r.action.responseHeaders ) { return false; }
    if ( r.action.requestHeaders ) { return false; }
    const { condition } = r;
    if ( condition.tabIds !== undefined ) { return false; }
    if ( condition.resourceTypes?.includes('object') ) {
        if ( condition.resourceTypes.length === 1 ) { return false; }
        const i = condition.resourceTypes.indexOf('object');
        condition.resourceTypes.splice(i, 1);
    }
    if ( condition.excludedResourceTypes?.includes('object') ) {
        const i = condition.excludedResourceTypes.indexOf('object');
        condition.excludedResourceTypes.splice(i, 1);
        if ( condition.excludedResourceTypes.length === 0 ) {
            delete condition.excludedResourceTypes;
        }
    }
    return true;
};

const prepareUpdateRules = optionsBefore => {
    const { addRules, removeRuleIds } = optionsBefore;
    const addRulesAfter = Array.isArray(addRules)
        ? structuredClone(addRules).filter(isSupportedRule)
        : undefined;
    if ( Boolean(addRulesAfter?.length || removeRuleIds?.length) === false ) { return; }
    addRulesAfter?.forEach(r => {
        if ( r.action?.redirect?.regexSubstitution ) {
            if ( r.condition?.requestDomains ) {
                r.condition.domains = r.condition.requestDomains;
                delete r.condition.requestDomains;
                return;
            }
        }
        if ( r.condition?.initiatorDomains ) {
            r.condition.domains = r.condition.initiatorDomains;
            delete r.condition.initiatorDomains;
        }
        if ( r.condition?.excludedInitiatorDomains ) {
            r.condition.excludedDomains = r.condition.excludedInitiatorDomains;
            delete r.condition.excludedInitiatorDomains;
        }
    });
    const optionsAfter = {};
    if ( addRulesAfter?.length ) { optionsAfter.addRules = addRulesAfter; }
    if ( removeRuleIds?.length ) { optionsAfter.removeRuleIds = removeRuleIds; }
    return optionsAfter;
};

/******************************************************************************/

export function normalizeDNRRules(rules, ruleIds) {
    if ( Array.isArray(rules) === false ) { return rules; }
    const selectedRules = Array.isArray(ruleIds)
        ? rules.filter(rule => ruleIds.includes(rule.id))
        : rules;
    selectedRules.forEach(rule => {
        const { condition } = rule;
        if ( Array.isArray(condition.domains) ) {
            condition.initiatorDomains = condition.domains;
            delete condition.domains;
        }
        if ( Array.isArray(condition.excludedDomains) ) {
            condition.excludedInitiatorDomains = condition.excludedDomains;
            delete condition.excludedDomains;
        }
    });
    return selectedRules;
}

/******************************************************************************/

export const dnr = {
    DYNAMIC_RULESET_ID: '_dynamic',
    MAX_NUMBER_OF_ENABLED_STATIC_RULESETS: nativeDNR.MAX_NUMBER_OF_ENABLED_STATIC_RULESETS,
    MAX_NUMBER_OF_REGEX_RULES: nativeDNR.MAX_NUMBER_OF_DYNAMIC_AND_SESSION_RULES,
    async getAvailableStaticRuleCount() {
        return 150000;
    },
    getDynamicRules({ ruleIds } = {}) {
        return new Promise((resolve, reject) => {
            nativeDNR.getDynamicRules(rules => {
                const lastError = webext.runtime.lastError;
                if ( lastError ) {
                    reject(new Error(lastError.message || `${lastError}`));
                    return;
                }
                if ( Array.isArray(rules) === false ) {
                    reject(new Error('Invalid dynamic DNR readback'));
                    return;
                }
                return resolve(normalizeDNRRules(rules, ruleIds));
            });
        });
    },
    getEnabledRulesets() {
        return readNativeEnabledRulesets();
    },
    getMatchedRules(...args) {
        return nativeDNR.getMatchedRules(...args);
    },
    getSessionRules({ ruleIds } = {}) {
        return new Promise((resolve, reject) => {
            nativeDNR.getSessionRules(rules => {
                const lastError = webext.runtime.lastError;
                if ( lastError ) {
                    reject(new Error(lastError.message || `${lastError}`));
                    return;
                }
                if ( Array.isArray(rules) === false ) {
                    reject(new Error('Invalid session DNR readback'));
                    return;
                }
                return resolve(normalizeDNRRules(rules, ruleIds));
            });
        });
    },
    isRegexSupported(...args) {
        return nativeDNR.isRegexSupported(...args);
    },
    async updateDynamicRules(optionsBefore) {
        const optionsAfter = prepareUpdateRules(optionsBefore);
        if ( optionsAfter === undefined ) { return; }
        return nativeDNR.updateDynamicRules(optionsAfter);
    },
    async updateEnabledRulesets(...args) {
        return updateEnabledRulesetsAndResetRealms(...args);
    },
    async updateSessionRules(optionsBefore) {
        const optionsAfter = prepareUpdateRules(optionsBefore);
        if ( optionsAfter === undefined ) { return; }
        return nativeDNR.updateSessionRules(optionsAfter);
    },
    async setAllowAllRules(
        id,
        allowed,
        notAllowed,
        reverse,
        priority,
        throwOnError = false
    ) {
        const beforeRules = await this.getDynamicRules({ ruleIds: [ id+0 ] });
        const addRules = [];
        if ( reverse || allowed.length || notAllowed.length ) {
            const rule0 = {
                id: id+0,
                action: { type: 'allow' },
                condition: { urlFilter: '*' },
                priority,
            };
            if ( allowed.length ) {
                rule0.condition.domains = allowed;
            } else if ( notAllowed.length ) {
                rule0.condition.excludedDomains = notAllowed;
            }
            addRules.push(rule0);
        }
        if ( deepEquals(addRules, beforeRules) ) { return false; }
        try {
            await this.updateDynamicRules({
                addRules,
                removeRuleIds: beforeRules.map(r => r.id),
            });
            const confirmed = await this.getDynamicRules({ ruleIds: [ id+0 ] });
            if ( deepEquals(addRules, confirmed) === false ) {
                throw new Error('Filtering-mode DNR readback mismatch');
            }
            return true;
        } catch(reason) {
            if ( throwOnError ) { throw reason; }
            return false;
        }
    },
    setExtensionActionOptions(...args) {
        return nativeDNR.setExtensionActionOptions(...args);
    },
};
