/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import { deepEquals } from './deep-compare.js';
import { normalizeSafariDNRRules } from './safari-dnr-normalizer.js';

export { normalizeSafariDNRRules };

export const webext = self.browser;

// WKWebExtension lazily creates its storage databases. Concurrent first-use
// operations can race that creation on Safari and fail with an "unknown error";
// treating a failed read as an empty store can then overwrite valid settings.
// Keep one serialization/retry primitive here so the Safari realm workaround
// and all higher-level storage helpers share the same per-area queue.
const isSafari = webext.runtime.getURL('').startsWith('safari-web-extension:');
const safariStorageOperationTails = new Map();
export const safariLocalStorageSentinelKey = '__floorpSafariStorageSentinel';
let safariLocalStorageReady = false;

async function retrySafariStorageOperation(operation) {
    let lastError;
    for ( let attempt = 0; attempt < 5; attempt++ ) {
        try {
            return await operation();
        } catch(reason) {
            lastError = reason;
            const message = reason instanceof Error ? reason.message : `${reason}`;
            if ( /unknown error/i.test(message) === false || attempt === 4 ) {
                break;
            }
            await new Promise(resolve => {
                setTimeout(resolve, 50 * (2 ** attempt));
            });
        }
    }
    throw lastError;
}

async function ensureSafariLocalStorage() {
    if ( safariLocalStorageReady ) { return; }
    await retrySafariStorageOperation(( ) =>
        webext.storage.local.set({ [safariLocalStorageSentinelKey]: true })
    );
    safariLocalStorageReady = true;
}

export function runStorageOperation(areaName, operation) {
    if ( isSafari === false ) { return operation(); }
    const before = safariStorageOperationTails.get(areaName) || Promise.resolve();
    const current = before
        .catch(( ) => undefined)
        .then(async ( ) => {
            if ( areaName === 'local' ) {
                await ensureSafariLocalStorage();
            }
            return retrySafariStorageOperation(operation);
        });
    safariStorageOperationTails.set(areaName, current.catch(( ) => undefined));
    return current;
}

/******************************************************************************/

const nativeDNR = webext.declarativeNetRequest;
const safariDNROperationLockName = 'floorp.ubol.safari-dnr.v1';
let safariDNROperationTail = Promise.resolve();

const nativeDynamicAndSessionRuleLimit =
    nativeDNR.MAX_NUMBER_OF_DYNAMIC_AND_SESSION_RULES;
export const safariDNRKeeperRuleCount = 2;
export const safariDNRPublicRuleLimit = isSafari
    ? Math.max(0, nativeDynamicAndSessionRuleLimit - safariDNRKeeperRuleCount)
    : nativeDynamicAndSessionRuleLimit;
export const safariDNRPublicRuleLimitPerStore = isSafari
    ? Math.max(0, Math.floor(nativeDynamicAndSessionRuleLimit / 2) - 1)
    : nativeDynamicAndSessionRuleLimit;
const safariDNRQuotaErrorPattern =
    /maximum number of dynamic and session rules exceeded/i;

// Upstream-managed IDs end below 5M; trusted directives start at 8M and user
// rules at 9M. Reserve the otherwise unused gap without entering either band.
export const safariDNRKeeperRuleId = 7000000;
const safariDNRKeeperRule = {
    id: safariDNRKeeperRuleId,
    priority: 1,
    action: { type: 'block' },
    condition: {
        urlFilter: '|https://floorp.invalid/.well-known/ubol-dnr-keeper|',
        resourceTypes: [ 'xmlhttprequest' ],
    },
};

function runLocalSafariDNROperation(operation) {
    const current = safariDNROperationTail
        .catch(( ) => undefined)
        .then(operation);
    safariDNROperationTail = current.catch(( ) => undefined);
    return current;
}

export function runSafariDNROperation(operation) {
    if ( isSafari === false ) { return operation(); }
    const lockManager = self.navigator?.locks;
    if ( typeof lockManager?.request === 'function' ) {
        return lockManager.request(
            safariDNROperationLockName,
            { mode: 'exclusive' },
            operation
        );
    }
    return runLocalSafariDNROperation(operation);
}

function getNativeDynamicRules(...args) {
    return nativeDNR.getDynamicRules(...args);
}

function readNativeDynamicRules() {
    return new Promise((resolve, reject) => {
        getNativeDynamicRules(rules => {
            const lastError = webext.runtime.lastError;
            if ( lastError ) {
                reject(new Error(lastError.message || `${lastError}`));
                return;
            }
            if ( Array.isArray(rules) === false ) {
                reject(new Error('Invalid dynamic DNR readback'));
                return;
            }
            resolve(rules);
        });
    });
}

function getNativeSessionRules(...args) {
    return nativeDNR.getSessionRules(...args);
}

function readNativeSessionRules() {
    return new Promise((resolve, reject) => {
        getNativeSessionRules(rules => {
            const lastError = webext.runtime.lastError;
            if ( lastError ) {
                reject(new Error(lastError.message || `${lastError}`));
                return;
            }
            if ( Array.isArray(rules) === false ) {
                reject(new Error('Invalid session DNR readback'));
                return;
            }
            resolve(rules);
        });
    });
}

function updateNativeDynamicRules(options) {
    return nativeDNR.updateDynamicRules(options);
}

function updateNativeSessionRules(options) {
    return nativeDNR.updateSessionRules(options);
}

function getNativeEnabledRulesets(...args) {
    return nativeDNR.getEnabledRulesets(...args);
}

function updateNativeEnabledRulesets(...args) {
    return nativeDNR.updateEnabledRulesets(...args);
}

function assertSafariDNRKeeperRule(rule, storageType) {
    if ( deepEquals(rule, safariDNRKeeperRule) ) { return; }
    throw new Error(`Safari ${storageType} DNR keeper rule ID collision`);
}

function rulesForSafariDNRStorage(stores, storageType) {
    return storageType === 'dynamic' ? stores.dynamic : stores.session;
}

function otherSafariDNRStorageType(storageType) {
    return storageType === 'dynamic' ? 'session' : 'dynamic';
}

function readNativeDNRStores() {
    return readNativeDynamicRules().then(async dynamic => ({
        dynamic,
        session: await readNativeSessionRules(),
    }));
}

function findSafariDNRKeeper(rules, storageType) {
    const keeper = rules.find(rule => rule.id === safariDNRKeeperRuleId);
    if ( keeper !== undefined ) {
        assertSafariDNRKeeperRule(keeper, storageType);
    }
    return keeper;
}

function isSafariDNRKeeperCapacityBlocked(storageType, stores) {
    if ( Number.isSafeInteger(nativeDynamicAndSessionRuleLimit) === false ) {
        return false;
    }
    const targetRules = rulesForSafariDNRStorage(stores, storageType);
    const otherRules = rulesForSafariDNRStorage(
        stores,
        otherSafariDNRStorageType(storageType)
    );
    // Released WebKit uses the documented shared final-count check. Some
    // Safari 26 builds instead compare current+final counts for the target
    // store. Suppress a quota error only when the exact native readback proves
    // that at least one of those known checks has no room for the keeper.
    const nextTargetCount = targetRules.length + 1;
    return nextTargetCount + otherRules.length > nativeDynamicAndSessionRuleLimit ||
        targetRules.length + nextTargetCount > nativeDynamicAndSessionRuleLimit;
}

function isConfirmedSafariDNRCapacityBlock(reason, storageType, stores) {
    const message = reason instanceof Error ? reason.message : `${reason}`;
    return safariDNRQuotaErrorPattern.test(message) &&
        isSafariDNRKeeperCapacityBlocked(storageType, stores);
}

async function ensureSafariDNRKeeper(storageType) {
    if ( isSafari === false ) { return; }
    const updateRules = storageType === 'dynamic'
        ? updateNativeDynamicRules
        : updateNativeSessionRules;
    let stores = await readNativeDNRStores();
    let rules = rulesForSafariDNRStorage(stores, storageType);
    let keeper = findSafariDNRKeeper(rules, storageType);
    if ( keeper !== undefined ) {
        return true;
    }
    if ( isSafariDNRKeeperCapacityBlocked(storageType, stores) ) {
        throw new Error(
            'Maximum number of dynamic and session rules exceeded'
        );
    }
    try {
        await updateRules({ addRules: [ structuredClone(safariDNRKeeperRule) ] });
    } catch(reason) {
        stores = await readNativeDNRStores();
        rules = rulesForSafariDNRStorage(stores, storageType);
        keeper = findSafariDNRKeeper(rules, storageType);
        if ( keeper === undefined ) { throw reason; }
        return true;
    }
    stores = await readNativeDNRStores();
    rules = rulesForSafariDNRStorage(stores, storageType);
    keeper = findSafariDNRKeeper(rules, storageType);
    if ( keeper === undefined ) {
        throw new Error(`Safari ${storageType} DNR keeper rule was not retained`);
    }
    return true;
}

async function ensureSafariDNRKeeperWithCapacityDeferral(storageType) {
    try {
        return await ensureSafariDNRKeeper(storageType);
    } catch(reason) {
        const stores = await readNativeDNRStores();
        const rules = rulesForSafariDNRStorage(stores, storageType);
        if ( findSafariDNRKeeper(rules, storageType) !== undefined ) {
            return true;
        }
        if ( isConfirmedSafariDNRCapacityBlock(reason, storageType, stores) ) {
            return false;
        }
        throw reason;
    }
}

async function ensureSafariDNRKeepers({ allowCapacityDeferral = false } = {}) {
    const ensure = allowCapacityDeferral
        ? ensureSafariDNRKeeperWithCapacityDeferral
        : ensureSafariDNRKeeper;
    const dynamic = await ensure('dynamic');
    const session = await ensure('session');
    return dynamic !== false && session !== false;
}

function assertNoSafariDNRKeeperCollision(options) {
    if ( isSafari === false ) { return; }
    if ( options.removeRuleIds?.includes(safariDNRKeeperRuleId) ) {
        throw new Error('Safari DNR keeper rule cannot be removed');
    }
    if ( options.addRules?.some(rule => rule?.id === safariDNRKeeperRuleId) ) {
        throw new Error('Safari DNR keeper rule ID is reserved');
    }
}

function projectSafariDNRUpdate(rules, options) {
    const removeRuleIds = new Set(options.removeRuleIds || []);
    const retainedRules = rules.filter(rule => removeRuleIds.has(rule.id) === false);
    const nextRules = retainedRules.slice();
    const nextRuleIds = new Set(nextRules.map(rule => rule.id));
    for ( const rule of options.addRules || [] ) {
        if ( nextRuleIds.has(rule.id) ) {
            throw new Error(`Duplicate Safari DNR rule ID ${rule.id}`);
        }
        nextRuleIds.add(rule.id);
        nextRules.push(rule);
    }
    return { nextRules, retainedRules };
}

function safariDNRCapacityError(storageType) {
    return new Error(
        `Safari DNR capacity reserves ${safariDNRKeeperRuleCount} hidden ` +
        `keeper slots; at most ${safariDNRPublicRuleLimit} public dynamic and ` +
        'session rules can be installed in total, and at most ' +
        `${safariDNRPublicRuleLimitPerStore} public ${storageType} rules can ` +
        'be installed in one store'
    );
}

async function updateSafariDNRRules(storageType, options) {
    await ensureSafariDNRKeepers({ allowCapacityDeferral: true });
    if ( options === undefined ) { return; }
    if (
        (options.addRules?.length || 0) === 0 &&
        (options.removeRuleIds?.length || 0) === 0
    ) {
        return;
    }

    const stores = await readNativeDNRStores();
    const otherStorageType = otherSafariDNRStorageType(storageType);
    const targetRules = rulesForSafariDNRStorage(stores, storageType);
    const otherRules = rulesForSafariDNRStorage(stores, otherStorageType);
    const targetKeeper = findSafariDNRKeeper(targetRules, storageType);
    findSafariDNRKeeper(otherRules, otherStorageType);
    const visibleTargetRules = targetRules.filter(
        rule => rule.id !== safariDNRKeeperRuleId
    );
    const visibleOtherRules = otherRules.filter(
        rule => rule.id !== safariDNRKeeperRuleId
    );
    const projection = projectSafariDNRUpdate(visibleTargetRules, options);
    const projectedTargetPublicRuleCount = projection.nextRules.length;
    const projectedPublicRuleCount =
        projectedTargetPublicRuleCount + visibleOtherRules.length;
    const isPureReduction = options.addRules === undefined &&
        projectedTargetPublicRuleCount < visibleTargetRules.length;
    const hasDeletionAnchor = targetKeeper !== undefined ||
        projection.retainedRules.length !== 0;

    // Safari 26's C++ port checks currentTarget + finalTarget against the
    // documented shared limit. Keeping each public store at floor(limit/2)-1
    // leaves one keeper in both terms, so every replacement/removal accepted
    // by this facade also passes that native check. Legacy stores above the
    // boundary must make a sufficiently large explicit reduction in one
    // atomic update; never let a doomed update reach native storage.
    if ( projectedTargetPublicRuleCount > safariDNRPublicRuleLimitPerStore ) {
        throw safariDNRCapacityError(storageType);
    }

    if ( projectedPublicRuleCount > safariDNRPublicRuleLimit ) {
        // A legacy/TestFlight store can predate the two-slot reservation. Let
        // an explicit removal drain it in safe stages, but never weaken the
        // requested rule set implicitly or let the native delete phase empty
        // an unguarded database.
        if ( isPureReduction === false || hasDeletionAnchor === false ) {
            throw safariDNRCapacityError(storageType);
        }
        const projectedTargetNativeRuleCount =
            projectedTargetPublicRuleCount + (targetKeeper === undefined ? 0 : 1);
        if (
            targetRules.length + projectedTargetNativeRuleCount >
                nativeDynamicAndSessionRuleLimit ||
            projectedTargetNativeRuleCount + otherRules.length >
                nativeDynamicAndSessionRuleLimit
        ) {
            throw safariDNRCapacityError(storageType);
        }
        return storageType === 'dynamic'
            ? updateNativeDynamicRules(options)
            : updateNativeSessionRules(options);
    }

    if ( targetKeeper === undefined && targetRules.length !== 0 &&
        projection.retainedRules.length === 0 ) {
        throw new Error(
            `Safari ${storageType} DNR capacity migration cannot delete the ` +
            'last unguarded rule; free capacity in a non-empty store first'
        );
    }

    const optionsWithKeeper = targetKeeper === undefined
        ? {
            ...options,
            addRules: [
                ...(options.addRules || []),
                structuredClone(safariDNRKeeperRule),
            ],
        }
        : options;
    const projectedTargetNativeRuleCount = projectedTargetPublicRuleCount + 1;
    if (
        targetRules.length + projectedTargetNativeRuleCount >
            nativeDynamicAndSessionRuleLimit ||
        projectedTargetNativeRuleCount + otherRules.length >
            nativeDynamicAndSessionRuleLimit
    ) {
        throw safariDNRCapacityError(storageType);
    }
    const result = storageType === 'dynamic'
        ? await updateNativeDynamicRules(optionsWithKeeper)
        : await updateNativeSessionRules(optionsWithKeeper);
    const confirmedStores = await readNativeDNRStores();
    const confirmedTargetRules = rulesForSafariDNRStorage(
        confirmedStores,
        storageType
    );
    const confirmedKeeper = findSafariDNRKeeper(
        confirmedTargetRules,
        storageType
    );
    if ( confirmedKeeper === undefined ) {
        throw new Error(`Safari ${storageType} DNR keeper rule was not retained`);
    }
    await ensureSafariDNRKeepers({ allowCapacityDeferral: true });
    return result;
}

/******************************************************************************/

// Workaround for:
// https://github.com/uBlockOrigin/uBOL-home/issues/515
// https://bugs.webkit.org/show_bug.cgi?id=300236
//
// For each realm, we will force-reload registered rulesets once.

const { windows } = webext;
const  NORMAL_REALM = 0b01;
const PRIVATE_REALM = 0b10;
const ALL_REALMS = NORMAL_REALM | PRIVATE_REALM;

let seenRealms = 0b00;
let seenRealmsReady = runStorageOperation('session', ( ) =>
    webext.storage.session.get('safari.seenRealms')
).then(bin => {
    seenRealms |= bin?.['safari.seenRealms'] ?? 0;
});

async function resolveRealm(windowId) {
    if ( windowId === windows.WINDOW_ID_NONE ) { return 0; }
    let details;
    try {
        details = await windows.get(windowId, { windowTypes: [ 'normal' ] });
    } catch(reason) {
        let openWindows;
        try {
            openWindows = await windows.getAll({ windowTypes: [ 'normal' ] });
        } catch {
            throw reason;
        }
        if ( openWindows.some(window => window.id === windowId) ) {
            throw reason;
        }
        return 0;
    }
    const incognito = details?.incognito;
    if ( typeof incognito !== 'boolean' ) { return 0; }
    return incognito ? PRIVATE_REALM : NORMAL_REALM;
}

function compareIds(a, b) {
    if ( a.length !== b.length ) { return false; }
    const compare = (left, right) => left < right ? -1 : left > right ? 1 : 0;
    const left = a.slice().sort(compare);
    const right = b.slice().sort(compare);
    return left.every((id, index) => id === right[index]);
}

function readNativeEnabledRulesetsNow(
    api = nativeDNR,
    runtimeAPI = webext.runtime
) {
    return new Promise((resolve, reject) => {
        const getEnabledRulesets = api === nativeDNR
            ? getNativeEnabledRulesets
            : api.getEnabledRulesets.bind(api);
        getEnabledRulesets(ids => {
            const lastError = runtimeAPI.lastError;
            if ( lastError ) {
                reject(new Error(lastError.message || `${lastError}`));
                return;
            }
            if ( Array.isArray(ids) === false ) {
                reject(new Error('Invalid enabled static DNR readback'));
                return;
            }
            resolve(ids);
        });
    });
}

export function readNativeEnabledRulesets(
    api = nativeDNR,
    runtimeAPI = webext.runtime
) {
    const operation = ( ) => readNativeEnabledRulesetsNow(api, runtimeAPI);
    if ( api !== nativeDNR ) { return operation(); }
    return runSafariDNROperation(operation);
}

async function forceEnableRulesets(currentRealm) {
    await seenRealmsReady;
    if ( seenRealms === ALL_REALMS ) { return false; }
    if ( currentRealm === 0 ) { return false; }
    if ( (seenRealms & currentRealm) !== 0 ) { return false; }
    await runSafariDNROperation(async ( ) => {
        await ensureSafariDNRKeepers({ allowCapacityDeferral: true });
        const ids = await readNativeEnabledRulesetsNow();
        if ( ids.length !== 0 ) {
            await updateNativeEnabledRulesets({
                disableRulesetIds: ids.slice(),
                enableRulesetIds: ids.slice(),
            });
            const confirmedIds = await readNativeEnabledRulesetsNow();
            if ( compareIds(confirmedIds, ids) === false ) {
                throw new Error('Realm static DNR refresh readback mismatch');
            }
        }
    });
    const nextSeenRealms = seenRealms | currentRealm;
    // Persist completion only after WebKit accepted the native DNR toggle.
    // If either step is interrupted, the next wake safely repeats the toggle.
    await runStorageOperation('session', ( ) =>
        webext.storage.session.set({ 'safari.seenRealms': nextSeenRealms })
    );
    seenRealms = nextSeenRealms;
    return true;
}

let realmRulesetUpdates = Promise.resolve();
let realmRulesetUpdateError;
let realmRulesetStartupError;
let isRealmRulesetStartupPending = true;
let releaseStartupGate;
const startupGate = new Promise(resolve => {
    releaseStartupGate = resolve;
});

export function releaseRealmRulesetStartupGate() {
    releaseStartupGate?.();
    releaseStartupGate = undefined;
}

windows.onFocusChanged.addListener(windowId => {
    const realmResolution = resolveRealm(windowId).then(
        currentRealm => ({ succeeded: true, currentRealm }),
        error => ({ succeeded: false, error })
    );
    const operation = realmRulesetUpdates
        .then(( ) => startupGate)
        .then(async ( ) => {
            const resolution = await realmResolution;
            if ( resolution.succeeded === false ) { throw resolution.error; }
            return forceEnableRulesets(resolution.currentRealm);
        });
    realmRulesetUpdates = operation.then(
        ( ) => { realmRulesetUpdateError = undefined; },
        reason => {
            realmRulesetUpdateError = reason;
            if ( isRealmRulesetStartupPending ) {
                realmRulesetStartupError ??= reason;
            }
        }
    );
});

export async function waitForRealmRulesetUpdates() {
    await seenRealmsReady;
    await startupGate;
    for (;;) {
        const pending = realmRulesetUpdates;
        await pending;
        if ( pending === realmRulesetUpdates ) { break; }
    }
    if ( isRealmRulesetStartupPending ) {
        isRealmRulesetStartupPending = false;
        if ( realmRulesetStartupError !== undefined ) {
            throw realmRulesetStartupError;
        }
    }
    if ( realmRulesetUpdateError !== undefined ) {
        throw realmRulesetUpdateError;
    }
}

export function resetSafariRealmReadiness() {
    seenRealms = 0b00;
    seenRealmsReady = Promise.resolve();
    realmRulesetUpdateError = undefined;
    realmRulesetStartupError = undefined;
}

/******************************************************************************/

// https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/declarativeNetRequest/

async function restoreEnabledRulesets(snapshot) {
    const current = new Set(await readNativeEnabledRulesetsNow());
    const before = new Set(snapshot);
    const enableRulesetIds = snapshot.filter(id => current.has(id) === false);
    const disableRulesetIds = Array.from(current).filter(id => before.has(id) === false);
    if ( enableRulesetIds.length === 0 && disableRulesetIds.length === 0 ) {
        return;
    }
    await updateNativeEnabledRulesets({
        enableRulesetIds,
        disableRulesetIds,
    });
    const confirmed = await readNativeEnabledRulesetsNow();
    if ( compareIds(confirmed, snapshot) === false ) {
        throw new Error('Static ruleset rollback readback mismatch');
    }
}

async function updateEnabledRulesetsAndResetRealms(options) {
    await seenRealmsReady;
    return runSafariDNROperation(async ( ) => {
        // Static ruleset changes do not delete dynamic/session SQLite rows.
        // A legacy store at capacity may therefore defer its missing keepers
        // while still allowing the independent static update to complete.
        await ensureSafariDNRKeepers({ allowCapacityDeferral: true });
        const rulesetSnapshot = await readNativeEnabledRulesetsNow();
        const expectedRulesets = new Set(rulesetSnapshot);
        for ( const id of options.enableRulesetIds || [] ) {
            expectedRulesets.add(id);
        }
        for ( const id of options.disableRulesetIds || [] ) {
            expectedRulesets.delete(id);
        }
        const seenRealmsSnapshot = seenRealms;
        try {
            seenRealms = 0b00;
            await runStorageOperation('session', ( ) =>
                webext.storage.session.remove('safari.seenRealms')
            );
            // Invalidate the durable realm completion marker before mutating the
            // static rules. An eviction at either boundary can then only cause a
            // harmless extra realm refresh, never a skipped refresh for new rules.
            await updateNativeEnabledRulesets(options);
            const confirmedRulesets = await readNativeEnabledRulesetsNow();
            if ( compareIds(confirmedRulesets, Array.from(expectedRulesets)) === false ) {
                throw new Error('Static ruleset update readback mismatch');
            }
        } catch(reason) {
            const rollbackErrors = [];
            try {
                await restoreEnabledRulesets(rulesetSnapshot);
            } catch(rollbackReason) {
                rollbackErrors.push(rollbackReason);
            }
            seenRealms = seenRealmsSnapshot;
            try {
                await runStorageOperation('session', ( ) => seenRealmsSnapshot === 0
                    ? webext.storage.session.remove('safari.seenRealms')
                    : webext.storage.session.set({
                        'safari.seenRealms': seenRealmsSnapshot,
                    })
                );
            } catch(rollbackReason) {
                rollbackErrors.push(rollbackReason);
            }
            if ( rollbackErrors.length !== 0 ) {
                throw new AggregateError(
                    [ reason, ...rollbackErrors ],
                    'Static ruleset update and rollback both failed'
                );
            }
            throw reason;
        }
    });
}

const prepareUpdateRules = optionsBefore => {
    assertNoSafariDNRKeeperCollision(optionsBefore);
    const { addRules, removeRuleIds } = optionsBefore;
    const addRulesAfter = Array.isArray(addRules)
        ? normalizeSafariDNRRules(addRules)
        : undefined;
    if ( Boolean(addRulesAfter?.length || removeRuleIds?.length) === false ) { return; }
    // Safari 26 implements the standard initiator-domain keys, including the
    // included+excluded combination. Legacy domains/excludedDomains cannot
    // represent that combination because WebKit prefers domains and ignores
    // excludedDomains when both aliases are present.
    const optionsAfter = {};
    if ( addRulesAfter?.length ) { optionsAfter.addRules = addRulesAfter; }
    if ( removeRuleIds?.length ) { optionsAfter.removeRuleIds = removeRuleIds; }
    return optionsAfter;
};

/******************************************************************************/

export function normalizeDNRRules(rules, ruleIds) {
    if ( Array.isArray(rules) === false ) { return rules; }
    const selectedRules = Array.isArray(ruleIds)
        ? rules.filter(rule => ruleIds.includes(rule.id))
        : rules;
    selectedRules.forEach(rule => {
        const { condition } = rule;
        if ( Array.isArray(condition.domains) ) {
            condition.initiatorDomains = condition.domains;
            delete condition.domains;
        }
        if ( Array.isArray(condition.excludedDomains) ) {
            condition.excludedInitiatorDomains = condition.excludedDomains;
            delete condition.excludedDomains;
        }
    });
    return selectedRules;
}

/******************************************************************************/

export const dnr = {
    DYNAMIC_RULESET_ID: '_dynamic',
    MAX_NUMBER_OF_ENABLED_STATIC_RULESETS: nativeDNR.MAX_NUMBER_OF_ENABLED_STATIC_RULESETS,
    MAX_NUMBER_OF_REGEX_RULES: isSafari
        ? safariDNRPublicRuleLimitPerStore
        : nativeDNR.MAX_NUMBER_OF_DYNAMIC_AND_SESSION_RULES,
    async getAvailableStaticRuleCount() {
        return 150000;
    },
    getDynamicRules(...args) {
        if ( isSafari === false ) {
            return getNativeDynamicRules(...args);
        }
        const { ruleIds } = args[0] || {};
        return (async ( ) => {
            const rules = await runSafariDNROperation(async ( ) => {
                await ensureSafariDNRKeeperWithCapacityDeferral('dynamic');
                return readNativeDynamicRules();
            });
            const visibleRules = rules.filter(
                rule => rule.id !== safariDNRKeeperRuleId
            );
            return normalizeDNRRules(visibleRules, ruleIds);
        })();
    },
    getEnabledRulesets(...args) {
        if ( isSafari === false ) {
            return getNativeEnabledRulesets(...args);
        }
        return readNativeEnabledRulesets();
    },
    getMatchedRules(...args) {
        if ( isSafari === false ) {
            return nativeDNR.getMatchedRules(...args);
        }
        return (async ( ) => {
            const result = await runSafariDNROperation(( ) =>
                nativeDNR.getMatchedRules(...args)
            );
            if ( Array.isArray(result?.rulesMatchedInfo) === false ) {
                return result;
            }
            return {
                ...result,
                rulesMatchedInfo: result.rulesMatchedInfo.filter(info =>
                    info?.rule?.ruleId !== safariDNRKeeperRuleId
                ),
            };
        })();
    },
    getSessionRules(...args) {
        if ( isSafari === false ) {
            return getNativeSessionRules(...args);
        }
        const { ruleIds } = args[0] || {};
        return (async ( ) => {
            const rules = await runSafariDNROperation(async ( ) => {
                await ensureSafariDNRKeeperWithCapacityDeferral('session');
                return readNativeSessionRules();
            });
            const visibleRules = rules.filter(
                rule => rule.id !== safariDNRKeeperRuleId
            );
            return normalizeDNRRules(visibleRules, ruleIds);
        })();
    },
    isRegexSupported(...args) {
        return nativeDNR.isRegexSupported(...args);
    },
    updateDynamicRules(optionsBefore) {
        if ( isSafari === false ) {
            return updateNativeDynamicRules(optionsBefore);
        }
        return runSafariDNROperation(( ) => {
            const optionsAfter = prepareUpdateRules(optionsBefore);
            return updateSafariDNRRules('dynamic', optionsAfter);
        });
    },
    updateEnabledRulesets(...args) {
        if ( isSafari === false ) {
            return updateNativeEnabledRulesets(...args);
        }
        return updateEnabledRulesetsAndResetRealms(...args);
    },
    updateSessionRules(optionsBefore) {
        if ( isSafari === false ) {
            return updateNativeSessionRules(optionsBefore);
        }
        return runSafariDNROperation(( ) => {
            const optionsAfter = prepareUpdateRules(optionsBefore);
            return updateSafariDNRRules('session', optionsAfter);
        });
    },
    async setAllowAllRules(
        id,
        allowed,
        notAllowed,
        reverse,
        priority,
        throwOnError = false
    ) {
        const beforeRules = await this.getDynamicRules({ ruleIds: [ id+0 ] });
        const addRules = [];
        if ( reverse || allowed.length || notAllowed.length ) {
            const rule0 = {
                id: id+0,
                action: { type: 'allow' },
                condition: { urlFilter: '*' },
                priority,
            };
            if ( allowed.length ) {
                rule0.condition.initiatorDomains = allowed;
            } else if ( notAllowed.length ) {
                rule0.condition.excludedInitiatorDomains = notAllowed;
            }
            addRules.push(rule0);
        }
        if ( deepEquals(addRules, beforeRules) ) { return false; }
        try {
            await this.updateDynamicRules({
                addRules,
                removeRuleIds: beforeRules.map(r => r.id),
            });
            const confirmed = await this.getDynamicRules({ ruleIds: [ id+0 ] });
            if ( deepEquals(addRules, confirmed) === false ) {
                throw new Error('Filtering-mode DNR readback mismatch');
            }
            return true;
        } catch(reason) {
            if ( throwOnError ) { throw reason; }
            return false;
        }
    },
    setExtensionActionOptions(...args) {
        return nativeDNR.setExtensionActionOptions(...args);
    },
};
