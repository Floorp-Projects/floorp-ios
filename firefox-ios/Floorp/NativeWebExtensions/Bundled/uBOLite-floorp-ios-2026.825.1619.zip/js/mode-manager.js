/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import {
    broadcastMessage,
    hostnamesFromMatches,
    isDescendantHostnameOfIter,
    toBroaderHostname,
} from './utils.js';

import {
    browser,
    localRead, localRemove, localWrite,
    sessionRead, sessionWrite,
} from './ext.js';

import {
    rulesetConfig,
    saveRulesetConfig,
} from './config.js';

import { adminReadEx } from './admin.js';
import { filteringModesToDNR } from './ruleset-manager.js';
import { hasBroadHostPermissions } from './ext-utils.js';


/******************************************************************************/

// 0:       no filtering
// 1:    basic filtering
// 2:  optimal filtering
// 3: complete filtering

export const     MODE_NONE = 0;
export const    MODE_BASIC = 1;
export const  MODE_OPTIMAL = 2;
export const MODE_COMPLETE = 3;

export const defaultFilteringModes = {
    none: [],
    basic: [],
    optimal: [ 'all-urls' ],
    complete: [],
};

/******************************************************************************/

const pruneDescendantHostnamesFromSet = (hostname, hnSet) => {
    for ( const hn of hnSet ) {
        if ( hn.endsWith(hostname) === false ) { continue; }
        if ( hn === hostname ) { continue; }
        if ( hn.at(-hostname.length-1) !== '.' ) { continue; }
        hnSet.delete(hn);
    }
};

const pruneHostnameFromSet = (hostname, hnSet) => {
    let hn = hostname;
    for (;;) {
        hnSet.delete(hn);
        hn = toBroaderHostname(hn);
        if ( hn === '*' ) { break; }
    }
};

/******************************************************************************/

const serializeModeDetails = details => {
    return {
        none: Array.from(details.none),
        basic: Array.from(details.basic),
        optimal: Array.from(details.optimal),
        complete: Array.from(details.complete),
    };
};

const unserializeModeDetails = details => {
    return {
        none: new Set(details.none),
        basic: new Set(details.basic ?? details.network),
        optimal: new Set(details.optimal ?? details.extendedSpecific),
        complete: new Set(details.complete ?? details.extendedGeneric),
    };
};

function lookupFilteringMode(filteringModes, hostname) {
    const { none, basic, optimal, complete } = filteringModes;
    if ( hostname === 'all-urls' ) {
        if ( filteringModes.none.has('all-urls') ) { return MODE_NONE; }
        if ( filteringModes.basic.has('all-urls') ) { return MODE_BASIC; }
        if ( filteringModes.optimal.has('all-urls') ) { return MODE_OPTIMAL; }
        if ( filteringModes.complete.has('all-urls') ) { return MODE_COMPLETE; }
        return MODE_BASIC;
    }
    if ( none.has(hostname) ) { return MODE_NONE; }
    if ( none.has('all-urls') === false ) {
        if ( isDescendantHostnameOfIter(hostname, none) ) { return MODE_NONE; }
    }
    if ( basic.has(hostname) ) { return MODE_BASIC; }
    if ( basic.has('all-urls') === false ) {
        if ( isDescendantHostnameOfIter(hostname, basic) ) { return MODE_BASIC; }
    }
    if ( optimal.has(hostname) ) { return MODE_OPTIMAL; }
    if ( optimal.has('all-urls') === false ) {
        if ( isDescendantHostnameOfIter(hostname, optimal) ) { return MODE_OPTIMAL; }
    }
    if ( complete.has(hostname) ) { return MODE_COMPLETE; }
    if ( complete.has('all-urls') === false ) {
        if ( isDescendantHostnameOfIter(hostname, complete) ) { return MODE_COMPLETE; }
    }
    return lookupFilteringMode(filteringModes, 'all-urls');
}

function applyFilteringMode(filteringModes, hostname, afterLevel) {
    const defaultLevel = lookupFilteringMode(filteringModes, 'all-urls');
    if ( hostname === 'all-urls' ) {
        if ( afterLevel === defaultLevel ) { return afterLevel; }
        switch ( afterLevel ) {
        case MODE_NONE:
            filteringModes.none.clear();
            filteringModes.none.add('all-urls');
            break;
        case MODE_BASIC:
            filteringModes.basic.clear();
            filteringModes.basic.add('all-urls');
            break;
        case MODE_OPTIMAL:
            filteringModes.optimal.clear();
            filteringModes.optimal.add('all-urls');
            break;
        case MODE_COMPLETE:
            filteringModes.complete.clear();
            filteringModes.complete.add('all-urls');
            break;
        }
        switch ( defaultLevel ) {
        case MODE_NONE:
            filteringModes.none.delete('all-urls');
            break;
        case MODE_BASIC:
            filteringModes.basic.delete('all-urls');
            break;
        case MODE_OPTIMAL:
            filteringModes.optimal.delete('all-urls');
            break;
        case MODE_COMPLETE:
            filteringModes.complete.delete('all-urls');
            break;
        }
        return lookupFilteringMode(filteringModes, 'all-urls');
    }
    const beforeLevel = lookupFilteringMode(filteringModes, hostname);
    if ( afterLevel === beforeLevel ) { return afterLevel; }
    const { none, basic, optimal, complete } = filteringModes;
    switch ( beforeLevel ) {
    case MODE_NONE:
        pruneHostnameFromSet(hostname, none);
        break;
    case MODE_BASIC:
        pruneHostnameFromSet(hostname, basic);
        break;
    case MODE_OPTIMAL:
        pruneHostnameFromSet(hostname, optimal);
        break;
    case MODE_COMPLETE:
        pruneHostnameFromSet(hostname, complete);
        break;
    }
    if ( afterLevel !== defaultLevel ) {
        switch ( afterLevel ) {
        case MODE_NONE:
            if ( isDescendantHostnameOfIter(hostname, none) === false ) {
                filteringModes.none.add(hostname);
                pruneDescendantHostnamesFromSet(hostname, none);
            }
            break;
        case MODE_BASIC:
            if ( isDescendantHostnameOfIter(hostname, basic) === false ) {
                filteringModes.basic.add(hostname);
                pruneDescendantHostnamesFromSet(hostname, basic);
            }
            break;
        case MODE_OPTIMAL:
            if ( isDescendantHostnameOfIter(hostname, optimal) === false ) {
                filteringModes.optimal.add(hostname);
                pruneDescendantHostnamesFromSet(hostname, optimal);
            }
            break;
        case MODE_COMPLETE:
            if ( isDescendantHostnameOfIter(hostname, complete) === false ) {
                filteringModes.complete.add(hostname);
                pruneDescendantHostnamesFromSet(hostname, complete);
            }
            break;
        }
    }
    return lookupFilteringMode(filteringModes, hostname);
}

/******************************************************************************/

export async function readFilteringModeDetails(
    bypassCache = false,
    startupFresh = false
) {
    if ( bypassCache === false && startupFresh === false ) {
        if ( readFilteringModeDetails.cache ) {
            return readFilteringModeDetails.cache;
        }
        const sessionModes = await sessionRead('filteringModeDetails');
        if ( sessionModes instanceof Object ) {
            readFilteringModeDetails.cache = unserializeModeDetails(sessionModes);
            return readFilteringModeDetails.cache;
        }
    }
    let [
        userModes = structuredClone(defaultFilteringModes),
        adminDefaultFiltering,
        adminNoFiltering,
    ] = await Promise.all([
        localRead('filteringModeDetails'),
        adminReadEx('defaultFiltering', startupFresh),
        adminReadEx('noFiltering', startupFresh),
    ]);
    userModes = unserializeModeDetails(userModes);
    if ( adminDefaultFiltering !== undefined ) {
        const modefromName = {
            none: MODE_NONE,
            basic: MODE_BASIC,
            optimal: MODE_OPTIMAL,
            complete: MODE_COMPLETE,
        };
        const adminDefaultFilteringMode = modefromName[adminDefaultFiltering];
        if ( adminDefaultFilteringMode !== undefined ) {
            applyFilteringMode(userModes, 'all-urls', adminDefaultFilteringMode);
        }
    }
    if ( Array.isArray(adminNoFiltering) && adminNoFiltering.length !== 0 ) {
        if ( adminNoFiltering.includes('-*') ) {
            userModes.none.clear();
        }
        for ( const hn of adminNoFiltering ) {
            if ( hn.charAt(0) === '-' ) {
                userModes.none.delete(hn.slice(1));
            } else {
                applyFilteringMode(userModes, hn, 0);
            }
        }
    }
    await filteringModesToDNR(userModes, startupFresh);
    await sessionWrite('filteringModeDetails', serializeModeDetails(userModes));
    readFilteringModeDetails.cache = userModes;
    return userModes;
}

/******************************************************************************/

async function writeFilteringModeDetails(afterDetails, throwOnDNRError = false) {
    const data = serializeModeDetails(afterDetails);
    // The durable target is authoritative. If WebKit kills the background
    // between this write and the DNR update, startup reconciliation completes
    // the target before readiness can become true.
    await localWrite('filteringModeDetails', data);
    await filteringModesToDNR(unserializeModeDetails(data), throwOnDNRError);
    try {
        await sessionWrite('filteringModeDetails', data);
    } catch(reason) {
        await sessionRemove('filteringModeDetails').catch(( ) => undefined);
        throw reason;
    }
    readFilteringModeDetails.cache = unserializeModeDetails(data);
    const [ defaultFilteringMode, hasOmnipotence ] = await Promise.all([
        getDefaultFilteringMode(),
        hasBroadHostPermissions(),
    ]);
    broadcastMessage({
        defaultFilteringMode,
        hasOmnipotence,
        filteringModeDetails: readFilteringModeDetails.cache,
    });
}

/******************************************************************************/

export async function getFilteringModeDetails(
    serializable = false,
    startupFresh = false
) {
    const actualDetails = await readFilteringModeDetails(false, startupFresh);
    const out = {
        none: new Set(actualDetails.none),
        basic: new Set(actualDetails.basic),
        optimal: new Set(actualDetails.optimal),
        complete: new Set(actualDetails.complete),
    };
    return serializable ? serializeModeDetails(out) : out;
}

export async function setFilteringModeDetails(details, throwOnDNRError = false) {
    await writeFilteringModeDetails(
        unserializeModeDetails(serializeModeDetails(details)),
        throwOnDNRError
    );
}

/******************************************************************************/

export async function getFilteringMode(hostname, startupFresh = false) {
    const filteringModes = await getFilteringModeDetails(false, startupFresh);
    return lookupFilteringMode(filteringModes, hostname);
}

export async function setFilteringMode(hostname, afterLevel, throwOnDNRError = false) {
    const filteringModes = await getFilteringModeDetails();
    const level = applyFilteringMode(filteringModes, hostname, afterLevel);
    await writeFilteringModeDetails(filteringModes, throwOnDNRError);
    return level;
}

/******************************************************************************/

export function getDefaultFilteringMode(startupFresh = false) {
    return getFilteringMode('all-urls', startupFresh);
}

export function setDefaultFilteringMode(afterLevel, throwOnDNRError = false) {
    return setFilteringMode('all-urls', afterLevel, throwOnDNRError);
}

/******************************************************************************/

export async function persistHostPermissions(iter) {
    if ( iter === undefined ) {
        const permissions = await browser.permissions.getAll();
        iter = hostnamesFromMatches(permissions.origins) || [];
    }
    const hostnames = Array.from(iter);
    return hostnames.length !== 0
        ? localWrite('permissions.hostnames', hostnames)
        : localRemove('permissions.hostnames');
}

/******************************************************************************/

export async function syncWithBrowserPermissions(startupFresh = false) {
    const [
        beforePermissions,
        afterPermissions,
        beforeMode,
    ] = await Promise.all([
        localRead('permissions.hostnames'),
        browser.permissions.getAll(),
        getDefaultFilteringMode(startupFresh),
    ]);
    const beforeAllowedHostnames = new Set(beforePermissions);
    const afterAllowedHostnames = new Set(hostnamesFromMatches(afterPermissions.origins || []));
    await persistHostPermissions(afterAllowedHostnames);
    const hasBroadHostPermissions = afterAllowedHostnames.has('all-urls');
    const broadHostPermissionsToggled =
        hasBroadHostPermissions !== rulesetConfig.hasBroadHostPermissions;
    let modified = false;
    if ( beforeMode > MODE_BASIC && hasBroadHostPermissions === false ) {
        await setDefaultFilteringMode(MODE_BASIC, startupFresh);
        modified = true;
    } else if ( beforeMode === MODE_BASIC && hasBroadHostPermissions && broadHostPermissionsToggled ) {
        await setDefaultFilteringMode(MODE_OPTIMAL, startupFresh);
        modified = true;
    }
    if ( broadHostPermissionsToggled ) {
        rulesetConfig.hasBroadHostPermissions = hasBroadHostPermissions;
        await saveRulesetConfig();
    }
    const afterMode = await getDefaultFilteringMode();
    if ( afterMode > MODE_BASIC ) { return afterMode !== beforeMode; }
    const filteringModes = await getFilteringModeDetails();
    if ( afterAllowedHostnames.has('all-urls') === false ) {
        const { none, basic, optimal, complete } = filteringModes;
        for ( const hn of new Set([ ...optimal, ...complete ]) ) {
            if ( afterAllowedHostnames.has(hn) ) { continue; }
            if ( isDescendantHostnameOfIter(hn, afterAllowedHostnames) ) { continue; }
            applyFilteringMode(filteringModes, hn, afterMode);
            modified = true;
        }
        for ( const hn of afterAllowedHostnames ) {
            if ( beforeAllowedHostnames.has(hn) ) { continue; }
            if ( optimal.has(hn) || complete.has(hn) ) { continue; }
            if ( basic.has(hn) || none.has(hn) ) { continue; }
            applyFilteringMode(filteringModes, hn, MODE_OPTIMAL);
            modified = true;
        }
        if ( modified ) {
            await writeFilteringModeDetails(filteringModes, startupFresh);
        }
    }
    return modified;
}

/******************************************************************************/
