/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2014-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import { dom, qs$, qsa$ } from './dom.js';
import { hashFromIterable, nodeFromTemplate } from './dashboard.js';
import { i18n, i18n$ } from './i18n.js';
import {
    localRead,
    localWrite,
    sendMessage,
    settleOptionsOperations,
    trackOptionsOperation,
} from './ext.js';
import { reconcileProtection } from './floorp-reconcile.js';

/******************************************************************************/

const rulesetMap = new Map();
const visuallyEnabledRulesets = new Set();

let hideUnusedSet = new Set([ 'ads', 'regions', 'imported' ]);

/******************************************************************************/

function renderNumber(value) {
    return value.toLocaleString();
}

/******************************************************************************/

function renderTotalRuleCounts() {
    let rulesetCount = 0;
    let filterCount = 0;
    let ruleCount = 0;
    for ( const listEntry of qsa$('#lists .listEntry[data-role="leaf"][data-rulesetid]') ) {
        if ( qs$(listEntry, 'input[type="checkbox"]:checked') === null ) { continue; }
        if ( listEntry.dataset.imported === undefined ) {
            rulesetCount += 1;
        }
        const stats = rulesetStats(listEntry.dataset.rulesetid);
        if ( stats === undefined ) { continue; }
        ruleCount += stats.ruleCount;
        filterCount += stats.filterCount;
    }
    dom.text('#listsOfBlockedHostsPrompt', i18n$('perRulesetStats')
        .replace('{{ruleCount}}', renderNumber(ruleCount))
        .replace('{{filterCount}}', renderNumber(filterCount))
    );

    dom.cl.toggle(dom.body, 'noMoreRuleset',
        rulesetCount === self.cachedRulesetData.maxNumberOfEnabledRulesets
    );
}

/******************************************************************************/

function updateNodes(listEntries) {
    listEntries = listEntries || qs$('#lists');
    const sublistSelector = '.listEntry[data-rulesetid] > .detailbar input';
    const checkedSublistSelector = `${sublistSelector}:checked`;
    const adminSublistSelector = '.listEntry.fromAdmin[data-rulesetid] > .detailbar input';
    for ( const listEntry of qsa$(listEntries, '.listEntry[data-nodeid]') ) {
        const countElem = qs$(listEntry, ':scope > .detailbar .count');
        if ( countElem === null ) { continue; }
        const totalCount = qsa$(listEntry, sublistSelector).length;
        const checkedCount = qsa$(listEntry, checkedSublistSelector).length;
        dom.text(countElem, `${checkedCount}/${totalCount}`);
        const checkboxElem = qs$(listEntry, ':scope > .detailbar .checkbox');
        if ( checkboxElem === null ) { continue; }
        const checkboxInput = qs$(checkboxElem, 'input');
        dom.prop(checkboxInput, 'checked', checkedCount !== 0);
        dom.cl.toggle(checkboxElem, 'partial',
            checkedCount !== 0 && checkedCount !== totalCount
        );
        const adminCount = qsa$(listEntry, adminSublistSelector).length;
        const fromAdmin = adminCount === totalCount;
        dom.cl.toggle(listEntry, 'fromAdmin', fromAdmin);
        dom.attr(checkboxInput, 'disabled', fromAdmin ? '' : null);
    }
}

/******************************************************************************/

function rulesetStats(rulesetId) {
    const rulesetDetails = rulesetMap.get(rulesetId);
    if ( rulesetDetails === undefined ) { return; }
    const { rules, filters } = rulesetDetails;
    const ruleCount = rules.plain + rules.regex;
    const filterCount = filters.accepted;
    return { ruleCount, filterCount };
}

/******************************************************************************/

function isAdminRuleset(listkey) {
    const { adminRulesets = [] } = self.cachedRulesetData;
    for ( const id of adminRulesets ) {
        const pos = id.indexOf(listkey);
        if ( pos === 0 ) { return true; }
        if ( pos !== 1 ) { continue; }
        const c = id.charAt(0);
        if ( c === '+' || c === '-' ) { return true; }
    }
    return false;
}

/******************************************************************************/

export async function renderFilterLists(incremental = false) {
    if ( incremental && renderFilterLists.visible !== true ) { return; }
    renderFilterLists.visible = true;

    const [
        enabledRulesets,
        rulesetDetails,
    ] = await Promise.all([
        sendMessage({ what: 'getEnabledRulesets' }),
        sendMessage({ what: 'getRulesetDetails' }),
    ]);

    self.cachedRulesetData.enabledRulesets = enabledRulesets;
    self.cachedRulesetData.rulesetDetails = rulesetDetails;

    visuallyEnabledRulesets.clear();
    rulesetMap.clear();
    rulesetDetails.forEach(rule => {
        rulesetMap.set(rule.id, rule);
    });

    const listStatsTemplate = i18n$('perRulesetStats');
    const beforeListEntries = new Set(qsa$('#lists .listEntry:not([data-role="root"])'));

    const initializeListEntry = (ruleset, listEntry) => {
        const on = enabledRulesets.includes(ruleset.id);
        if ( on ) {
            visuallyEnabledRulesets.add(ruleset.id);
        }
        if ( dom.cl.has(listEntry, 'toggled') === false ) {
            dom.prop(qs$(listEntry, ':scope > .detailbar input'), 'checked', on);
        }
        if ( ruleset.homeURL ) {
            dom.attr(qs$(listEntry, 'a.support'), 'href', ruleset.homeURL);
        }
        const isImported = ruleset.group === 'imported';
        dom.cl.toggle(listEntry, 'isDefault',
            ruleset.enabled === true && isImported === false
        );
        if ( isImported ) {
            listEntry.dataset.imported = '';
        }
        const stats = rulesetStats(ruleset.id);
        if ( stats === undefined ) { return; }
        listEntry.title = listStatsTemplate
            .replace('{{ruleCount}}', renderNumber(stats.ruleCount))
            .replace('{{filterCount}}', renderNumber(stats.filterCount));
        if ( isImported ) { return; }
        const fromAdmin = isAdminRuleset(ruleset.id);
        dom.cl.toggle(listEntry, 'fromAdmin', fromAdmin);
        dom.attr(
            qs$(listEntry, '.input.checkbox input'),
            'disabled',
            fromAdmin ? '' : null
        );
    };

    const createListEntry = (entryid, listDetails, depth) => {
        if ( listDetails.lists === undefined ) {
            const listEntry = qs$(`[data-role="leaf"][data-rulesetid="${entryid}"]`);
            if ( listEntry !== null ) { return listEntry; }
            return nodeFromTemplate('listEntryLeaf', '.listEntry');
        }
        if ( depth !== 0 ) {
            const listEntry = qs$(`[data-role="node"][data-nodeid="${entryid}"]`);
            if ( listEntry !== null ) { return listEntry; }
            return nodeFromTemplate('listEntryNode', '.listEntry');
        }
        const listEntry = qs$(`[data-role="rootnode"][data-nodeid="${entryid}"]`);
        if ( listEntry !== null ) { return listEntry; }
        return nodeFromTemplate('listEntryRoot', '.listEntry');
    };

    const createListEntries = (parentkey, listTree, depth = 0) => {
        const treeEntries = Object.entries(listTree);
        const listEntries = qs$(`#lists .listEntry[data-nodeid="${parentkey}"] > .listEntries`) ||
            qs$('#lists > .listEntries') ||
            nodeFromTemplate('listEntries', '.listEntries');
        if ( depth !== 0 ) {
            const reEmojis = /\p{Emoji}+/gu;
            treeEntries.sort((a ,b) => {
                const ap = a[1].preferred === true;
                const bp = b[1].preferred === true;
                if ( ap !== bp ) { return ap ? -1 : 1; }
                const as = (a[1].title || a[0]).replace(reEmojis, '');
                const bs = (b[1].title || b[0]).replace(reEmojis, '');
                return as.localeCompare(bs);
            });
        }
        for ( const [ listid, listDetails ] of treeEntries ) {
            const listEntry = createListEntry(listid, listDetails, depth);
            beforeListEntries.delete(listEntry);
            const newEntry = listEntry.parentElement === null;
            if ( listDetails.lists === undefined ) {
                listEntry.dataset.rulesetid = listid;
            } else {
                listEntry.dataset.nodeid = listid;
                dom.cl.toggle(listEntry, 'hideUnused', hideUnusedSet.has(listid));
            }
            if ( newEntry ) {
                qs$(listEntry, ':scope > .detailbar .listname').append(
                    i18n.patchUnicodeFlags(listDetails.name)
                );
            }
            if ( listDetails.lists !== undefined ) {
                const listEntries = createListEntries(listid, listDetails.lists, depth+1)
                if ( listEntries.parentElement === null ) {
                    listEntry.append(listEntries);
                }
            } else {
                initializeListEntry(listDetails, listEntry);
            }
            if ( newEntry ) {
                listEntries.append(listEntry);
            }
        }
        return listEntries;
    };

    // Visually split the filter lists in groups
    const groups = [
        [
            'default',
            rulesetDetails.filter(ruleset =>
                ruleset.group === 'default'
            ),
        ], [
            'ads',
            rulesetDetails.filter(ruleset =>
                ruleset.group === 'ads'
            ),
        ], [
            'privacy',
            rulesetDetails.filter(ruleset =>
                ruleset.group === 'privacy'
            ),
        ], [
            'malware',
            rulesetDetails.filter(ruleset =>
                ruleset.group === 'malware'
            ),
        ], [
            'annoyances',
            rulesetDetails.filter(ruleset =>
                ruleset.group === 'annoyances'
            ),
        ], [
            'misc',
            rulesetDetails.filter(ruleset =>
                ruleset.group === undefined &&
                typeof ruleset.lang !== 'string'
            ),
        ], [
            'regions',
            rulesetDetails.filter(ruleset =>
                ruleset.group === 'regions'
            ),
        ], [
            'imported',
            rulesetDetails.filter(ruleset =>
                ruleset.group === 'imported'
            ),
        ],
    ];

    dom.cl.toggle(dom.body, 'hideUnused', mustHideUnusedLists('*'));

    // Build list tree
    const listTree = {};
    const groupNames = new Map();
    for ( const [ nodeid, rulesets ] of groups ) {
        let name = groupNames.get(nodeid);
        if ( name === undefined ) {
            name = i18n$(`3pGroup${nodeid.charAt(0).toUpperCase()}${nodeid.slice(1)}`);
            groupNames.set(nodeid, name);
        }
        const details = { name, lists: {} };
        listTree[nodeid] = details;
        for ( const ruleset of rulesets ) {
            if ( ruleset.parent !== undefined ) {
                let lists = details.lists;
                for ( const parent of ruleset.parent.split('|') ) {
                    if ( lists[parent] === undefined ) {
                        lists[parent] = { name: parent, lists: {} };
                    }
                    lists = lists[parent].lists;
                }
                lists[ruleset.id] = ruleset;
            } else {
                details.lists[ruleset.id] = ruleset;
            }
        }
    }
    // Replace composite list with only one sublist with sublist itself
    const promoteLonelySublist = (parent, depth = 0) => {
        if ( Boolean(parent.lists) === false ) { return parent; }
        const childKeys = Object.keys(parent.lists);
        for ( const childKey of childKeys ) {
            const child = promoteLonelySublist(parent.lists[childKey], depth + 1);
            if ( child === parent.lists[childKey] ) { continue; }
            parent.lists[child.id] = child;
            delete parent.lists[childKey];
        }
        if ( depth === 0 ) { return parent; }
        if ( childKeys.length > 1 ) { return parent; }
        return parent.lists[childKeys[0]]
    };
    for ( const key of Object.keys(listTree) ) {
        promoteLonelySublist(listTree[key]);
    }
    const listEntries = createListEntries('root', listTree);
    for ( const listEntry of beforeListEntries ) {
        listEntry.remove();
    }

    updateNodes(listEntries);

    if ( listEntries.parentElement === null ) {
        qs$('#lists').append(listEntries);
    }

    renderTotalRuleCounts();
}

/******************************************************************************/

// Collapsing of unused lists.

function mustHideUnusedLists(which) {
    const hideAll = hideUnusedSet.has('*');
    if ( which === '*' ) { return hideAll; }
    return hideUnusedSet.has(which) !== hideAll;
}

function toggleHideUnusedLists(which) {
    const doesHideAll = hideUnusedSet.has('*');
    if ( which === '*' ) {
        const mustHide = doesHideAll === false;
        hideUnusedSet.clear();
        if ( mustHide ) {
            hideUnusedSet.add(which);
        }
        dom.cl.toggle('#lists', 'hideUnused', mustHide);
        dom.cl.toggle('.listEntry[data-nodeid]', 'hideUnused', mustHide);
    } else {
        const doesHide = hideUnusedSet.has(which);
        if ( doesHide ) {
            hideUnusedSet.delete(which);
        } else {
            hideUnusedSet.add(which);
        }
        const mustHide = doesHide === doesHideAll;
        const groupSelector = `.listEntry[data-nodeid="${which}"]`;
        dom.cl.toggle(groupSelector, 'hideUnused', mustHide);
    }

    trackOptionsOperation(
        localWrite('hideUnusedFilterLists', Array.from(hideUnusedSet))
    );
}

// Initialize from saved state.
localRead('hideUnusedFilterLists').then(value => {
    if ( Array.isArray(value) === false ) { return; }
    hideUnusedSet = new Set(value);
    for ( const listEntry of qsa$('[data-nodeid]') ) {
        dom.cl.toggle(listEntry, 'hideUnused',
            hideUnusedSet.has(listEntry.dataset.nodeid)
        );
    }
});

/******************************************************************************/

const searchFilterLists = ( ) => {
    const pattern = dom.prop('#findInLists', 'value') || '';
    dom.cl.toggle('#lists', 'searchMode', pattern !== '');
    if ( pattern === '' ) { return; }
    const re = new RegExp(pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    for ( const listEntry of qsa$('#lists [data-role="leaf"]') ) {
        if ( dom.cl.has(listEntry, 'fromAdmin') ) { continue; }
        const rulesetid = listEntry.dataset.rulesetid;
        const rulesetDetails = rulesetMap.get(rulesetid);
        if ( rulesetDetails === undefined ) { continue; }
        let haystack = perListHaystack.get(rulesetDetails);
        if ( haystack === undefined ) {
            haystack = [
                rulesetDetails.name,
                listEntry.dataset.nodeid,
                rulesetDetails.group || '',
                rulesetDetails.tags || '',
            ].join(' ').trim();
            perListHaystack.set(rulesetDetails, haystack);
        }
        dom.cl.toggle(listEntry, 'searchMatch', re.test(haystack));
    }
    for ( const listEntry of qsa$('#lists .listEntry:not([data-role="leaf"])') ) {
        dom.cl.toggle(listEntry, 'searchMatch',
            qs$(listEntry, '.listEntries .listEntry.searchMatch') !== null
        );
    }
};

const perListHaystack = new WeakMap();

/******************************************************************************/

const applyEnabledRulesets = (( ) => {
    const apply = async (final = false) => {
        dom.cl.add(dom.body, 'committing');
        dom.text('#runtimeError', '');

        try {
            const enabledRulesets = [];
            const rulesetEntries =
                qsa$('#lists [data-role="leaf"][data-rulesetid]');
            for ( const listEntry of rulesetEntries ) {
                const checked = qs$(listEntry, 'input[type="checkbox"]:checked') !== null;
                if ( checked === false ) { continue; }
                const { rulesetid } = listEntry.dataset;
                if ( dom.cl.has(listEntry, 'fromAdmin') ) { continue; }
                enabledRulesets.push(rulesetid);
            }

            dom.cl.remove('#lists .listEntry.toggled', 'toggled');

            const toRemove = Array.from(
                qsa$('#lists [data-role="leaf"][data-rulesetid][data-remove]')
            ).map(a => a.dataset.rulesetid);

            const modified = hashFromIterable(enabledRulesets) !==
                hashFromIterable(visuallyEnabledRulesets) ||
                final && toRemove.length;
            if ( modified || final ) {
                const reconciliation = await reconcileProtection({
                    enabledRulesets,
                });
                if ( reconciliation.ready !== true ) {
                    throw new Error(
                        reconciliation.error ||
                        'Enabled rulesets did not reconcile'
                    );
                }
                // Removing an already-disabled imported list only discards its
                // local metadata. Static/derived protection was reconciled by
                // the foreground extension page above.
                if ( final && toRemove.length !== 0 ) {
                    await sendMessage({
                        what: 'removeDisabledImportedLists',
                        rulesetIds: toRemove,
                    });
                }
            }
            const confirmedRulesets = await sendMessage({
                what: 'getEnabledRulesets',
            });
            const confirmedSet = new Set(confirmedRulesets);
            const mismatch = Array.from(rulesetEntries).some(listEntry => {
                if ( dom.cl.has(listEntry, 'fromAdmin') ) { return false; }
                const { rulesetid } = listEntry.dataset;
                const checked = qs$(
                    listEntry,
                    'input[type="checkbox"]:checked'
                ) !== null;
                return confirmedSet.has(rulesetid) !== checked;
            });
            if ( mismatch ) {
                throw new Error('Enabled rulesets did not match the requested selection');
            }
            visuallyEnabledRulesets.clear();
            confirmedRulesets.forEach(id => visuallyEnabledRulesets.add(id));
            dom.text('#dnrError', '');
            return { ready: true, enabledRulesets: confirmedRulesets };
        } catch(reason) {
            const message = reason instanceof Error ? reason.message : `${reason}`;
            dom.text('#runtimeError', message);
            dom.text('#dnrError', message);
            try {
                await renderFilterLists(true);
            } catch {
            }
            return { ready: false, error: message };
        } finally {
            dom.cl.remove(dom.body, 'committing');
        }
    };

    let timer;
    let revision = 0;
    let completedRevision = 0;
    let completedFinalRevision = 0;
    let lastResult = { ready: true };
    let applyTail = Promise.resolve({ ready: true });

    const enqueue = (final, targetRevision) => {
        const operation = applyTail.then(( ) => apply(final)).catch(reason => {
            const error = reason instanceof Error ? reason.message : `${reason}`;
            dom.text('#runtimeError', error);
            dom.text('#dnrError', error);
            return { ready: false, error };
        });
        applyTail = operation.then(result => {
            if ( targetRevision >= completedRevision ) {
                completedRevision = targetRevision;
                lastResult = result;
            }
            if ( final ) {
                completedFinalRevision = Math.max(
                    completedFinalRevision,
                    targetRevision
                );
            }
            return result;
        });
        return applyTail;
    };

    const clearTimer = ( ) => {
        if ( timer === undefined ) { return; }
        self.clearTimeout(timer);
        timer = undefined;
    };

    const schedule = ( ) => {
        clearTimer();
        revision += 1;
        const targetRevision = revision;
        timer = self.setTimeout(( ) => {
            timer = undefined;
            void enqueue(false, targetRevision);
        }, 997);
    };

    schedule.flush = async ( ) => {
        // The dashboard starts on Settings and defers rendering Filter lists
        // until that pane is shown. Do not interpret an untouched, empty DOM
        // as an explicit request to disable every ruleset when Floorp asks the
        // page to settle before closing.
        if ( revision === 0 ) {
            try {
                const enabledRulesets = await sendMessage({
                    what: 'getEnabledRulesets',
                });
                if ( Array.isArray(enabledRulesets) === false ) {
                    throw new Error('Enabled ruleset readback was invalid');
                }
                return { ready: true, enabledRulesets };
            } catch(reason) {
                const error = reason instanceof Error ? reason.message : `${reason}`;
                dom.text('#runtimeError', error);
                dom.text('#dnrError', error);
                return { ready: false, error };
            }
        }
        for (;;) {
            clearTimer();
            const targetRevision = revision;
            await applyTail;
            const result = await enqueue(true, targetRevision);
            if ( result.ready !== true ) { return result; }
            if ( revision === targetRevision ) { return lastResult; }
        }
    };

    self.addEventListener('beforeunload', ( ) => {
        if ( timer === undefined ) { return; }
        void schedule.flush();
    });

    return schedule;
})();

self.floorpPrepareToClose = async ( ) => {
    try {
        const before = await settleOptionsOperations();
        const rulesets = await applyEnabledRulesets.flush();
        const after = await settleOptionsOperations();
        const reconciliation = rulesets.ready === true
            ? await sendMessage({ what: 'floorpReconcileDashboardState' })
            : { ready: false, error: rulesets.error };
        const readiness = reconciliation.ready === true
            ? await sendMessage({ what: 'floorpReadiness' })
            : { ready: false, error: reconciliation.error };
        const confirmedConfig = readiness.ready === true
            ? await sendMessage({ what: 'getOptionsPageData' })
            : undefined;
        const final = await settleOptionsOperations();
        const failure = [
            before,
            rulesets,
            after,
            reconciliation,
            readiness,
            final,
        ]
            .find(result => result?.ready !== true);
        if ( failure !== undefined ) {
            throw new Error(failure.error || 'Dashboard changes did not settle');
        }
        const configKeys = [
            'autoReload',
            'defaultFilteringMode',
            'developerMode',
            'popupBlockMode',
            'showBlockedCount',
            'strictBlockMode',
        ];
        const configMismatch = configKeys.find(key =>
            self.cachedRulesetData[key] !== undefined &&
            confirmedConfig?.[key] !== self.cachedRulesetData[key]
        );
        if ( configMismatch !== undefined ) {
            throw new Error(`Dashboard setting readback mismatch: ${configMismatch}`);
        }
        return { ready: true, enabledRulesets: rulesets.enabledRulesets };
    } catch(reason) {
        await settleOptionsOperations();
        const error = reason instanceof Error ? reason.message : `${reason}`;
        dom.text('#runtimeError', error);
        dom.text('#dnrError', error);
        return { ready: false, error };
    }
};

/******************************************************************************/

async function importFromInput() {
    const input = qs$('.importRulesetURL input[type="url"]');
    const url = input.value;
    if ( /^[a-z-]+:\/\/(?:\S+\/\S*|\/\S+)/m.test(url) === false ) { return; }
    dom.cl.add(dom.body, 'committing');
    dom.text('#runtimeError', '');
    try {
        await sendMessage({ what: 'importFilterList', url });
        qs$('.importRulesetURL').open = false;
        input.value = '';
    } catch(reason) {
        const message = reason instanceof Error ? reason.message : `${reason}`;
        dom.text('#runtimeError', message);
    } finally {
        dom.cl.remove(dom.body, 'committing');
    }
}

function removeImportedList(ev) {
    const listEntry = ev.target.closest('[data-role="leaf"]');
    dom.cl.add(listEntry, 'toggled');
    const input = qs$(listEntry, 'input[type="checkbox"]');
    listEntry.dataset.remove = JSON.stringify(input.checked);
    input.checked = false;
    input.setAttribute('disabled', '');
    updateNodes();
    renderTotalRuleCounts();
    applyEnabledRulesets();
}

function unremoveImportedList(ev) {
    const listEntry = ev.target.closest('[data-role="leaf"]');
    dom.cl.add(listEntry, 'toggled');
    const input = qs$(listEntry, 'input[type="checkbox"]');
    input.removeAttribute('disabled');
    input.checked = JSON.parse(listEntry.dataset.remove);
    delete listEntry.dataset.remove;
    updateNodes();
    renderTotalRuleCounts();
    applyEnabledRulesets();
}

/******************************************************************************/

async function start() {
    await renderFilterLists();

    dom.on('#findInLists', 'input', searchFilterLists);
    dom.on('#lists', 'click', '.listEntry[data-nodeid] > .detailbar, .listExpander', ev => {
        toggleHideUnusedLists(
            dom.attr(ev.target.closest('[data-nodeid]'), 'data-nodeid')
        );
    });
    dom.on('#lists', 'change', '.listEntry input[type="checkbox"]', ev => {
        const input = ev.target;
        const listEntry = input.closest('.listEntry');
        if ( listEntry === null ) { return; }
        if ( listEntry.dataset.nodeid !== undefined ) {
            const checkAll = input.checked ||
                dom.cl.has(qs$(listEntry, ':scope > .detailbar .checkbox'), 'partial');
            for ( const subListEntry of qsa$(listEntry, ':scope > .listEntries .listEntry[data-rulesetid]') ) {
                dom.cl.add(subListEntry, 'toggled');
                dom.prop(qsa$(subListEntry, ':scope > .detailbar input'), 'checked', checkAll);
            }
        } else {
            dom.cl.add(listEntry, 'toggled');
        }
        updateNodes();
        renderTotalRuleCounts();
        applyEnabledRulesets();
    });
    dom.on('section[data-pane="rulesets"] button:has([data-i18n="addButton"])', 'click',
        ( ) => { importFromInput(); }
    );
    dom.on('#lists', 'click', '[data-role="leaf"][data-imported] .doRemove',
        removeImportedList
    );
    dom.on('#lists', 'click', '[data-role="leaf"][data-imported] .undoRemove',
        unremoveImportedList
    );
}

dom.onFirstShown(start, qs$('section[data-pane="rulesets"]'));
