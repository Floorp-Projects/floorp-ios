/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import {
    browser,
    localKeys,
    localRead,
    localRemove,
    localWrite,
} from './ext.js';

import {
    isScriptlet,
    matchesFromHostnames,
} from './utils.js';

import { ubolErr } from './debug.js';

/******************************************************************************/

const isProcedural = a => a.startsWith('{');
const isCSS = a => isProcedural(a) === false && isScriptlet(a) === false;

export const customFilterMutationJournalKey =
    'floorp.customFilterMutationJournal.v1';
export const settingsRestoreJournalKey = 'floorp.settingsRestoreJournal.v1';
export const customFilterModeStorageKeys = [
    'filteringModeDetails',
    'admin.defaultFiltering',
    'admin.noFiltering',
];

function committedJournalSnapshot(journal, label, phases) {
    if ( journal === undefined ) { return; }
    if (
        typeof journal !== 'object' ||
        journal === null ||
        Array.isArray(journal) ||
        journal.version !== 1 ||
        typeof journal.id !== 'string' ||
        journal.id === '' ||
        phases.includes(journal.phase) === false ||
        typeof journal.beforeLocal !== 'object' ||
        journal.beforeLocal === null ||
        Array.isArray(journal.beforeLocal)
    ) {
        throw new Error(`Invalid ${label} journal`);
    }
    return journal.beforeLocal;
}

export function committedSettingsRestoreSnapshot(journal) {
    return committedJournalSnapshot(journal, 'settings restore', [
        'applying',
        'committingForeground',
        'rollingBack',
    ]);
}

export function committedCustomFilterMutationSnapshot(journal) {
    return committedJournalSnapshot(journal, 'custom-filter mutation', [
        'applying',
        'rollingBack',
    ]);
}

function customFilterMapFromStorageSnapshot(snapshot) {
    if (
        typeof snapshot !== 'object' ||
        snapshot === null ||
        Array.isArray(snapshot)
    ) {
        throw new Error('Invalid custom-filter storage snapshot');
    }
    const out = new Map();
    for ( const [ key, selectors ] of Object.entries(snapshot) ) {
        if ( key.startsWith('site.') === false ) { continue; }
        const hostname = key.slice(5);
        if (
            hostname === '' ||
            Array.isArray(selectors) === false ||
            selectors.some(selector => typeof selector !== 'string')
        ) {
            throw new Error('Invalid custom-filter selector snapshot');
        }
        out.set(hostname, selectors.slice());
    }
    return out;
}

function customFilterStorageSnapshot(entries) {
    return Object.fromEntries(entries.map(([ hostname, selectors ]) => [
        `site.${hostname}`,
        selectors.slice(),
    ]));
}

function serializedModeSets(details) {
    const source = details ?? {
        none: [],
        basic: [],
        optimal: [ 'all-urls' ],
        complete: [],
    };
    if (
        typeof source !== 'object' ||
        source === null ||
        Array.isArray(source)
    ) {
        throw new Error('Invalid filtering-mode storage snapshot');
    }
    const aliases = {
        none: 'none',
        basic: source.basic === undefined ? 'network' : 'basic',
        optimal: source.optimal === undefined
            ? 'extendedSpecific'
            : 'optimal',
        complete: source.complete === undefined
            ? 'extendedGeneric'
            : 'complete',
    };
    const out = {};
    for ( const [ name, sourceName ] of Object.entries(aliases) ) {
        const values = source[sourceName];
        if (
            Array.isArray(values) === false ||
            values.some(value => typeof value !== 'string' || value === '')
        ) {
            throw new Error('Invalid filtering-mode storage snapshot');
        }
        out[name] = new Set(values);
    }
    return out;
}

function broaderHostnameInSet(hostname, set) {
    if ( set.has('*') ) { return true; }
    let hn = hostname;
    for (;;) {
        if ( set.has(hn) ) { return true; }
        const pos = hn.indexOf('.');
        if ( pos === -1 ) { return false; }
        hn = hn.slice(pos + 1);
    }
}

function lookupMode(modes, hostname) {
    if ( hostname === 'all-urls' ) {
        for ( const name of [ 'none', 'basic', 'optimal', 'complete' ] ) {
            if ( modes[name].has('all-urls') ) { return name; }
        }
        return 'basic';
    }
    for ( const name of [ 'none', 'basic', 'optimal', 'complete' ] ) {
        if ( modes[name].has(hostname) ) { return name; }
        if (
            modes[name].has('all-urls') === false &&
            broaderHostnameInSet(hostname, modes[name])
        ) {
            return name;
        }
    }
    return lookupMode(modes, 'all-urls');
}

function pruneDescendants(hostname, set) {
    for ( const candidate of set ) {
        if (
            candidate !== hostname &&
            candidate.endsWith(`.${hostname}`)
        ) {
            set.delete(candidate);
        }
    }
}

function pruneHostname(hostname, set) {
    let hn = hostname;
    for (;;) {
        set.delete(hn);
        const pos = hn.indexOf('.');
        if ( pos === -1 ) { return; }
        hn = hn.slice(pos + 1);
    }
}

function applyMode(modes, hostname, afterMode) {
    const beforeMode = lookupMode(modes, hostname);
    if ( beforeMode === afterMode ) { return; }
    if ( hostname === 'all-urls' ) {
        modes[afterMode].clear();
        modes[afterMode].add('all-urls');
        modes[beforeMode].delete('all-urls');
        return;
    }
    pruneHostname(hostname, modes[beforeMode]);
    if ( afterMode === lookupMode(modes, 'all-urls') ) { return; }
    if ( broaderHostnameInSet(hostname, modes[afterMode]) === false ) {
        modes[afterMode].add(hostname);
        pruneDescendants(hostname, modes[afterMode]);
    }
}

function adminData(snapshot, key) {
    const envelope = snapshot[key];
    if ( envelope === undefined ) { return; }
    if (
        typeof envelope !== 'object' ||
        envelope === null ||
        Array.isArray(envelope)
    ) {
        throw new Error('Invalid administrator filtering-mode snapshot');
    }
    return envelope.data;
}

export function customFilteringEnabledFromStorageSnapshot(snapshot, hostname) {
    if (
        typeof snapshot !== 'object' ||
        snapshot === null ||
        Array.isArray(snapshot) ||
        typeof hostname !== 'string' ||
        hostname === ''
    ) {
        throw new Error('Invalid filtering-mode storage snapshot');
    }
    const modes = serializedModeSets(snapshot.filteringModeDetails);
    const adminDefault = adminData(snapshot, 'admin.defaultFiltering');
    if ([ 'none', 'basic', 'optimal', 'complete' ].includes(adminDefault)) {
        applyMode(modes, 'all-urls', adminDefault);
    }
    const adminNone = adminData(snapshot, 'admin.noFiltering');
    if ( Array.isArray(adminNone) && adminNone.length !== 0 ) {
        if ( adminNone.some(value => typeof value !== 'string') ) {
            throw new Error('Invalid administrator filtering-mode snapshot');
        }
        if ( adminNone.includes('-*') ) { modes.none.clear(); }
        for ( const value of adminNone ) {
            if ( value.startsWith('-') ) {
                modes.none.delete(value.slice(1));
            } else if ( value !== '' ) {
                applyMode(modes, value, 'none');
            }
        }
    }
    return lookupMode(modes, hostname) !== 'none';
}

/******************************************************************************/

async function keysFromStorage() {
    return queueStorageOperation(( ) => localKeys());
}

async function readFromStorage(key) {
    return queueStorageOperation(( ) => localRead(key));
}

async function writeToStorage(key, value) {
    return queueStorageOperation(( ) => localWrite(key, value));
}

async function removeFromStorage(key) {
    return queueStorageOperation(( ) => localRemove(key));
}

let pendingStorageOp = Promise.resolve();

function queueStorageOperation(callback) {
    const operation = pendingStorageOp.then(callback);
    // A failed write must reject its caller without poisoning the serialized
    // tail: an atomic mutation still needs to be able to restore its snapshot.
    pendingStorageOp = operation.catch(( ) => undefined);
    return operation;
}

/******************************************************************************/

export function customFilterStorageKeys(hostname) {
    const out = [];
    let hn = hostname;
    while ( hn !== '' ) {
        out.push(`site.${hn}`);
        const pos = hn.indexOf('.');
        if ( pos === -1 ) { break; }
        hn = hn.slice(pos + 1);
    }
    return out;
}

/******************************************************************************/

export async function customFiltersFromHostname(hostname) {
    const keys = customFilterStorageKeys(hostname);
    const promises = keys.map(key => readFromStorage(key));
    const results = await Promise.all(promises);
    const out = [];
    for ( let i = 0; i < promises.length; i++ ) {
        const selectors = results[i];
        if ( selectors === undefined ) { continue; }
        selectors.forEach(selector => {
            out.push(selector);
        });
    }
    return out.sort();
}

/******************************************************************************/

export function customFiltersFromSnapshot(hostname, snapshot) {
    if (
        typeof snapshot !== 'object' ||
        snapshot === null ||
        Array.isArray(snapshot)
    ) {
        throw new Error('Invalid custom-filter storage snapshot');
    }
    const out = [];
    for ( const key of customFilterStorageKeys(hostname) ) {
        const selectors = snapshot[key];
        if ( selectors !== undefined ) {
            if (
                Array.isArray(selectors) === false ||
                selectors.some(selector => typeof selector !== 'string')
            ) {
                throw new Error('Invalid custom-filter selector snapshot');
            }
            out.push(...selectors);
        }
    }
    return out.sort();
}

/******************************************************************************/

export function assertSuccessfulScriptInjection(results, operation) {
    if ( Array.isArray(results) === false || results.length === 0 ) {
        throw new Error(`${operation} returned no injection results`);
    }
    for ( const result of results ) {
        if ( typeof result !== 'object' || result === null ) {
            throw new Error(`${operation} returned a malformed injection result`);
        }
        if ( result.error !== undefined ) {
            throw new Error(`${operation}: ${result.error}`);
        }
    }
    return results;
}

/******************************************************************************/

export async function hasCustomFilters(hostname) {
    const selectors = await customFiltersFromHostname(hostname);
    return selectors?.length ?? 0;
}

/******************************************************************************/

async function getAllCustomFilterKeys() {
    const storageKeys = await keysFromStorage() || [];
    return storageKeys.filter(a => a.startsWith('site.'));
}

/******************************************************************************/

export async function getAllCustomFilters() {
    const collect = async key => {
        const selectors = await readFromStorage(key);
        return [ key.slice(5), selectors ?? [] ];
    };
    const keys = await getAllCustomFilterKeys();
    const promises = keys.map(k => collect(k));
    return Promise.all(promises);
}

/******************************************************************************/

export function startCustomFilters(tabId, frameId) {
    return browser.scripting.executeScript({
        files: [ '/js/scripting/css-user.js' ],
        target: { tabId, frameIds: [ frameId ] },
        injectImmediately: true,
    }).catch(reason => {
        ubolErr(`startCustomFilters/${reason}`);
    })
}

export function terminateCustomFilters(tabId, frameId) {
    return browser.scripting.executeScript({
        files: [ '/js/scripting/css-user-terminate.js' ],
        target: { tabId, frameIds: [ frameId ] },
        injectImmediately: true,
    }).catch(reason => {
        ubolErr(`terminateCustomFilters/${reason}`);
    })
}

/******************************************************************************/

export async function injectCustomFilters(target, hostname, storageSnapshot) {
    const selectors = storageSnapshot === undefined
        ? await customFiltersFromHostname(hostname)
        : customFiltersFromSnapshot(hostname, storageSnapshot);
    const plainSelectors = selectors.filter(a => isCSS(a));
    if ( plainSelectors.length !== 0 ) {
        await browser.scripting.insertCSS({
            css: `${plainSelectors.join(',\n')}{display:none!important;}`,
            origin: 'USER',
            target,
        });
    }
    const proceduralSelectors = selectors.filter(a => isProcedural(a));
    return { plainSelectors, proceduralSelectors };
}

/******************************************************************************/

export async function registerCustomFilters(context) {
    let customFilters;
    if ( context.localStorageSnapshot === undefined ) {
        customFilters = new Map(await getAllCustomFilters());
    } else {
        const snapshots = [ context.localStorageSnapshot ];
        for ( const [ key, readJournal ] of [
            [ settingsRestoreJournalKey, committedSettingsRestoreSnapshot ],
            [
                customFilterMutationJournalKey,
                committedCustomFilterMutationSnapshot,
            ],
        ] ) {
            const snapshot = readJournal(context.localStorageSnapshot[key]);
            if ( snapshot !== undefined ) { snapshots.push(snapshot); }
        }
        customFilters = new Map();
        for ( const snapshot of snapshots ) {
            for ( const [ hostname, selectors ] of
                customFilterMapFromStorageSnapshot(snapshot) ) {
                const existing = customFilters.get(hostname) || [];
                customFilters.set(
                    hostname,
                    Array.from(new Set([ ...existing, ...selectors ])).sort()
                );
            }
        }
    }
    if ( customFilters.size === 0 ) { return; }

    // Register every stored root and enforce the effective mode when selectors
    // are read. This covers an enabled child inheriting a parent filter under a
    // default-none policy and is safe if Safari briefly retains a broader row.
    const hostnames = Array.from(customFilters.keys()).filter(a =>
        customFilters.get(a).some(a => isCSS(a) || isProcedural(a))
    );
    if ( hostnames.length === 0 ) { return; }

    const js = [ '/js/scripting/css-user.js' ];
    const hasInheritedProceduralFilter = hostname => {
        let hn = hostname;
        while ( hn !== '' ) {
            if ( customFilters.get(hn)?.some(isProcedural) ) { return true; }
            const pos = hn.indexOf('.');
            if ( pos === -1 ) { break; }
            hn = hn.slice(pos + 1);
        }
        return false;
    };
    if ( hostnames.some(hasInheritedProceduralFilter) ) {
        // WebKit does not apply matchOriginAsFallback when executeScript checks
        // access to about:blank/about:srcdoc. Preload the API in css-user's
        // registered isolated world, including filters inherited from a parent
        // hostname. css-user retains a lazy fallback for ordinary web frames.
        js.unshift(
            '/js/scripting/css-api.js',
            '/js/scripting/css-procedural-api.js'
        );
    }
    const directive = {
        id: 'css-user',
        js,
        matches: matchesFromHostnames(hostnames),
        allFrames: true,
        matchOriginAsFallback: true,
        runAt: 'document_start',
    };
    const idleJS = js.slice();
    if ( idleJS.includes('/js/scripting/css-api.js') === false ) {
        idleJS.unshift('/js/scripting/css-api.js');
    }
    idleJS.unshift('/js/scripting/css-user-idle-prelude.js');
    idleJS.splice(idleJS.length - 1, 0, '/js/scripting/css-user-idle.js');
    context.toAdd.push(directive, {
        ...directive,
        id: 'css-user-idle',
        js: idleJS,
        runAt: 'document_idle',
    });
}

/******************************************************************************/

export async function addCustomFilters(hostname, toAdd) {
    if ( hostname === '' ) { return false; }
    const key = `site.${hostname}`;
    const selectors = await readFromStorage(key) || [];
    const countBefore = selectors.length;
    for ( const selector of toAdd ) {
        if ( selectors.includes(selector) ) { continue; }
        selectors.push(selector);
    }
    if ( selectors.length === countBefore ) { return false; }
    selectors.sort();
    await writeToStorage(key, selectors);
    return true;
}

/******************************************************************************/

export async function removeAllCustomFilters(hostname) {
    if ( hostname === '*' ) {
        const keys = await getAllCustomFilterKeys();
        if ( keys.length === 0 ) { return false; }
        for ( const key of keys ) {
            await removeFromStorage(key);
        }
        return true;
    }
    const key = `site.${hostname}`;
    const selectors = await readFromStorage(key) || [];
    await removeFromStorage(key);
    return selectors.length !== 0;
}

export async function removeCustomFilters(hostname, selectors) {
    const promises = [];
    let hn = hostname;
    while ( hn !== '' ) {
        promises.push(removeCustomFiltersByKey(`site.${hn}`, selectors));
        const pos = hn.indexOf('.');
        if ( pos === -1 ) { break; }
        hn = hn.slice(pos + 1);
    }
    const results = await Promise.all(promises);
    return results.some(a => a);
}

async function removeCustomFiltersByKey(key, toRemove) {
    const selectors = await readFromStorage(key);
    if ( selectors === undefined ) { return false; }
    const beforeCount = selectors.length;
    for ( const selector of toRemove ) {
        const i = selectors.indexOf(selector);
        if ( i === -1 ) { continue; }
        selectors.splice(i, 1);
    }
    const afterCount = selectors.length;
    if ( afterCount === beforeCount ) { return false; }
    if ( afterCount !== 0 ) {
        await writeToStorage(key, selectors);
    } else {
        await removeFromStorage(key);
    }
    return true;
}

/******************************************************************************/

async function writeCustomFilterSnapshot(entries) {
    const desired = new Map(entries.map(([ hostname, selectors ]) => [
        hostname,
        Array.from(new Set(selectors)).sort(),
    ]));
    const currentKeys = await getAllCustomFilterKeys();
    for ( const key of currentKeys ) {
        const hostname = key.slice(5);
        if ( desired.has(hostname) ) { continue; }
        await removeFromStorage(key);
    }
    for ( const [ hostname, selectors ] of desired ) {
        const key = `site.${hostname}`;
        if ( selectors.length === 0 ) {
            await removeFromStorage(key);
        } else {
            await writeToStorage(key, selectors);
        }
    }
}

let pendingCustomFilterMutation = Promise.resolve();

function queueCustomFilterMutation(callback) {
    const operation = pendingCustomFilterMutation
        .catch(( ) => undefined)
        .then(callback);
    pendingCustomFilterMutation = operation.catch(( ) => undefined);
    return operation;
}

async function recoverCustomFilterMutationNow() {
    const journal = await readFromStorage(customFilterMutationJournalKey);
    const beforeLocal = committedCustomFilterMutationSnapshot(journal);
    if ( beforeLocal === undefined ) { return false; }
    await writeCustomFilterSnapshot(
        Array.from(customFilterMapFromStorageSnapshot(beforeLocal))
    );
    await removeFromStorage(customFilterMutationJournalKey);
    return true;
}

export function recoverCustomFilterMutation() {
    return queueCustomFilterMutation(recoverCustomFilterMutationNow);
}

async function runCustomFilterMutation(
    mutation,
    applyRegistrations,
    rollbackFailureMessage
) {
    await recoverCustomFilterMutationNow();
    const snapshot = await getAllCustomFilters();
    const id = globalThis.crypto?.randomUUID?.() ||
        `${Date.now()}-${Math.random()}`;
    const journal = {
        version: 1,
        id,
        phase: 'applying',
        beforeLocal: customFilterStorageSnapshot(snapshot),
    };
    await writeToStorage(customFilterMutationJournalKey, journal);
    try {
        const modified = await mutation(snapshot);
        if ( modified === false ) {
            await removeFromStorage(customFilterMutationJournalKey);
            return false;
        }
        // While the journal exists registration is the union of last-committed
        // and live roots, while selector reads remain pinned to last-committed.
        await applyRegistrations();
        await removeFromStorage(customFilterMutationJournalKey);
        // Extra rows are functionally safe because every selector read is mode
        // gated. Narrow them promptly, but do not roll back a published change
        // merely because Safari rejected this redundant cleanup attempt.
        await applyRegistrations().catch(reason => {
            ubolErr(`narrowCustomFilterRegistrations/${reason}`);
        });
        return modified;
    } catch(reason) {
        try {
            await writeToStorage(customFilterMutationJournalKey, {
                ...journal,
                phase: 'rollingBack',
            });
            await writeCustomFilterSnapshot(snapshot);
            await applyRegistrations();
            await removeFromStorage(customFilterMutationJournalKey);
            await applyRegistrations().catch(narrowReason => {
                ubolErr(`narrowCustomFilterRegistrations/${narrowReason}`);
            });
        } catch(rollbackReason) {
            throw new AggregateError(
                [ reason, rollbackReason ],
                rollbackFailureMessage
            );
        }
        throw reason;
    }
}

function replaceCustomFilterData(entries, before, after) {
    const output = new Map(entries.map(([ hostname, selectors ]) => [
        hostname,
        Array.from(new Set(selectors)),
    ]));
    const beforeSelectors = output.get(before.hostname) || [];
    const toRemove = new Set(before.selectors);
    const remaining = beforeSelectors.filter(selector => !toRemove.has(selector));
    if ( remaining.length === 0 ) {
        output.delete(before.hostname);
    } else {
        output.set(before.hostname, remaining);
    }
    const afterSelectors = output.get(after.hostname) || [];
    for ( const selector of after.selectors ) {
        if ( afterSelectors.includes(selector) ) { continue; }
        afterSelectors.push(selector);
    }
    if ( afterSelectors.length !== 0 ) {
        output.set(after.hostname, afterSelectors);
    }
    return Array.from(output);
}

export async function replaceCustomFiltersAtomically(
    before,
    after,
    applyRegistrations
) {
    return queueCustomFilterMutation(( ) => runCustomFilterMutation(
        async snapshot => {
            const replacement = replaceCustomFilterData(
                snapshot,
                before,
                after
            );
            if ( JSON.stringify(snapshot) === JSON.stringify(replacement) ) {
                return false;
            }
            await writeCustomFilterSnapshot(replacement);
            return true;
        },
        applyRegistrations,
        'Custom-filter mutation and rollback both failed'
    ));
}

export async function mutateCustomFiltersAtomically(
    mutation,
    applyRegistrations
) {
    return queueCustomFilterMutation(( ) => runCustomFilterMutation(
        async ( ) => await mutation() === true,
        applyRegistrations,
        'Custom-filter mutation and rollback both failed'
    ));
}

export async function replaceAllCustomFiltersAtomically(
    replacement,
    applyRegistrations
) {
    return queueCustomFilterMutation(( ) => runCustomFilterMutation(
        async ( ) => {
            await writeCustomFilterSnapshot(replacement);
            return true;
        },
        applyRegistrations,
        'Custom-filter replacement and rollback both failed'
    ));
}

/******************************************************************************/

export function getSandboxFilters() {
    return localRead('sandboxFilters');
}

export function setSandboxFilters(text = '') {
    text = text.trim();
    return text !== ''
        ? localWrite('sandboxFilters', text)
        : localRemove('sandboxFilters')
}
