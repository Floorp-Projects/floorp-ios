'use strict';

// Run before the API files in the document_idle registration. WebKit can
// preserve their isolated-world document identity across the transient
// about:blank -> final about:srcdoc commit, so origin-fallback documents must
// rebuild those APIs even when their normal identity guards still match.
self.floorpCSSUserAPIIdleReplay = document.location.hostname === '';
