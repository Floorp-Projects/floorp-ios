'use strict';

// Do not infer Document identity from location, documentElement, or timeOrigin:
// WebKit can preserve any of those across an origin-fallback commit, while
// pushState and root replacement can change them within one Document. css-user
// performs a request-bound sender.documentId handshake after the guarded API
// files run and forces a rebuild only when that immutable ID changed.
self.floorpCSSUserAPIIdleReplay = true;
