/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

var floorpCSSUserTermination = (async function uBOL_cssUserTerminate() {

/******************************************************************************/

const generation = self.cssUserDocumentGeneration;
const startHandler = self.cssUserStartHandler;
const filterer = self.customProceduralFiltererAPI ??
    self.floorpCSSUserActivationState?.proceduralFilterer;
const plainSelectors = self.customFilters?.plainSelectors;
const cssAPI = self.cssAPI;
const latestExecution = self.floorpCSSUserLatestExecutionRecord;
const pendingIdentity = self.floorpCSSUserIdentityPendingRecord;
if ( typeof latestExecution === 'object' && latestExecution !== null ) {
    latestExecution.cancelled = true;
}
if ( typeof pendingIdentity === 'object' && pendingIdentity !== null ) {
    pendingIdentity.cancelled = true;
    cssAPI?.cancelIdentity?.(pendingIdentity);
}
self.floorpCSSUserLatestExecutionRecord = { cancelled: true };
self.floorpCSSUserIdentityPendingRecord = undefined;

// forgetOwner synchronously removes this generation from remembered and
// in-flight CSS before its first await. Invalidate the generation immediately
// afterwards so pending css-user work cannot publish customFilters or commit a
// reset filterer while termination is being acknowledged to the picker.
const forgetOperation =
    typeof generation === 'object' &&
    generation !== null &&
    typeof cssAPI?.forgetOwner === 'function'
        ? cssAPI.forgetOwner(generation, generation)
        : undefined;
if ( typeof startHandler === 'function' ) {
    self.removeEventListener('pagereveal', startHandler);
    self.removeEventListener('pageshow', startHandler);
}
self.cssUserDocumentGeneration = {};
self.floorpCSSUserActivationState = undefined;
self.cssUserStartHandler = undefined;
self.cssUserPendingOp = Promise.resolve();
self.floorpCSSUserBootstrapState = undefined;
self.floorpCSSUserExecution = undefined;
self.customFilters = undefined;
self.customProceduralFiltererAPI = undefined;

const cleanup = [];
if ( forgetOperation !== undefined ) {
    cleanup.push(forgetOperation);
} else if ( plainSelectors ) {
    cleanup.push(Promise.reject(
        new Error('Custom-filter CSS owner cleanup is unavailable')
    ));
}
if ( typeof filterer?.reset === 'function' ) {
    cleanup.push(Promise.resolve().then(( ) =>
        filterer.reset({
            // Owner-scoped cssAPI cleanup removes native CSS without touching
            // stock sheets; reset still tears down observers and node tokens.
            removeCSS: forgetOperation === undefined,
        })
    ));
}
const cleanupResults = await Promise.allSettled(cleanup);
const rejectedCleanup = cleanupResults.find(result =>
    result.status === 'rejected'
);
if ( rejectedCleanup !== undefined ) {
    throw rejectedCleanup.reason;
}
const failedCleanup = cleanupResults.find(result =>
    result.status === 'fulfilled' && result.value?.ok === false
);
if ( failedCleanup !== undefined ) {
    throw new Error(
        failedCleanup.value.error || 'Custom-filter termination failed'
    );
}

/******************************************************************************/

return {
    ok: true,
    schema: 1,
    documentId: cssAPI?.documentId ?? null,
};

})();

self.floorpCSSUserTerminationOp = floorpCSSUserTermination;
void floorpCSSUserTermination.catch(( ) => undefined);
void 0;
