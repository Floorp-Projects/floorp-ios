/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

(async function uBOL_cssUser() {

/******************************************************************************/

// Safari can reuse an isolated-world global when the tab commits a new
// document. Keep the custom-filter guard and its serialized operation scoped
// to the document that created them, otherwise a later navigation can inherit
// `customFilters` and skip both CSS and procedural injection.
// Use the content-script execution as the generation boundary because Safari
// can preserve the JavaScript `document` wrapper identity as well.
const cssUserDocumentGeneration = {};
if ( typeof self.cssUserStartHandler === 'function' ) {
    self.removeEventListener('pagereveal', self.cssUserStartHandler);
}
const previousProceduralFilterer = self.customProceduralFiltererAPI;
const previousPendingOp = self.cssUserPendingOp;
self.cssUserDocumentGeneration = cssUserDocumentGeneration;
self.customFilters = undefined;
self.customProceduralFiltererAPI = undefined;
const cssUserCleanupOp = Promise.resolve(previousPendingOp)
    .catch(( ) => undefined)
    .then(( ) => previousProceduralFilterer instanceof Object
        ? previousProceduralFilterer.reset()
        : undefined
    )
    .catch(( ) => undefined);
self.cssUserPendingOp = cssUserCleanupOp;

self.cssUserStartHandler = uBOL_cssUserStart;
const isCurrentDocument = ( ) =>
    self.cssUserDocumentGeneration === cssUserDocumentGeneration &&
    self.cssUserStartHandler === uBOL_cssUserStart;

async function uBOL_cssUserActivate() {
    if ( isCurrentDocument() === false ) { return; }
    if ( self.customFilters ) { return; }

    const docURL = new URL(document.baseURI);

    const details = await chrome.runtime.sendMessage({
        what: 'injectCustomFilters',
        hostname: docURL.hostname,
    }).catch(( ) => {
    });
    if ( isCurrentDocument() === false ) { return; }
    self.customFilters = details;
    if ( Boolean(details) === false ) { return; }

    if ( details?.proceduralSelectors?.length ) {
        if ( self.ProceduralFiltererAPI === undefined ) {
            self.ProceduralFiltererAPI = chrome.runtime.sendMessage({
                what: 'injectCSSProceduralAPI'
            }).catch(( ) => {
            });
        }
        await self.ProceduralFiltererAPI;
        if ( isCurrentDocument() === false ) { return; }
        self.customProceduralFiltererAPI = new self.ProceduralFiltererAPI();
        const selectors = details.proceduralSelectors.map(a => JSON.parse(a));
        const declaratives = selectors.filter(a => a.cssable);
        if ( declaratives.length !== 0 ) {
            self.customProceduralFiltererAPI.addDeclaratives(declaratives);
        }
        const procedurals = selectors.filter(a => !a.cssable);
        if ( procedurals.length !== 0 ) {
            self.customProceduralFiltererAPI.addProcedurals(procedurals);
        }
    }

    if ( details?.plainSelectors?.length ) {
        const selectors = details.plainSelectors;
        self.cssAPI.insert(`${selectors.join(',\n')}{display:none!important;}`);
    }
}

async function uBOL_cssUserStart() {
    if ( isCurrentDocument() === false ) { return; }
    const pendingOp = Promise.resolve(self.cssUserPendingOp)
        .catch(( ) => undefined)
        .then(uBOL_cssUserActivate);
    self.cssUserPendingOp = pendingOp.catch(( ) => undefined);
    await pendingOp;
    if ( isCurrentDocument() === false ) { return; }
    if ( Boolean(self.customFilters) === false ) { return; }
    self.removeEventListener('pagereveal', uBOL_cssUserStart);
}

await uBOL_cssUserStart();

if ( isCurrentDocument() === false ) { return; }
if ( self.customFilters ) { return; }
self.addEventListener('pagereveal', uBOL_cssUserStart);

/******************************************************************************/

})();

void 0;
