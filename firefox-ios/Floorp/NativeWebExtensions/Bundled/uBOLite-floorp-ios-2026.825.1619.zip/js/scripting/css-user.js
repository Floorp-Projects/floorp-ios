/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

var floorpCSSUserExecutionRecord = {};
var floorpCSSUserExecution = (async function uBOL_cssUser(executionRecord) {

/******************************************************************************/

const floorpIdleReplay = self.floorpCSSUserIdleReplay === true;
self.floorpCSSUserIdleReplay = undefined;
self.floorpCSSUserAPIIdleReplay = undefined;
const floorpOriginFallbackDocument = document.location.hostname === '';
const customFilterActivationTimeout = 15000;
executionRecord.startedAt = performance.now();
executionRecord.deadline =
    executionRecord.startedAt + customFilterActivationTimeout;
const customFilterMessageSchema = 1;
const customFilterReplyTimeout = 2000;
const customFilterRetryDelays = [ 100, 250, 500, 1000, 2000 ];
const customFilterRequestId = globalThis.crypto?.randomUUID?.() ||
    `${Date.now()}-${Math.random()}`;
self.floorpCSSUserIdentityPendingRecord = executionRecord;
if ( typeof self.cssAPI?.suspendForIdentity === 'function' ) {
    self.cssAPI.suspendForIdentity(executionRecord);
}
self.floorpCSSUserLatestExecutionRecord = executionRecord;

function failedExecution() {
    return { ok: false, schema: customFilterMessageSchema, committed: false };
}

function isLatestExecution() {
    return executionRecord.cancelled !== true &&
        self.floorpCSSUserLatestExecutionRecord === executionRecord &&
        performance.now() < executionRecord.deadline;
}

async function followLatestExecution() {
    const latestRecord = self.floorpCSSUserLatestExecutionRecord;
    // A deadline-expired execution can still be the newest record. Never await
    // its own Promise while trying to hand off to a newer execution.
    if ( latestRecord === executionRecord ) { return failedExecution(); }
    const latestOperation = latestRecord?.operation;
    if ( latestOperation instanceof Promise ) {
        try {
            return await latestOperation;
        } catch {
        }
    }
    return failedExecution();
}

function waitForBootstrapTimeout(delay) {
    return new Promise(resolve => setTimeout(resolve, delay));
}

function validDocumentIdentity(response, requestId) {
    return typeof response === 'object' &&
        response !== null &&
        response.ok === true &&
        response.schema === customFilterMessageSchema &&
        response.requestId === requestId &&
        typeof response.documentId === 'string' &&
        response.documentId !== '' &&
        Number.isInteger(response.frameId) &&
        response.frameId >= 0;
}

async function readDocumentIdentity() {
    const deadline = executionRecord.deadline;
    let attempt = 0;
    while (
        executionRecord.cancelled !== true &&
        performance.now() < deadline
    ) {
        const requestId = `${customFilterRequestId}:document:${attempt}`;
        const requestRoot = document.documentElement;
        let timeoutId;
        const operation = Promise.resolve().then(( ) =>
            chrome.runtime.sendMessage({
                what: 'floorpCSSDocumentIdentity',
                schema: customFilterMessageSchema,
                requestId,
            })
        );
        void operation.catch(( ) => undefined);
        let outcome;
        try {
            outcome = await Promise.race([
                operation.then(
                    value => ({ status: 'resolved', value }),
                    reason => ({ status: 'rejected', reason })
                ),
                new Promise(resolve => {
                    timeoutId = setTimeout(
                        () => resolve({ status: 'timeout' }),
                        Math.min(
                            customFilterReplyTimeout,
                            deadline - performance.now()
                        )
                    );
                }),
            ]);
        } finally {
            clearTimeout(timeoutId);
        }
        if (
            outcome.status === 'resolved' &&
            document.documentElement === requestRoot &&
            validDocumentIdentity(outcome.value, requestId)
        ) {
            return outcome.value;
        }
        const remaining = deadline - performance.now();
        if ( remaining <= 0 ) { break; }
        const delay = customFilterRetryDelays[
            Math.min(attempt, customFilterRetryDelays.length - 1)
        ];
        attempt += 1;
        await waitForBootstrapTimeout(Math.min(delay, remaining));
    }
}

const cssUserDocumentIdentity = await readDocumentIdentity();
if ( cssUserDocumentIdentity === undefined ) {
    return failedExecution();
}
if ( isLatestExecution() === false ) {
    return followLatestExecution();
}
const cssUserNativeDocumentId = cssUserDocumentIdentity.documentId;
const cssUserNativeFrameId = cssUserDocumentIdentity.frameId;
let cssUserIdentityResumed = false;
if ( typeof self.cssAPI?.resumeForIdentity === 'function' ) {
    cssUserIdentityResumed = self.cssAPI.resumeForIdentity(
        executionRecord,
        cssUserNativeDocumentId,
        cssUserNativeFrameId
    );
}

async function bindCSSAPIToCurrentDocument() {
    let cssAPI = self.cssAPI;
    if ( cssUserIdentityResumed === true ) { return true; }

    // The isolated global can survive an origin-fallback commit even when the
    // native Document changed. Invalidate the old generation before yielding,
    // then force guarded APIs into this exact sender.documentId.
    const oldStartHandler = self.cssUserStartHandler;
    if ( typeof oldStartHandler === 'function' ) {
        self.removeEventListener('pagereveal', oldStartHandler);
        self.removeEventListener('pageshow', oldStartHandler);
    }
    self.cssUserDocumentGeneration = {};
    self.floorpCSSUserActivationState = undefined;
    self.cssUserStartHandler = undefined;
    self.cssUserPendingOp = Promise.resolve();
    self.customFilters = undefined;
    const forceToken = {};
    self.floorpCSSUserIdentityPendingRecord = executionRecord;
    if ( typeof cssAPI?.suspendForIdentity === 'function' ) {
        cssAPI.suspendForIdentity(executionRecord);
    }
    self.floorpCSSUserForceAPIReplay = forceToken;
    const requestId = `${customFilterRequestId}:api`;
    try {
        const operation = Promise.resolve().then(( ) =>
            chrome.runtime.sendMessage({
                what: 'injectCSSProceduralAPI',
                schema: customFilterMessageSchema,
                requestId,
            })
        );
        void operation.catch(( ) => undefined);
        const remaining = Math.max(
            0,
            executionRecord.deadline - performance.now()
        );
        if ( remaining === 0 ) { return false; }
        let timeoutId;
        let outcome;
        try {
            outcome = await Promise.race([
                operation.then(
                    value => ({ status: 'resolved', value }),
                    reason => ({ status: 'rejected', reason })
                ),
                new Promise(resolve => {
                    timeoutId = setTimeout(
                        () => resolve({ status: 'timeout' }),
                        remaining
                    );
                }),
            ]);
        } finally {
            clearTimeout(timeoutId);
        }
        if (
            outcome.status !== 'resolved' ||
            isLatestExecution() === false
        ) { return false; }
        const response = outcome.value;
        if (
            typeof response !== 'object' ||
            response === null ||
            response.ok !== true ||
            response.schema !== customFilterMessageSchema ||
            response.requestId !== requestId
        ) { return false; }
    } catch {
        return false;
    } finally {
        if ( self.floorpCSSUserForceAPIReplay === forceToken ) {
            self.floorpCSSUserForceAPIReplay = undefined;
        }
    }
    cssAPI = self.cssAPI;
    self.floorpCSSUserIdentityPendingRecord = executionRecord;
    if ( typeof cssAPI?.suspendForIdentity === 'function' ) {
        cssAPI.suspendForIdentity(executionRecord);
    }
    cssUserIdentityResumed =
        typeof cssAPI?.resumeForIdentity === 'function' &&
        cssAPI.resumeForIdentity(
            executionRecord,
            cssUserNativeDocumentId,
            cssUserNativeFrameId
        );
    return cssUserIdentityResumed;
}

if ( await bindCSSAPIToCurrentDocument() === false ) {
    return isLatestExecution() ? failedExecution() : followLatestExecution();
}
if ( isLatestExecution() === false ) {
    return followLatestExecution();
}

// Each executeScript(files:) evaluation receives an independent result in
// Safari, and multiple picker starts can overlap. Use the native Document ID as
// the key and share its serialized activation queue; URL, timeOrigin, and the
// mutable documentElement are deliberately not document identities. Joining
// the queue directly lets document_idle grant recovery after document_start's
// own deadline instead of consuming both windows while awaiting its wrapper.
const existingBootstrap = self.floorpCSSUserBootstrapState;
if (
    existingBootstrap?.documentId === cssUserNativeDocumentId &&
    existingBootstrap.frameId === cssUserNativeFrameId &&
    existingBootstrap.record !== executionRecord
) {
    const activation = self.floorpCSSUserActivationState;
    if (
        activation?.documentId === cssUserNativeDocumentId &&
        activation.frameId === cssUserNativeFrameId &&
        activation.generation === self.cssUserDocumentGeneration &&
        typeof self.cssUserStartHandler === 'function'
    ) {
        if ( activation.committed !== true ) {
            await self.cssUserStartHandler({
                type: floorpIdleReplay
                    ? 'floorp-document-idle'
                    : 'floorp-dynamic-start',
            });
        }
        const committed = activation.committed === true &&
            activation.generation === self.cssUserDocumentGeneration;
        return {
            ok: committed,
            schema: customFilterMessageSchema,
            committed,
            documentId: cssUserNativeDocumentId,
        };
    }
}
if ( isLatestExecution() === false ) {
    return followLatestExecution();
}
self.floorpCSSUserBootstrapState = {
    documentId: cssUserNativeDocumentId,
    frameId: cssUserNativeFrameId,
    operation: executionRecord.operation,
    record: executionRecord,
};

// A stable document_idle execution is idempotent. A true transient commit has
// a different native Document ID and reached the fresh-generation path above.
const sameDocumentActivation = self.floorpCSSUserActivationState;
if (
    sameDocumentActivation?.documentId === cssUserNativeDocumentId &&
    sameDocumentActivation.frameId === cssUserNativeFrameId &&
    sameDocumentActivation.generation === self.cssUserDocumentGeneration &&
    typeof self.cssUserStartHandler === 'function'
) {
    if ( sameDocumentActivation.committed !== true ) {
        await self.cssUserStartHandler({
            type: floorpIdleReplay
                ? 'floorp-document-idle'
                : 'floorp-dynamic-start',
        });
        if ( isLatestExecution() === false ) {
            return followLatestExecution();
        }
    }
    const committed = sameDocumentActivation.committed === true;
    return {
        ok: committed,
        schema: customFilterMessageSchema,
        committed,
        documentId: cssUserNativeDocumentId,
    };
}

// Safari can reuse an isolated-world global when the tab commits a new
// document. Keep the custom-filter guard and its serialized operation scoped
// to the document that created them, otherwise a later navigation can inherit
// `customFilters` and skip both CSS and procedural injection.
// Use the content-script execution as the generation boundary because Safari
// can preserve the JavaScript `document` wrapper identity as well.
const cssUserDocumentGeneration = {};
if ( isLatestExecution() === false ) {
    return followLatestExecution();
}
if ( typeof self.cssUserStartHandler === 'function' ) {
    self.removeEventListener('pagereveal', self.cssUserStartHandler);
    self.removeEventListener('pageshow', self.cssUserStartHandler);
}
const previousProceduralFilterer = self.customProceduralFiltererAPI;
self.cssUserDocumentGeneration = cssUserDocumentGeneration;
self.customFilters = undefined;
self.customProceduralFiltererAPI = undefined;
const cssUserActivationState = {
    generation: cssUserDocumentGeneration,
    documentId: cssUserNativeDocumentId,
    frameId: cssUserNativeFrameId,
    deadline: executionRecord.deadline,
    committed: false,
    details: undefined,
    awaitingCSSAPI: false,
    idleRecoveryUsed: false,
    proceduralFilterer: undefined,
};
self.floorpCSSUserActivationState = cssUserActivationState;
// Do not chain this document behind the previous document's pending runtime
// message. Safari can orphan that promise during navigation; the generation
// checks below prevent a late old result from mutating this script's
// generation-scoped state or applying its returned selectors.
const cssUserCleanupOp = Promise.resolve()
    .then(( ) => typeof previousProceduralFilterer?.reset === 'function'
        ? previousProceduralFilterer.reset({ removeCSS: false })
        : undefined
    )
    .catch(( ) => undefined);
self.cssUserPendingOp = cssUserCleanupOp;

self.cssUserStartHandler = uBOL_cssUserStart;
const isCurrentDocument = ( ) =>
    executionRecord.cancelled !== true &&
    (
        self.floorpCSSUserIdentityPendingRecord === undefined ||
        self.floorpCSSUserIdentityPendingRecord === executionRecord
    ) &&
    self.cssUserDocumentGeneration === cssUserDocumentGeneration &&
    self.cssUserStartHandler === uBOL_cssUserStart &&
    self.floorpCSSUserActivationState === cssUserActivationState &&
    self.cssAPI?.documentId === cssUserNativeDocumentId &&
    self.cssAPI?.frameId === cssUserNativeFrameId;

const customFilterMutationJournalKey =
    'floorp.customFilterMutationJournal.v1';
const customFilterModeStorageKeys = [
    'filteringModeDetails',
    'admin.defaultFiltering',
    'admin.noFiltering',
];
const settingsRestoreJournalKey = 'floorp.settingsRestoreJournal.v1';

function hostnameFromURL(value) {
    if ( typeof value !== 'string' || value === '' ) { return ''; }
    try {
        const url = new URL(value);
        if ( url.hostname !== '' ) { return url.hostname; }
        if ( url.origin !== 'null' ) {
            return new URL(url.origin).hostname;
        }
    } catch {
    }
    return '';
}

function hostnameFromHTTPURL(value) {
    if ( typeof value !== 'string' || value === '' ) { return ''; }
    try {
        const url = new URL(value);
        if (
            (url.protocol === 'http:' || url.protocol === 'https:') &&
            url.hostname !== ''
        ) {
            return url.hostname.toLowerCase();
        }
    } catch {
    }
    return '';
}

function originFallbackHostname() {
    // WebKit matches about:, data:, and blob: registrations against the
    // immediate parent's URL, even when a blob URL serializes a different
    // HTTP(S) origin. Mirror that exact authority and never select the blob's
    // embedded origin or a more distant ancestor.
    try {
        if ( self.parent === self ) { return ''; }
    } catch {
        return '';
    }
    let ancestorHostname = '';
    try {
        ancestorHostname = hostnameFromHTTPURL(
            document.location.ancestorOrigins?.[0]
        );
    } catch {
    }
    let parentHostname = '';
    try {
        if ( self.parent !== self ) {
            parentHostname = hostnameFromHTTPURL(self.parent.location.origin) ||
                hostnameFromHTTPURL(self.parent.location.href);
        }
    } catch {
    }
    if (
        ancestorHostname !== '' &&
        parentHostname !== '' &&
        ancestorHostname !== parentHostname
    ) {
        return '';
    }
    return ancestorHostname || parentHostname;
}

function customFilterStorageKeys(hostname) {
    const out = [];
    let hn = hostname;
    while ( hn !== '' ) {
        out.push(`site.${hn}`);
        const pos = hn.indexOf('.');
        if ( pos === -1 ) { break; }
        hn = hn.slice(pos + 1);
    }
    return out;
}

function committedJournalSnapshot(journal, label, phases) {
    if ( journal === undefined ) { return; }
    if (
        typeof journal !== 'object' ||
        journal === null ||
        Array.isArray(journal) ||
        journal.version !== 1 ||
        typeof journal.id !== 'string' ||
        journal.id === '' ||
        phases.includes(journal.phase) === false ||
        typeof journal.beforeLocal !== 'object' ||
        journal.beforeLocal === null ||
        Array.isArray(journal.beforeLocal)
    ) {
        throw new Error(`Invalid ${label} journal`);
    }
    return journal.beforeLocal;
}

function broaderHostnameInSet(hostname, set) {
    if ( set.has('*') ) { return true; }
    let hn = hostname;
    for (;;) {
        if ( set.has(hn) ) { return true; }
        const pos = hn.indexOf('.');
        if ( pos === -1 ) { return false; }
        hn = hn.slice(pos + 1);
    }
}

function serializedModeSets(details) {
    const source = details ?? {
        none: [],
        basic: [],
        optimal: [ 'all-urls' ],
        complete: [],
    };
    if (
        typeof source !== 'object' ||
        source === null ||
        Array.isArray(source)
    ) {
        throw new Error('Invalid filtering-mode storage snapshot');
    }
    const aliases = {
        none: 'none',
        basic: source.basic === undefined ? 'network' : 'basic',
        optimal: source.optimal === undefined
            ? 'extendedSpecific'
            : 'optimal',
        complete: source.complete === undefined
            ? 'extendedGeneric'
            : 'complete',
    };
    const modes = {};
    for ( const [ name, sourceName ] of Object.entries(aliases) ) {
        const values = source[sourceName];
        if (
            Array.isArray(values) === false ||
            values.some(value => typeof value !== 'string' || value === '')
        ) {
            throw new Error('Invalid filtering-mode storage snapshot');
        }
        modes[name] = new Set(values);
    }
    return modes;
}

function lookupMode(modes, hostname) {
    if ( hostname === 'all-urls' ) {
        for ( const name of [ 'none', 'basic', 'optimal', 'complete' ] ) {
            if ( modes[name].has('all-urls') ) { return name; }
        }
        return 'basic';
    }
    for ( const name of [ 'none', 'basic', 'optimal', 'complete' ] ) {
        if ( modes[name].has(hostname) ) { return name; }
        if (
            modes[name].has('all-urls') === false &&
            broaderHostnameInSet(hostname, modes[name])
        ) {
            return name;
        }
    }
    return lookupMode(modes, 'all-urls');
}

function pruneDescendants(hostname, set) {
    for ( const candidate of set ) {
        if (
            candidate !== hostname &&
            candidate.endsWith(`.${hostname}`)
        ) {
            set.delete(candidate);
        }
    }
}

function pruneHostname(hostname, set) {
    let hn = hostname;
    for (;;) {
        set.delete(hn);
        const pos = hn.indexOf('.');
        if ( pos === -1 ) { return; }
        hn = hn.slice(pos + 1);
    }
}

function applyMode(modes, hostname, afterMode) {
    const beforeMode = lookupMode(modes, hostname);
    if ( beforeMode === afterMode ) { return; }
    if ( hostname === 'all-urls' ) {
        modes[afterMode].clear();
        modes[afterMode].add('all-urls');
        modes[beforeMode].delete('all-urls');
        return;
    }
    pruneHostname(hostname, modes[beforeMode]);
    if ( afterMode === lookupMode(modes, 'all-urls') ) { return; }
    if ( broaderHostnameInSet(hostname, modes[afterMode]) === false ) {
        modes[afterMode].add(hostname);
        pruneDescendants(hostname, modes[afterMode]);
    }
}

function adminData(snapshot, key) {
    const envelope = snapshot[key];
    if ( envelope === undefined ) { return; }
    if (
        typeof envelope !== 'object' ||
        envelope === null ||
        Array.isArray(envelope)
    ) {
        throw new Error('Invalid administrator filtering-mode snapshot');
    }
    return envelope.data;
}

function customFilteringEnabled(snapshot, hostname) {
    const modes = serializedModeSets(snapshot.filteringModeDetails);
    const adminDefault = adminData(snapshot, 'admin.defaultFiltering');
    if ([ 'none', 'basic', 'optimal', 'complete' ].includes(adminDefault)) {
        applyMode(modes, 'all-urls', adminDefault);
    }
    const adminNone = adminData(snapshot, 'admin.noFiltering');
    if ( Array.isArray(adminNone) && adminNone.length !== 0 ) {
        if ( adminNone.some(value => typeof value !== 'string') ) {
            throw new Error('Invalid administrator filtering-mode snapshot');
        }
        if ( adminNone.includes('-*') ) { modes.none.clear(); }
        for ( const value of adminNone ) {
            if ( value.startsWith('-') ) {
                modes.none.delete(value.slice(1));
            } else if ( value !== '' ) {
                applyMode(modes, value, 'none');
            }
        }
    }
    return lookupMode(modes, hostname) !== 'none';
}

function selectorsFromStorageSnapshot(hostname, snapshot) {
    if (
        typeof snapshot !== 'object' ||
        snapshot === null ||
        Array.isArray(snapshot)
    ) {
        throw new Error('Invalid custom-filter storage snapshot');
    }
    const selectors = [];
    for ( const key of customFilterStorageKeys(hostname) ) {
        const values = snapshot[key];
        if ( values === undefined ) { continue; }
        if (
            Array.isArray(values) === false ||
            values.some(value => typeof value !== 'string')
        ) {
            throw new Error('Invalid custom-filter selector snapshot');
        }
        selectors.push(...values);
    }
    selectors.sort();
    return {
        plainSelectors: selectors.filter(selector =>
            selector.startsWith('{') === false &&
            selector.startsWith('+js') === false
        ),
        proceduralSelectors: selectors.filter(selector =>
            selector.startsWith('{')
        ),
    };
}

async function readStoredCustomFilters(hostname) {
    if ( hostname === '' ) { return; }
    const keys = [
        settingsRestoreJournalKey,
        customFilterMutationJournalKey,
        ...customFilterModeStorageKeys,
        ...customFilterStorageKeys(hostname),
    ];
    let localState;
    try {
        localState = await chrome.storage.local.get(keys);
    } catch {
        return;
    }
    if (
        typeof localState !== 'object' ||
        localState === null ||
        Array.isArray(localState)
    ) {
        throw new Error('Invalid local-storage snapshot');
    }
    const settingsSnapshot = committedJournalSnapshot(
        localState[settingsRestoreJournalKey],
        'settings restore',
        [ 'applying', 'committingForeground', 'rollingBack' ]
    );
    const mutationSnapshot = committedJournalSnapshot(
        localState[customFilterMutationJournalKey],
        'custom-filter mutation',
        [ 'applying', 'rollingBack' ]
    );
    let authoritativeState = localState;
    if ( settingsSnapshot !== undefined ) {
        // Settings restore owns user modes/selectors, while administrator
        // policy can change independently and must remain immediately
        // authoritative even during apply or rollback.
        authoritativeState = {
            ...settingsSnapshot,
            'admin.defaultFiltering': localState['admin.defaultFiltering'],
            'admin.noFiltering': localState['admin.noFiltering'],
        };
    } else if ( mutationSnapshot !== undefined ) {
        authoritativeState = {
            ...Object.fromEntries(customFilterModeStorageKeys.map(key => [
                key,
                localState[key],
            ])),
            ...mutationSnapshot,
        };
    }
    const details = customFilteringEnabled(authoritativeState, hostname)
        ? selectorsFromStorageSnapshot(hostname, authoritativeState)
        : { plainSelectors: [], proceduralSelectors: [] };
    return {
        ok: true,
        schema: customFilterMessageSchema,
        requestId: customFilterRequestId,
        ...details,
    };
}

// matchOriginAsFallback runs this script in about:, data:, blob:, and srcdoc
// frames whose own URL has no hostname. Their direct path mirrors WebKit's
// immediate-parent authority. Ordinary HTTP(S) documents may use the same
// bounded snapshot only after a background transport failure and only when the
// live location still proves the original hostname. document.baseURI is
// page-controlled and must never select which site's document is returned.
const customFilterHostname = document.location.hostname ||
    hostnameFromURL(document.location.origin);
const customFilterRequest = {
    what: 'injectCustomFilters',
    schema: customFilterMessageSchema,
    requestId: customFilterRequestId,
    hostname: customFilterHostname,
};

function waitForTimeout(delay) {
    return new Promise(resolve => setTimeout(resolve, delay));
}

function remainingActivationTime() {
    return cssUserActivationState.deadline - performance.now();
}

function retryDelay(attempt) {
    return customFilterRetryDelays[
        Math.min(attempt, customFilterRetryDelays.length - 1)
    ];
}

async function waitForRetry(attempt) {
    const remaining = remainingActivationTime();
    if ( remaining <= 0 ) { return false; }
    await waitForTimeout(Math.min(retryDelay(attempt), remaining));
    return isCurrentDocument() && remainingActivationTime() > 0;
}

async function waitForMessageReply(operation) {
    let timeoutId;
    try {
        const remaining = remainingActivationTime();
        if ( remaining <= 0 ) { return { status: 'timeout' }; }
        return await Promise.race([
            operation.then(
                value => ({ status: 'resolved', value }),
                reason => ({ status: 'rejected', reason })
            ),
            new Promise(resolve => {
                timeoutId = setTimeout(
                    () => resolve({ status: 'timeout' }),
                    Math.min(customFilterReplyTimeout, remaining)
                );
            }),
        ]);
    } finally {
        clearTimeout(timeoutId);
    }
}

function isValidCustomFilterAck(details, requestId) {
    return typeof details === 'object' &&
        details !== null &&
        details.ok === true &&
        details.schema === customFilterMessageSchema &&
        details.requestId === requestId &&
        Array.isArray(details.plainSelectors) &&
        details.plainSelectors.every(selector => typeof selector === 'string') &&
        Array.isArray(details.proceduralSelectors) &&
        details.proceduralSelectors.every(selector => typeof selector === 'string');
}

async function requestCustomFilters() {
    let attempt = 0;
    let useStoredSnapshot = floorpOriginFallbackDocument;
    while ( isCurrentDocument() && remainingActivationTime() > 0 ) {
        // MessageSender.url/origin describe an origin-fallback child document
        // and can expose a blob's embedded origin rather than the immediate
        // parent URL WebKit matched. Keep that authority on the direct storage
        // path; retrying must never switch it to the background hostname path.
        const operation = Promise.resolve().then(( ) => {
            if ( useStoredSnapshot ) {
                const hostname = floorpOriginFallbackDocument
                    ? originFallbackHostname()
                    : hostnameFromHTTPURL(document.location.href);
                if (
                    floorpOriginFallbackDocument === false &&
                    hostname !== customFilterHostname
                ) { return; }
                return readStoredCustomFilters(hostname);
            }
            return chrome.runtime.sendMessage(customFilterRequest);
        });
        const outcome = await waitForMessageReply(operation);
        if ( isCurrentDocument() === false ) { return; }
        if (
            outcome.status === 'resolved' &&
            isValidCustomFilterAck(
                outcome.value,
                customFilterRequestId
            )
        ) {
            return outcome.value;
        }
        // A missing or malformed resolved reply is an explicit fail-closed
        // signal. Only transport timeout/rejection can switch the ordinary
        // document to the same one-snapshot storage path used by WebKit's
        // origin-fallback frames.
        if ( useStoredSnapshot === false && outcome.status !== 'resolved' ) {
            useStoredSnapshot = true;
        }
        if ( await waitForRetry(attempt) === false ) { return; }
        attempt += 1;
    }
}

async function ensureProceduralAPI() {
    if ( typeof self.ProceduralFiltererAPI === 'function' ) { return true; }
    let attempt = 0;
    while ( isCurrentDocument() && remainingActivationTime() > 0 ) {
        const requestId = `${customFilterRequestId}:procedural:${attempt}`;
        const operation = Promise.resolve().then(( ) =>
            chrome.runtime.sendMessage({
                what: 'injectCSSProceduralAPI',
                schema: customFilterMessageSchema,
                requestId,
            })
        );
        self.ProceduralFiltererAPI = operation;
        void operation.catch(( ) => undefined);
        const outcome = await waitForMessageReply(operation);
        if ( isCurrentDocument() === false ) { return false; }
        if (
            outcome.status === 'resolved' &&
            isValidCustomFilterAck(outcome.value, requestId) &&
            typeof self.ProceduralFiltererAPI === 'function'
        ) {
            return true;
        }
        if ( self.ProceduralFiltererAPI === operation ) {
            self.ProceduralFiltererAPI = undefined;
        }
        if ( await waitForRetry(attempt) === false ) { return false; }
        attempt += 1;
    }
    return false;
}

async function uBOL_cssUserActivate() {
    if ( isCurrentDocument() === false ) { return; }
    if ( cssUserActivationState.committed ) { return; }

    let details = cssUserActivationState.details;
    if ( details === undefined ) {
        try {
            details = await requestCustomFilters();
        } catch {
            return;
        }
        if ( isCurrentDocument() === false ) { return; }
        if ( Boolean(details) === false ) { return; }
        cssUserActivationState.details = details;
    }

    const hasCSS = details.plainSelectors.length !== 0 ||
        details.proceduralSelectors.length !== 0;
    const cssAPI = self.cssAPI;
    if (
        hasCSS && (
            typeof cssAPI?.insert !== 'function' ||
            typeof cssAPI?.commit !== 'function'
        )
    ) {
        // css-api is normally preloaded before css-user, including plain-only
        // registrations. Keep this explicit state for the one bounded idle
        // recovery path if WebKit skipped or delayed that registered script.
        cssUserActivationState.awaitingCSSAPI = true;
        return;
    }
    cssUserActivationState.awaitingCSSAPI = false;

    if (
        details.proceduralSelectors.length &&
        cssUserActivationState.proceduralFilterer === undefined
    ) {
        if ( await ensureProceduralAPI() === false ) { return; }
        if ( isCurrentDocument() === false ) { return; }
        if (
            typeof cssAPI.beginInsertionTransaction !== 'function' ||
            typeof cssAPI.finishInsertionTransaction !== 'function' ||
            typeof cssAPI.rollbackInsertionTransaction !== 'function'
        ) {
            cssUserActivationState.awaitingCSSAPI = true;
            return;
        }
        let filterer;
        let transaction;
        try {
            // Parse the complete selector document before constructing anything.
            // The transaction then stages all synchronous add* CSS calls without
            // native side effects until every selector has been accepted.
            const selectors = details.proceduralSelectors.map(a => JSON.parse(a));
            transaction = cssAPI.beginInsertionTransaction(
                cssUserDocumentGeneration,
                cssUserActivationState.deadline,
                cssUserDocumentGeneration,
                'custom'
            );
            filterer = new self.ProceduralFiltererAPI({
                cssOwner: cssUserDocumentGeneration,
                cssGeneration: cssUserDocumentGeneration,
                cssLane: 'custom',
            });
            const declaratives = selectors.filter(a => a.cssable);
            if ( declaratives.length !== 0 ) {
                filterer.addDeclaratives(declaratives);
            }
            const procedurals = selectors.filter(a => !a.cssable);
            if ( procedurals.length !== 0 ) {
                filterer.addProcedurals(procedurals);
            }
            cssAPI.finishInsertionTransaction(transaction);
            transaction = undefined;
            if ( isCurrentDocument() === false ) {
                await filterer.reset({ removeCSS: true });
                return;
            }
            // Publish only a fully parsed and fully constructed filterer. Native
            // insertion acknowledgement is still required by commit() below.
            cssUserActivationState.proceduralFilterer = filterer;
        } catch {
            // A construction failure occurred while CSS was only staged, so a
            // reset without native removal safely tears down observers, tokens,
            // and node attributes while keeping insert/remove message counts at
            // zero. Clear state before awaiting cleanup so replay cannot observe
            // or commit the partial filterer.
            if ( isCurrentDocument() ) {
                cssUserActivationState.proceduralFilterer = undefined;
                if ( self.customProceduralFiltererAPI === filterer ) {
                    self.customProceduralFiltererAPI = undefined;
                }
                cssUserActivationState.details = undefined;
            }
            if ( transaction !== undefined ) {
                try {
                    cssAPI.rollbackInsertionTransaction(transaction);
                } catch {
                }
            }
            if ( typeof filterer?.reset === 'function' ) {
                try {
                    await filterer.reset({ removeCSS: false });
                } catch {
                }
            }
            return;
        }
    }

    try {
        if ( details.plainSelectors.length ) {
            const selectors = details.plainSelectors;
            const insertion = await cssAPI.insert(
                `${selectors.join(',\n')}{display:none!important;}`,
                {
                    deadline: cssUserActivationState.deadline,
                    generation: cssUserDocumentGeneration,
                    lane: 'custom',
                    owner: cssUserDocumentGeneration,
                }
            );
            if ( insertion?.ok !== true ) { return; }
        }

        if ( hasCSS ) {
            const committed = await cssAPI.commit(
                cssUserDocumentGeneration,
                cssUserDocumentGeneration,
                cssUserActivationState.deadline
            );
            if ( committed?.ok !== true ) { return; }
        }
    } catch {
        return;
    }
    if ( isCurrentDocument() === false ) { return; }
    self.customProceduralFiltererAPI =
        cssUserActivationState.proceduralFilterer;
    self.customFilters = details;
    cssUserActivationState.committed = true;
}

function beginLifecycleRecovery(event) {
    const isPageReveal = event?.type === 'pagereveal' ||
        event?.type === 'pageshow' && event?.persisted === true;
    const isDynamicRecovery = event?.type === 'floorp-dynamic-start';
    const isIdleRecovery =
        event?.type === 'floorp-document-idle' &&
        cssUserActivationState.committed !== true &&
        cssUserActivationState.idleRecoveryUsed !== true;
    let recovery;
    if (
        isIdleRecovery ||
        (isPageReveal || isDynamicRecovery) &&
            cssUserActivationState.deadline <= performance.now()
    ) {
        cssUserActivationState.deadline =
            performance.now() + customFilterActivationTimeout;
        if ( isIdleRecovery ) {
            cssUserActivationState.idleRecoveryUsed = true;
        }
        // Invoke this before yielding so css-api/css-user listener order cannot
        // make one reveal use an expired window. css-api coalesces concurrent
        // recovery and replay for this document generation.
        if ( typeof self.cssAPI?.beginRecoveryWindow === 'function' ) {
            recovery = self.cssAPI.beginRecoveryWindow(
                cssUserDocumentGeneration
            );
        }
    }
    return { event, recovery };
}

async function prepareLifecycleRecovery(lifecycle) {
    if ( lifecycle.recovery !== undefined ) {
        try {
            await lifecycle.recovery;
        } catch {
            return false;
        }
    }
    if (
        lifecycle.event?.type !== 'pagereveal' &&
        lifecycle.event?.type !== 'pageshow' &&
        lifecycle.event?.type !== 'floorp-document-idle'
    ) {
        return true;
    }
    const cssAPI = self.cssAPI;
    if (
        typeof cssAPI?.waitForRecovery === 'function' &&
        typeof cssAPI?.replay === 'function'
    ) {
        const recovered = await cssAPI.waitForRecovery(
            cssUserDocumentGeneration
        );
        if ( recovered?.ok !== true ) { return false; }
        const replayed = await cssAPI.replay(cssUserDocumentGeneration, {
            deadline: cssUserActivationState.deadline,
            owner: cssUserDocumentGeneration,
        });
        if ( replayed?.ok !== true ) { return false; }
    }
    return isCurrentDocument();
}

async function uBOL_cssUserStart(event) {
    if ( event?.type === 'pageshow' && event?.persisted !== true ) { return; }
    if ( isCurrentDocument() === false ) { return; }
    // A document_idle or dynamic replay may be queued behind the entire prior
    // activation. Evaluate recovery only when that queue reaches this caller,
    // otherwise both windows can expire together while the background wakes.
    const queuedRecovery = event?.type === 'floorp-document-idle' ||
        event?.type === 'floorp-dynamic-start';
    let lifecycle = queuedRecovery
        ? { event, recovery: undefined }
        : beginLifecycleRecovery(event);
    const pendingOp = Promise.resolve(self.cssUserPendingOp)
        .catch(( ) => undefined)
        .then(async ( ) => {
            // document_idle can enqueue behind a still-pending document_start
            // activation. If the earlier operation commits while queued, do
            // not replay already-installed CSS before hitting activate's guard.
            if ( cssUserActivationState.committed ) { return; }
            if ( queuedRecovery ) {
                lifecycle = beginLifecycleRecovery(event);
            }
            if ( await prepareLifecycleRecovery(lifecycle) === false ) { return; }
            return uBOL_cssUserActivate();
        });
    self.cssUserPendingOp = pendingOp.catch(( ) => undefined);
    await pendingOp;
    if ( isCurrentDocument() === false ) { return; }
    if ( cssUserActivationState.committed !== true ) { return; }
    self.removeEventListener('pagereveal', uBOL_cssUserStart);
    self.removeEventListener('pageshow', uBOL_cssUserStart);
}

await uBOL_cssUserStart();

const executionCommitted =
    isCurrentDocument() && cssUserActivationState.committed === true;
if ( executionCommitted === false && isCurrentDocument() ) {
    self.addEventListener('pagereveal', uBOL_cssUserStart);
    self.addEventListener('pageshow', uBOL_cssUserStart);
}
return {
    ok: executionCommitted,
    schema: customFilterMessageSchema,
    committed: executionCommitted,
    documentId: cssUserNativeDocumentId,
};

/******************************************************************************/

})(floorpCSSUserExecutionRecord);

floorpCSSUserExecutionRecord.operation = floorpCSSUserExecution;

self.floorpCSSUserExecution = floorpCSSUserExecution;
void floorpCSSUserExecution.catch(( ) => undefined);
void 0;
