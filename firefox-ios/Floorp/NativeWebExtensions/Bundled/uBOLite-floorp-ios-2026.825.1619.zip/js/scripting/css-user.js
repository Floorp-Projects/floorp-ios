/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

(async function uBOL_cssUser() {

/******************************************************************************/

const floorpIdleReplay = self.floorpCSSUserIdleReplay === true;
self.floorpCSSUserIdleReplay = undefined;
const floorpOriginFallbackDocument = document.location.hostname === '';
const floorpOriginFallbackReplay =
    floorpIdleReplay && floorpOriginFallbackDocument;
// The document_start registration already covers ordinary HTTP(S) documents.
// WebKit can reuse the same Document wrapper and time origin when a transient
// about:blank frame commits its final about:srcdoc document, so identity-based
// de-duplication loses the final activation. Re-run every hostname-less final
// document instead; the idle marker is placed immediately before this file and
// is never set by live, programmatic custom-filter refreshes.
if ( floorpIdleReplay && floorpOriginFallbackReplay === false ) { return; }

// Safari can reuse an isolated-world global when the tab commits a new
// document. Keep the custom-filter guard and its serialized operation scoped
// to the document that created them, otherwise a later navigation can inherit
// `customFilters` and skip both CSS and procedural injection.
// Use the content-script execution as the generation boundary because Safari
// can preserve the JavaScript `document` wrapper identity as well.
const cssUserDocumentGeneration = {};
if ( typeof self.cssUserStartHandler === 'function' ) {
    self.removeEventListener('pagereveal', self.cssUserStartHandler);
}
const previousProceduralFilterer = self.customProceduralFiltererAPI;
self.cssUserDocumentGeneration = cssUserDocumentGeneration;
self.customFilters = undefined;
self.customProceduralFiltererAPI = undefined;
// Do not chain this document behind the previous document's pending runtime
// message. Safari can orphan that promise during navigation; the generation
// checks below prevent a late old result from mutating this script's
// generation-scoped state or applying its returned selectors.
const cssUserCleanupOp = Promise.resolve()
    .then(( ) => previousProceduralFilterer instanceof Object
        ? previousProceduralFilterer.reset({ removeCSS: false })
        : undefined
    )
    .catch(( ) => undefined);
self.cssUserPendingOp = cssUserCleanupOp;

self.cssUserStartHandler = uBOL_cssUserStart;
const isCurrentDocument = ( ) =>
    self.cssUserDocumentGeneration === cssUserDocumentGeneration &&
    self.cssUserStartHandler === uBOL_cssUserStart;

const customFilterMessageSchema = 1;
const customFilterMutationJournalKey =
    'floorp.customFilterMutationJournal.v1';
const customFilterModeStorageKeys = [
    'filteringModeDetails',
    'admin.defaultFiltering',
    'admin.noFiltering',
];
const settingsRestoreJournalKey = 'floorp.settingsRestoreJournal.v1';
const customFilterReplyTimeout = 2000;
const customFilterUndefinedRetryDelay = 100;
const customFilterRequestId = globalThis.crypto?.randomUUID?.() ||
    `${Date.now()}-${Math.random()}`;

function hostnameFromURL(value) {
    if ( typeof value !== 'string' || value === '' ) { return ''; }
    try {
        const url = new URL(value);
        if ( url.hostname !== '' ) { return url.hostname; }
        if ( url.origin !== 'null' ) {
            return new URL(url.origin).hostname;
        }
    } catch {
    }
    return '';
}

function hostnameFromHTTPURL(value) {
    if ( typeof value !== 'string' || value === '' ) { return ''; }
    try {
        const url = new URL(value);
        if (
            (url.protocol === 'http:' || url.protocol === 'https:') &&
            url.hostname !== ''
        ) {
            return url.hostname.toLowerCase();
        }
    } catch {
    }
    return '';
}

function originFallbackHostname() {
    // WebKit matches about:, data:, and blob: registrations against the
    // immediate parent's URL, even when a blob URL serializes a different
    // HTTP(S) origin. Mirror that exact authority and never select the blob's
    // embedded origin or a more distant ancestor.
    try {
        if ( self.parent === self ) { return ''; }
    } catch {
        return '';
    }
    let ancestorHostname = '';
    try {
        ancestorHostname = hostnameFromHTTPURL(
            document.location.ancestorOrigins?.[0]
        );
    } catch {
    }
    let parentHostname = '';
    try {
        if ( self.parent !== self ) {
            parentHostname = hostnameFromHTTPURL(self.parent.location.origin) ||
                hostnameFromHTTPURL(self.parent.location.href);
        }
    } catch {
    }
    if (
        ancestorHostname !== '' &&
        parentHostname !== '' &&
        ancestorHostname !== parentHostname
    ) {
        return '';
    }
    return ancestorHostname || parentHostname;
}

function customFilterStorageKeys(hostname) {
    const out = [];
    let hn = hostname;
    while ( hn !== '' ) {
        out.push(`site.${hn}`);
        const pos = hn.indexOf('.');
        if ( pos === -1 ) { break; }
        hn = hn.slice(pos + 1);
    }
    return out;
}

function committedJournalSnapshot(journal, label, phases) {
    if ( journal === undefined ) { return; }
    if (
        typeof journal !== 'object' ||
        journal === null ||
        Array.isArray(journal) ||
        journal.version !== 1 ||
        typeof journal.id !== 'string' ||
        journal.id === '' ||
        phases.includes(journal.phase) === false ||
        typeof journal.beforeLocal !== 'object' ||
        journal.beforeLocal === null ||
        Array.isArray(journal.beforeLocal)
    ) {
        throw new Error(`Invalid ${label} journal`);
    }
    return journal.beforeLocal;
}

function broaderHostnameInSet(hostname, set) {
    if ( set.has('*') ) { return true; }
    let hn = hostname;
    for (;;) {
        if ( set.has(hn) ) { return true; }
        const pos = hn.indexOf('.');
        if ( pos === -1 ) { return false; }
        hn = hn.slice(pos + 1);
    }
}

function serializedModeSets(details) {
    const source = details ?? {
        none: [],
        basic: [],
        optimal: [ 'all-urls' ],
        complete: [],
    };
    if (
        typeof source !== 'object' ||
        source === null ||
        Array.isArray(source)
    ) {
        throw new Error('Invalid filtering-mode storage snapshot');
    }
    const aliases = {
        none: 'none',
        basic: source.basic === undefined ? 'network' : 'basic',
        optimal: source.optimal === undefined
            ? 'extendedSpecific'
            : 'optimal',
        complete: source.complete === undefined
            ? 'extendedGeneric'
            : 'complete',
    };
    const modes = {};
    for ( const [ name, sourceName ] of Object.entries(aliases) ) {
        const values = source[sourceName];
        if (
            Array.isArray(values) === false ||
            values.some(value => typeof value !== 'string' || value === '')
        ) {
            throw new Error('Invalid filtering-mode storage snapshot');
        }
        modes[name] = new Set(values);
    }
    return modes;
}

function lookupMode(modes, hostname) {
    if ( hostname === 'all-urls' ) {
        for ( const name of [ 'none', 'basic', 'optimal', 'complete' ] ) {
            if ( modes[name].has('all-urls') ) { return name; }
        }
        return 'basic';
    }
    for ( const name of [ 'none', 'basic', 'optimal', 'complete' ] ) {
        if ( modes[name].has(hostname) ) { return name; }
        if (
            modes[name].has('all-urls') === false &&
            broaderHostnameInSet(hostname, modes[name])
        ) {
            return name;
        }
    }
    return lookupMode(modes, 'all-urls');
}

function pruneDescendants(hostname, set) {
    for ( const candidate of set ) {
        if (
            candidate !== hostname &&
            candidate.endsWith(`.${hostname}`)
        ) {
            set.delete(candidate);
        }
    }
}

function pruneHostname(hostname, set) {
    let hn = hostname;
    for (;;) {
        set.delete(hn);
        const pos = hn.indexOf('.');
        if ( pos === -1 ) { return; }
        hn = hn.slice(pos + 1);
    }
}

function applyMode(modes, hostname, afterMode) {
    const beforeMode = lookupMode(modes, hostname);
    if ( beforeMode === afterMode ) { return; }
    if ( hostname === 'all-urls' ) {
        modes[afterMode].clear();
        modes[afterMode].add('all-urls');
        modes[beforeMode].delete('all-urls');
        return;
    }
    pruneHostname(hostname, modes[beforeMode]);
    if ( afterMode === lookupMode(modes, 'all-urls') ) { return; }
    if ( broaderHostnameInSet(hostname, modes[afterMode]) === false ) {
        modes[afterMode].add(hostname);
        pruneDescendants(hostname, modes[afterMode]);
    }
}

function adminData(snapshot, key) {
    const envelope = snapshot[key];
    if ( envelope === undefined ) { return; }
    if (
        typeof envelope !== 'object' ||
        envelope === null ||
        Array.isArray(envelope)
    ) {
        throw new Error('Invalid administrator filtering-mode snapshot');
    }
    return envelope.data;
}

function customFilteringEnabled(snapshot, hostname) {
    const modes = serializedModeSets(snapshot.filteringModeDetails);
    const adminDefault = adminData(snapshot, 'admin.defaultFiltering');
    if ([ 'none', 'basic', 'optimal', 'complete' ].includes(adminDefault)) {
        applyMode(modes, 'all-urls', adminDefault);
    }
    const adminNone = adminData(snapshot, 'admin.noFiltering');
    if ( Array.isArray(adminNone) && adminNone.length !== 0 ) {
        if ( adminNone.some(value => typeof value !== 'string') ) {
            throw new Error('Invalid administrator filtering-mode snapshot');
        }
        if ( adminNone.includes('-*') ) { modes.none.clear(); }
        for ( const value of adminNone ) {
            if ( value.startsWith('-') ) {
                modes.none.delete(value.slice(1));
            } else if ( value !== '' ) {
                applyMode(modes, value, 'none');
            }
        }
    }
    return lookupMode(modes, hostname) !== 'none';
}

function selectorsFromStorageSnapshot(hostname, snapshot) {
    if (
        typeof snapshot !== 'object' ||
        snapshot === null ||
        Array.isArray(snapshot)
    ) {
        throw new Error('Invalid custom-filter storage snapshot');
    }
    const selectors = [];
    for ( const key of customFilterStorageKeys(hostname) ) {
        const values = snapshot[key];
        if ( values === undefined ) { continue; }
        if (
            Array.isArray(values) === false ||
            values.some(value => typeof value !== 'string')
        ) {
            throw new Error('Invalid custom-filter selector snapshot');
        }
        selectors.push(...values);
    }
    selectors.sort();
    return {
        plainSelectors: selectors.filter(selector =>
            selector.startsWith('{') === false &&
            selector.startsWith('+js') === false
        ),
        proceduralSelectors: selectors.filter(selector =>
            selector.startsWith('{')
        ),
    };
}

async function readOriginFallbackCustomFilters() {
    const hostname = originFallbackHostname();
    if ( hostname === '' ) { return; }
    const keys = [
        settingsRestoreJournalKey,
        customFilterMutationJournalKey,
        ...customFilterModeStorageKeys,
        ...customFilterStorageKeys(hostname),
    ];
    let localState;
    try {
        localState = await chrome.storage.local.get(keys);
    } catch {
        return;
    }
    if (
        typeof localState !== 'object' ||
        localState === null ||
        Array.isArray(localState)
    ) {
        throw new Error('Invalid local-storage snapshot');
    }
    const settingsSnapshot = committedJournalSnapshot(
        localState[settingsRestoreJournalKey],
        'settings restore',
        [ 'applying', 'committingForeground', 'rollingBack' ]
    );
    const mutationSnapshot = committedJournalSnapshot(
        localState[customFilterMutationJournalKey],
        'custom-filter mutation',
        [ 'applying', 'rollingBack' ]
    );
    let authoritativeState = localState;
    if ( settingsSnapshot !== undefined ) {
        // Settings restore owns user modes/selectors, while administrator
        // policy can change independently and must remain immediately
        // authoritative even during apply or rollback.
        authoritativeState = {
            ...settingsSnapshot,
            'admin.defaultFiltering': localState['admin.defaultFiltering'],
            'admin.noFiltering': localState['admin.noFiltering'],
        };
    } else if ( mutationSnapshot !== undefined ) {
        authoritativeState = {
            ...Object.fromEntries(customFilterModeStorageKeys.map(key => [
                key,
                localState[key],
            ])),
            ...mutationSnapshot,
        };
    }
    const details = customFilteringEnabled(authoritativeState, hostname)
        ? selectorsFromStorageSnapshot(hostname, authoritativeState)
        : { plainSelectors: [], proceduralSelectors: [] };
    return {
        ok: true,
        schema: customFilterMessageSchema,
        requestId: customFilterRequestId,
        ...details,
    };
}

// matchOriginAsFallback runs this script in about:, data:, blob:, and srcdoc
// frames whose own URL has no hostname. The direct path below mirrors WebKit's
// immediate-parent authority. document.baseURI is page-controlled and must not
// select which site's custom-filter document is returned.
const customFilterHostname = document.location.hostname ||
    hostnameFromURL(document.location.origin);
const customFilterRequest = {
    what: 'injectCustomFilters',
    schema: customFilterMessageSchema,
    requestId: customFilterRequestId,
    hostname: customFilterHostname,
};
const isMainFrame = (() => {
    try {
        return self.top === self;
    } catch {
        return false;
    }
})();
let customFilterRequestInFlight;
let customFilterRequestTimedOut = false;
let customFilterLateReplyHandlerAttached = false;
let customFilterUndefinedRetryUsed = false;
let proceduralAPIRequest;

function waitForTimeout(delay) {
    return new Promise(resolve => setTimeout(resolve, delay));
}

async function waitForMessageReply(operation) {
    let timeoutId;
    try {
        return await Promise.race([
            operation.then(
                value => ({ status: 'resolved', value }),
                reason => ({ status: 'rejected', reason })
            ),
            new Promise(resolve => {
                timeoutId = setTimeout(
                    () => resolve({ status: 'timeout' }),
                    customFilterReplyTimeout
                );
            }),
        ]);
    } finally {
        clearTimeout(timeoutId);
    }
}

async function sendCustomFilterRequest() {
    if ( customFilterRequestInFlight === undefined ) {
        const operation = Promise.resolve().then(( ) =>
            chrome.runtime.sendMessage(customFilterRequest)
        );
        customFilterRequestInFlight = operation;
        customFilterLateReplyHandlerAttached = false;
    }
    const operation = customFilterRequestInFlight;
    const outcome = await waitForMessageReply(operation);
    if ( outcome.status === 'timeout' ) {
        customFilterRequestTimedOut = true;
        if ( customFilterLateReplyHandlerAttached === false ) {
            customFilterLateReplyHandlerAttached = true;
            operation.then(value => {
                if (
                    customFilterRequestInFlight === operation &&
                    customFilterRequestTimedOut &&
                    (
                        value === undefined ||
                        isValidCustomFilterAck(value, customFilterRequestId)
                    )
                ) {
                    void uBOL_cssUserStart();
                }
            }, ( ) => undefined);
        }
    } else if ( customFilterRequestInFlight === operation ) {
        customFilterRequestInFlight = undefined;
        customFilterRequestTimedOut = false;
        customFilterLateReplyHandlerAttached = false;
    }
    return outcome;
}

function isValidCustomFilterAck(details, requestId) {
    return typeof details === 'object' &&
        details !== null &&
        details.ok === true &&
        details.schema === customFilterMessageSchema &&
        details.requestId === requestId &&
        Array.isArray(details.plainSelectors) &&
        details.plainSelectors.every(selector => typeof selector === 'string') &&
        Array.isArray(details.proceduralSelectors) &&
        details.proceduralSelectors.every(selector => typeof selector === 'string');
}

async function requestCustomFilters() {
    if ( floorpOriginFallbackDocument ) {
        // MessageSender.url/origin describe the child document and can expose
        // a blob's embedded origin rather than the parent URL WebKit matched.
        // Use the bounded storage read exclusively; unavailable or ambiguous
        // parent provenance fails closed instead of switching authority.
        return readOriginFallbackCustomFilters();
    }
    let outcome = await sendCustomFilterRequest();
    if ( isCurrentDocument() === false ) { return; }
    if (
        outcome.status === 'resolved' &&
        outcome.value === undefined &&
        isMainFrame &&
        customFilterUndefinedRetryUsed === false
    ) {
        customFilterUndefinedRetryUsed = true;
        await waitForTimeout(customFilterUndefinedRetryDelay);
        if ( isCurrentDocument() === false ) { return; }
        outcome = await sendCustomFilterRequest();
    }
    if ( outcome.status !== 'resolved' ) { return; }
    if (
        isValidCustomFilterAck(
            outcome.value,
            customFilterRequestId
        ) === false
    ) {
        return;
    }
    return outcome.value;
}

async function ensureProceduralAPI() {
    if ( typeof self.ProceduralFiltererAPI === 'function' ) { return true; }
    const requestId = `${customFilterRequestId}:procedural`;
    if ( proceduralAPIRequest === undefined ) {
        const operation = Promise.resolve().then(( ) =>
            chrome.runtime.sendMessage({
                what: 'injectCSSProceduralAPI',
                schema: customFilterMessageSchema,
                requestId,
            })
        );
        proceduralAPIRequest = operation;
        self.ProceduralFiltererAPI = operation;
        operation.catch(( ) => undefined);
    }
    const operation = proceduralAPIRequest;
    const outcome = await waitForMessageReply(operation);
    if ( isCurrentDocument() === false ) { return false; }
    if ( outcome.status === 'timeout' ) { return false; }
    if (
        outcome.status !== 'resolved' ||
        isValidCustomFilterAck(outcome.value, requestId) === false ||
        typeof self.ProceduralFiltererAPI !== 'function'
    ) {
        if ( proceduralAPIRequest === operation ) {
            proceduralAPIRequest = undefined;
        }
        if ( self.ProceduralFiltererAPI === operation ) {
            self.ProceduralFiltererAPI = undefined;
        }
        return false;
    }
    return true;
}

async function uBOL_cssUserActivate() {
    if ( isCurrentDocument() === false ) { return; }
    if ( self.customFilters ) { return; }

    let details;
    try {
        details = await requestCustomFilters();
    } catch {
        return;
    }
    if ( isCurrentDocument() === false ) { return; }
    if ( Boolean(details) === false ) { return; }
    self.customFilters = details;

    try {
        if ( details.proceduralSelectors.length ) {
            if ( await ensureProceduralAPI() === false ) {
                self.customFilters = undefined;
                return;
            }
            if ( isCurrentDocument() === false ) { return; }
            self.customProceduralFiltererAPI = new self.ProceduralFiltererAPI();
            const selectors = details.proceduralSelectors.map(a => JSON.parse(a));
            const declaratives = selectors.filter(a => a.cssable);
            if ( declaratives.length !== 0 ) {
                self.customProceduralFiltererAPI.addDeclaratives(declaratives);
            }
            const procedurals = selectors.filter(a => !a.cssable);
            if ( procedurals.length !== 0 ) {
                self.customProceduralFiltererAPI.addProcedurals(procedurals);
            }
        }

        if (
            details.plainSelectors.length &&
            typeof self.cssAPI?.insert === 'function'
        ) {
            const selectors = details.plainSelectors;
            self.cssAPI.insert(
                `${selectors.join(',\n')}{display:none!important;}`
            );
        }
    } catch {
        if ( isCurrentDocument() ) {
            self.customFilters = undefined;
        }
    }
}

async function uBOL_cssUserStart() {
    if ( isCurrentDocument() === false ) { return; }
    const pendingOp = Promise.resolve(self.cssUserPendingOp)
        .catch(( ) => undefined)
        .then(uBOL_cssUserActivate);
    self.cssUserPendingOp = pendingOp.catch(( ) => undefined);
    await pendingOp;
    if ( isCurrentDocument() === false ) { return; }
    if ( Boolean(self.customFilters) === false ) { return; }
    self.removeEventListener('pagereveal', uBOL_cssUserStart);
}

await uBOL_cssUserStart();

if ( isCurrentDocument() === false ) { return; }
if ( self.customFilters ) { return; }
self.addEventListener('pagereveal', uBOL_cssUserStart);

/******************************************************************************/

})();

void 0;
