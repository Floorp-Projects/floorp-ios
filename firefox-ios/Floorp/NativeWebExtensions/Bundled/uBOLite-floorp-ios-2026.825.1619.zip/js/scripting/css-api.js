/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2025-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

(api => {
    const floorpOriginFallbackReplay =
        self.floorpCSSUserAPIIdleReplay === true;
    const documentElement = document.documentElement;
    const documentTimeOrigin = performance.timeOrigin;
    if (
        floorpOriginFallbackReplay === false &&
        typeof api === 'object' &&
        api.documentElement === documentElement &&
        api.documentTimeOrigin === documentTimeOrigin
    ) { return; }
    if ( typeof api?.pageRevealHandler === 'function' ) {
        self.removeEventListener('pagereveal', api.pageRevealHandler);
    }

    const inserted = new Set();

    const pageRevealHandler = ( ) => {
        chrome.runtime.sendMessage({
            what: 'insertCSS',
            css: Array.from(inserted).join('\n'),
        }).catch(( ) => {
        });
    };

    self.cssAPI = {
        documentElement,
        documentTimeOrigin,
        pageRevealHandler,
        insert(css) {
            chrome.runtime.sendMessage({
                what: 'insertCSS',
                css,
            }).catch(( ) => {
            });
            inserted.add(css);
        },
    };

    self.addEventListener('pagereveal', pageRevealHandler);

})(self.cssAPI);
