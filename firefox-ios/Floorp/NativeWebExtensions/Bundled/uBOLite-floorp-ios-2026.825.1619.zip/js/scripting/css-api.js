/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2025-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

(api => {
    const cssUserOwnsIdleIdentity =
        self.floorpCSSUserAPIIdleReplay === true;
    const forcedReplay = self.floorpCSSUserForceAPIReplay !== undefined;
    const documentTimeOrigin = performance.timeOrigin;
    if (
        forcedReplay === false &&
        typeof api === 'object' &&
        api.documentTimeOrigin === documentTimeOrigin &&
        api.disposed !== true
    ) {
        // The immediately following idle css-user execution owns the native
        // Document identity lease. Other retained executions still self-check.
        if ( cssUserOwnsIdleIdentity === false ) {
            void api.refreshForScriptExecution?.();
        }
        return;
    }
    api?.dispose?.();

    const messageSchema = 1;
    const operationWindow = 15000;
    const replySlice = 2000;
    const retryDelays = [ 100, 250, 500, 1000, 2000 ];
    const fallbackGeneration = {};
    const defaultOwner = {};
    const slots = new Map();
    const state = {
        documentId: undefined,
        frameId: undefined,
        verifiedRoot: undefined,
    };
    let activeTransaction;
    let currentAPI;
    let disposed = false;
    let globalQueue = Promise.resolve({ ok: true });
    let identityBarrier = Promise.resolve({ ok: true });
    let identityBarrierResolve;
    let identityOperation;
    let markerObserver;
    let observedRoot;
    let pageCacheArmed = false;
    let pageCacheEpoch = 0;
    let recoveredPageCacheEpoch = -1;
    let scriptIdentityRefresh;
    let sequence = 0;
    let slotOrder = 0;
    let suspendedBy = self.floorpCSSUserIdentityPendingRecord;

    const makeRequestId = ( ) => globalThis.crypto?.randomUUID?.() ||
        `${Date.now()}-${Math.random()}`;
    const now = ( ) => performance.now();
    const timeout = delay => new Promise(resolve => setTimeout(resolve, delay));

    async function waitForReply(operation, delay) {
        let timeoutId;
        try {
            return await Promise.race([
                operation.then(
                    value => ({ status: 'resolved', value }),
                    reason => ({ status: 'rejected', reason })
                ),
                new Promise(resolve => {
                    timeoutId = setTimeout(
                        () => resolve({ status: 'timeout' }),
                        Math.max(0, delay)
                    );
                }),
            ]);
        } finally {
            clearTimeout(timeoutId);
        }
    }

    function failure(error, ambiguous = false) {
        const result = {
            ok: false,
            schema: messageSchema,
            requestId: null,
            documentId: state.documentId ?? null,
            error,
        };
        if ( ambiguous ) { result.ambiguous = true; }
        return result;
    }

    function success(extra = {}) {
        return {
            ok: true,
            schema: messageSchema,
            requestId: null,
            documentId: state.documentId ?? null,
            ...extra,
        };
    }

    function isCurrentAPI() {
        return disposed === false &&
            self.cssAPI === currentAPI &&
            currentAPI.documentTimeOrigin === performance.timeOrigin;
    }

    function currentDocumentGeneration() {
        return typeof self.cssUserDocumentGeneration === 'object' &&
            self.cssUserDocumentGeneration !== null
            ? self.cssUserDocumentGeneration
            : fallbackGeneration;
    }

    function isCurrentGeneration(generation) {
        return isCurrentAPI() && (
            generation === fallbackGeneration ||
            self.cssUserDocumentGeneration === generation
        );
    }

    function beginIdentitySuspension(record) {
        identityBarrierResolve?.({ ok: false, superseded: true });
        const root = document.documentElement;
        for ( const slot of slots.values() ) {
            if ( state.verifiedRoot !== root ) {
                removeMarker(slot.active, state.verifiedRoot);
                removeMarker(slot.candidate, state.verifiedRoot);
            }
            removeMarker(slot.active, root);
            removeMarker(slot.candidate, root);
            if ( slot.hookActive ) {
                try { slot.hook?.suspend?.(); } catch { }
                slot.hookActive = false;
            }
        }
        suspendedBy = record;
        identityBarrier = new Promise(resolve => {
            identityBarrierResolve = resolve;
        });
    }

    function finishIdentitySuspension(result) {
        const resolve = identityBarrierResolve;
        identityBarrierResolve = undefined;
        resolve?.(result);
    }

    function validIdentityAck(response, requestId) {
        return typeof response === 'object' &&
            response !== null &&
            response.ok === true &&
            response.schema === messageSchema &&
            response.requestId === requestId &&
            typeof response.documentId === 'string' &&
            response.documentId !== '' &&
            Number.isInteger(response.frameId) &&
            response.frameId >= 0;
    }

    async function requestDocumentIdentity(deadline) {
        let attempt = 0;
        while ( isCurrentAPI() && now() < deadline ) {
            const requestId = `${makeRequestId()}:identity:${attempt}`;
            const requestRoot = document.documentElement;
            const operation = Promise.resolve().then(( ) =>
                chrome.runtime.sendMessage({
                    what: 'floorpCSSDocumentIdentity',
                    schema: messageSchema,
                    requestId,
                })
            );
            void operation.catch(( ) => undefined);
            const outcome = await waitForReply(
                operation,
                Math.min(replySlice, deadline - now())
            );
            if (
                outcome.status === 'resolved' &&
                document.documentElement === requestRoot &&
                validIdentityAck(outcome.value, requestId)
            ) {
                return { ...outcome.value, root: requestRoot };
            }
            const remaining = deadline - now();
            if ( remaining <= 0 ) { break; }
            await timeout(Math.min(
                retryDelays[Math.min(attempt, retryDelays.length - 1)],
                remaining
            ));
            attempt += 1;
        }
        return failure('CSS document identity deadline expired', true);
    }

    async function waitForIdentity(deadline) {
        while ( suspendedBy !== undefined ) {
            const remaining = deadline - now();
            if ( remaining <= 0 ) {
                return failure('CSS document identity deadline expired');
            }
            const barrier = identityBarrier;
            const outcome = await waitForReply(barrier, remaining);
            if ( outcome.status !== 'resolved' ) {
                return failure('CSS document identity deadline expired');
            }
            if ( identityBarrier !== barrier ) { continue; }
            if ( outcome.value?.ok !== true ) {
                return outcome.value ??
                    failure('CSS document identity was not verified', true);
            }
            if ( isCurrentAPI() === false ) {
                return failure('CSS API was replaced', true);
            }
            if ( suspendedBy !== undefined ) {
                return failure('CSS document identity remains suspended', true);
            }
        }
        return success();
    }

    async function freshIdentity(deadline) {
        const ready = await waitForIdentity(deadline);
        if ( ready.ok !== true ) { return ready; }
        const identity = await requestDocumentIdentity(deadline);
        if ( identity?.ok !== true || isCurrentAPI() === false ) {
            return identity?.ok === false
                ? identity
                : failure('CSS document identity changed', true);
        }
        if (
            state.documentId !== undefined &&
            (
                state.documentId !== identity.documentId ||
                state.frameId !== identity.frameId
            )
        ) {
            return failure('CSS document identity changed', true);
        }
        const previousRoot = state.verifiedRoot;
        if ( previousRoot !== undefined && previousRoot !== identity.root ) {
            for ( const slot of slots.values() ) {
                removeMarker(slot.active, previousRoot);
                removeMarker(slot.candidate, previousRoot);
            }
        }
        state.documentId = identity.documentId;
        state.frameId = identity.frameId;
        state.verifiedRoot = identity.root;
        observeMarkers();
        return identity;
    }

    function randomHex128() {
        const values = new Uint32Array(4);
        if ( typeof globalThis.crypto?.getRandomValues === 'function' ) {
            globalThis.crypto.getRandomValues(values);
            return Array.from(values, value =>
                value.toString(16).padStart(8, '0')
            ).join('');
        }
        const uuid = globalThis.crypto?.randomUUID?.()
            ?.replace(/[^a-fA-F0-9]/g, '');
        if ( typeof uuid === 'string' && uuid.length >= 32 ) {
            return uuid.slice(0, 32).toLowerCase();
        }
        throw new Error('A cryptographically random CSS scope is unavailable');
    }

    function makeScopeAttribute() {
        for ( let attempt = 0; attempt < 8; attempt += 1 ) {
            const attribute = `data-floorp-ubol-${randomHex128()}`;
            if ( document.documentElement?.hasAttribute(attribute) !== true ) {
                return attribute;
            }
        }
        throw new Error('Unable to allocate a private CSS document scope');
    }

    const allowedConditionalRules = new Set([
        'media',
        'supports',
        'container',
    ]);

    function validateRawAtRules(css) {
        let quote = '';
        let comment = false;
        let parentheses = 0;
        let brackets = 0;
        let braces = 0;
        for ( let i = 0; i < css.length; i += 1 ) {
            const char = css[i];
            const next = css[i + 1];
            if ( comment ) {
                if ( char === '*' && next === '/' ) {
                    comment = false;
                    i += 1;
                }
                continue;
            }
            if ( quote !== '' ) {
                if ( char === '\\' ) { i += 1; }
                else if ( char === quote ) { quote = ''; }
                continue;
            }
            if ( char === '/' && next === '*' ) {
                comment = true;
                i += 1;
                continue;
            }
            if ( char === '"' || char === "'" ) {
                quote = char;
                continue;
            }
            if ( char === '\\' ) { i += 1; continue; }
            if ( char === '(' ) { parentheses += 1; continue; }
            if ( char === ')' ) { parentheses -= 1; continue; }
            if ( char === '[' ) { brackets += 1; continue; }
            if ( char === ']' ) { brackets -= 1; continue; }
            if ( char === '{' ) { braces += 1; continue; }
            if ( char === '}' ) {
                braces -= 1;
                if ( braces < 0 ) {
                    throw new Error('CSS source has an unmatched closing block');
                }
                continue;
            }
            if ( char !== '@' || parentheses !== 0 || brackets !== 0 ) {
                continue;
            }
            const atRule = /^@([a-z-]+)/i.exec(css.slice(i));
            const name = atRule?.[1]?.toLowerCase();
            if ( allowedConditionalRules.has(name) === false ) {
                throw new Error(`CSS at-rule is not document-scoped: ${name}`);
            }
            let innerQuote = '';
            let innerComment = false;
            let innerParentheses = 0;
            let innerBrackets = 0;
            let foundBlock = false;
            for ( let j = i + atRule[0].length; j < css.length; j += 1 ) {
                const inner = css[j];
                const following = css[j + 1];
                if ( innerComment ) {
                    if ( inner === '*' && following === '/' ) {
                        innerComment = false;
                        j += 1;
                    }
                    continue;
                }
                if ( innerQuote !== '' ) {
                    if ( inner === '\\' ) { j += 1; }
                    else if ( inner === innerQuote ) { innerQuote = ''; }
                    continue;
                }
                if ( inner === '/' && following === '*' ) {
                    innerComment = true;
                    j += 1;
                    continue;
                }
                if ( inner === '"' || inner === "'" ) {
                    innerQuote = inner;
                    continue;
                }
                if ( inner === '\\' ) { j += 1; continue; }
                if ( inner === '(' ) { innerParentheses += 1; continue; }
                if ( inner === ')' ) { innerParentheses -= 1; continue; }
                if ( inner === '[' ) { innerBrackets += 1; continue; }
                if ( inner === ']' ) { innerBrackets -= 1; continue; }
                if ( innerParentheses !== 0 || innerBrackets !== 0 ) { continue; }
                if ( inner === ';' ) {
                    throw new Error('CSS conditional at-rule must have a block');
                }
                if ( inner === '{' ) {
                    foundBlock = true;
                    break;
                }
            }
            if ( foundBlock === false ) {
                throw new Error('CSS conditional at-rule has no block');
            }
        }
        if (
            quote !== '' || comment || parentheses !== 0 || brackets !== 0 ||
            braces !== 0
        ) {
            throw new Error('CSS source is not balanced');
        }
    }

    function firstOpeningBrace(text) {
        let quote = '';
        let comment = false;
        for ( let i = 0; i < text.length; i += 1 ) {
            const char = text[i];
            const next = text[i + 1];
            if ( comment ) {
                if ( char === '*' && next === '/' ) {
                    comment = false;
                    i += 1;
                }
                continue;
            }
            if ( quote !== '' ) {
                if ( char === '\\' ) { i += 1; }
                else if ( char === quote ) { quote = ''; }
                continue;
            }
            if ( char === '/' && next === '*' ) {
                comment = true;
                i += 1;
                continue;
            }
            if ( char === '"' || char === "'" ) {
                quote = char;
                continue;
            }
            if ( char === '\\' ) {
                i += 1;
                continue;
            }
            if ( char === '{' ) { return i; }
        }
        return -1;
    }

    function splitSelectorList(selectorText) {
        const selectors = [];
        let start = 0;
        let quote = '';
        let brackets = 0;
        let parentheses = 0;
        for ( let i = 0; i < selectorText.length; i += 1 ) {
            const char = selectorText[i];
            if ( quote !== '' ) {
                if ( char === '\\' ) { i += 1; }
                else if ( char === quote ) { quote = ''; }
                continue;
            }
            if ( char === '"' || char === "'" ) {
                quote = char;
                continue;
            }
            if ( char === '\\' ) {
                i += 1;
                continue;
            }
            if ( char === '[' ) { brackets += 1; continue; }
            if ( char === ']' ) { brackets -= 1; continue; }
            if ( char === '(' ) { parentheses += 1; continue; }
            if ( char === ')' ) { parentheses -= 1; continue; }
            if ( char !== ',' || brackets !== 0 || parentheses !== 0 ) {
                continue;
            }
            const selector = selectorText.slice(start, i).trim();
            if ( selector === '' ) {
                throw new Error('CSS selector list contains an empty branch');
            }
            selectors.push(selector);
            start = i + 1;
        }
        const selector = selectorText.slice(start).trim();
        if (
            selector === '' || quote !== '' ||
            brackets !== 0 || parentheses !== 0
        ) {
            throw new Error('CSS selector list is not balanced');
        }
        selectors.push(selector);
        return selectors;
    }

    function firstTopLevelPseudoElement(selector) {
        let quote = '';
        let brackets = 0;
        let parentheses = 0;
        for ( let i = 0; i < selector.length; i += 1 ) {
            const char = selector[i];
            if ( quote !== '' ) {
                if ( char === '\\' ) { i += 1; }
                else if ( char === quote ) { quote = ''; }
                continue;
            }
            if ( char === '"' || char === "'" ) {
                quote = char;
                continue;
            }
            if ( char === '\\' ) { i += 1; continue; }
            if ( char === '[' ) { brackets += 1; continue; }
            if ( char === ']' ) { brackets -= 1; continue; }
            if ( char === '(' ) { parentheses += 1; continue; }
            if ( char === ')' ) { parentheses -= 1; continue; }
            if ( char !== ':' || brackets !== 0 || parentheses !== 0 ) {
                continue;
            }
            if ( selector[i + 1] === ':' ) { return i; }
            const legacy = /^:(before|after|first-line|first-letter)(?=$|[.#:\[>+~\s])/i
                .exec(selector.slice(i));
            if ( legacy !== null ) { return i; }
        }
        return -1;
    }

    function scopedBranches(selector, wrapper) {
        const pseudoIndex = firstTopLevelPseudoElement(selector);
        let base = pseudoIndex === -1
            ? selector
            : selector.slice(0, pseudoIndex);
        const pseudo = pseudoIndex === -1 ? '' : selector.slice(pseudoIndex);
        const descendantUniversal = /\s$/.test(base) ||
            /(?:[>+~]|\|\|)\s*$/.test(base);
        base = base.trim();
        if ( base === '' ) { base = '*'; }
        else if ( descendantUniversal ) { base += ' *'; }
        return [
            `${wrapper} :is(${base})${pseudo}`,
            `${wrapper}:is(${base})${pseudo}`,
        ];
    }

    function conditionalRule(rule, text) {
        if ( text.startsWith('@') === false ) { return; }
        const name = /^@([a-z-]+)/i.exec(text)?.[1]?.toLowerCase();
        if (
            allowedConditionalRules.has(name) === false ||
            rule.cssRules === undefined
        ) {
            throw new Error(`CSS at-rule is not document-scoped: ${name}`);
        }
        return name;
    }

    function serializeCanonicalRules(rules) {
        const out = [];
        for ( const rule of Array.from(rules) ) {
            const text = `${rule.cssText ?? ''}`.trim();
            if ( text === '' ) {
                throw new Error('CSS parser discarded a rule');
            }
            const conditional = conditionalRule(rule, text);
            if ( conditional !== undefined ) {
                const opening = firstOpeningBrace(text);
                if ( opening === -1 ) {
                    throw new Error('CSS conditional rule has no body');
                }
                const children = serializeCanonicalRules(rule.cssRules);
                if ( children.length === 0 ) {
                    throw new Error('CSS conditional rule has no scoped rules');
                }
                out.push(
                    `${text.slice(0, opening).trim()} {\n` +
                    `${children.join('\n')}\n}`
                );
                continue;
            }
            const selectorText = `${rule.selectorText ?? ''}`.trim();
            if ( selectorText === '' ) {
                throw new Error('CSS qualified rule has no selector');
            }
            splitSelectorList(selectorText);
            if ( rule.cssRules !== undefined && rule.cssRules.length !== 0 ) {
                throw new Error('Authored CSS nesting is not supported');
            }
            const declarations = `${rule.style?.cssText ?? ''}`.trim();
            out.push(`${selectorText} { ${declarations} }`);
        }
        return out;
    }

    function serializeScopedRules(rules, wrapper, expectedBranches) {
        const out = [];
        for ( const rule of Array.from(rules) ) {
            const text = `${rule.cssText ?? ''}`.trim();
            const conditional = conditionalRule(rule, text);
            if ( conditional !== undefined ) {
                const opening = firstOpeningBrace(text);
                const children = serializeScopedRules(
                    rule.cssRules,
                    wrapper,
                    expectedBranches
                );
                out.push(
                    `${text.slice(0, opening).trim()} {\n` +
                    `${children.join('\n')}\n}`
                );
                continue;
            }
            const selectors = splitSelectorList(`${rule.selectorText ?? ''}`);
            const branches = selectors.flatMap(selector =>
                scopedBranches(selector, wrapper)
            );
            expectedBranches.push(branches.length);
            const declarations = `${rule.style?.cssText ?? ''}`.trim();
            out.push(`${branches.join(',\n')} { ${declarations} }`);
        }
        return out;
    }

    function validateScopedRoundTrip(
        rules,
        wrapper,
        expectedBranches,
        cursor
    ) {
        for ( const rule of Array.from(rules) ) {
            const text = `${rule.cssText ?? ''}`.trim();
            if ( text.startsWith('@') ) {
                conditionalRule(rule, text);
                validateScopedRoundTrip(
                    rule.cssRules,
                    wrapper,
                    expectedBranches,
                    cursor
                );
                continue;
            }
            const selectors = splitSelectorList(`${rule.selectorText ?? ''}`);
            const expected = expectedBranches[cursor.index++];
            if (
                selectors.length !== expected ||
                selectors.some(selector =>
                    (
                        selector.startsWith(`${wrapper} :is(`) === false &&
                        selector.startsWith(`${wrapper}:is(`) === false
                    ) || /:is\(\s*\)/.test(selector)
                )
            ) {
                throw new Error('CSS document scope lost a selector branch');
            }
        }
    }

    function canonicalizeCSS(css) {
        if ( typeof css !== 'string' || css.trim() === '' ) {
            throw new Error('CSS insertion requires non-empty CSS');
        }
        if ( typeof CSSStyleSheet !== 'function' ) {
            throw new Error('CSS parsing is unavailable');
        }
        // Constructable stylesheets silently discard some forbidden rules
        // (notably @import) instead of throwing. Reject every raw at-keyword
        // except the recursively scoped conditional groups before CSSOM can
        // erase evidence of a global side effect.
        validateRawAtRules(css);
        const sheet = new CSSStyleSheet();
        sheet.replaceSync(css);
        const rules = serializeCanonicalRules(sheet.cssRules);
        if ( rules.length === 0 ) {
            throw new Error('CSS parser produced no rules');
        }
        return rules.join('\n');
    }

    function makeBundle(body, intent) {
        const attr = makeScopeAttribute();
        const token = attr.slice('data-floorp-ubol-'.length);
        const canary = `--floorp-ubol-canary-${token}`;
        const canaryValue = `floorp-${randomHex128()}`;
        const source = new CSSStyleSheet();
        source.replaceSync(body);
        const expectedBranches = [];
        const wrapper = `:where(:root[${attr}])`;
        const scoped = serializeScopedRules(
            source.cssRules,
            wrapper,
            expectedBranches
        );
        const exactCSS = `${wrapper} {\n` +
            `${canary}: ${canaryValue} !important;\n` +
            `}\n${scoped.join('\n')}`;
        const parsed = new CSSStyleSheet();
        parsed.replaceSync(exactCSS);
        const canaryRule = parsed.cssRules[0];
        if (
            parsed.cssRules.length < 2 ||
            `${canaryRule?.selectorText ?? ''}` !== wrapper ||
            (
                canaryRule?.cssRules !== undefined &&
                canaryRule.cssRules.length !== 0
            ) ||
            canaryRule.style?.getPropertyValue(canary)?.trim() !== canaryValue ||
            canaryRule.style?.getPropertyPriority?.(canary) !== 'important'
        ) {
            throw new Error('CSS document canary was not accepted');
        }
        const cursor = { index: 0 };
        validateScopedRoundTrip(
            Array.from(parsed.cssRules).slice(1),
            wrapper,
            expectedBranches,
            cursor
        );
        if ( cursor.index !== expectedBranches.length ) {
            throw new Error('CSS document scope discarded scoped rules');
        }
        return {
            attr,
            canary,
            canaryValue,
            exactCSS,
            fingerprint: body,
            intent,
        };
    }

    function laneRank(lane, generation) {
        if ( lane === 'preview' ) { return 2; }
        if ( lane === 'custom' || generation !== fallbackGeneration ) {
            return 1;
        }
        return 0;
    }

    function slotFor(owner, generation, lane, create = true) {
        let slot = slots.get(owner);
        if ( slot !== undefined ) {
            if ( slot.generation !== generation ) {
                throw new Error('CSS owner generation changed');
            }
            return slot;
        }
        if ( create === false ) { return; }
        slot = {
            active: null,
            activeIntent: -1,
            candidate: null,
            desired: new Map(),
            dirty: new Set(),
            generation,
            hook: undefined,
            hookActive: false,
            intent: 0,
            lane,
            markerSuppressed: false,
            order: slotOrder++,
            owner,
            rank: laneRank(lane, generation),
            wantsActivation: false,
        };
        slots.set(owner, slot);
        return slot;
    }

    function orderedSlots() {
        return Array.from(slots.values()).sort((a, b) =>
            a.rank - b.rank || a.order - b.order
        );
    }

    function follows(candidate, changed) {
        return candidate.rank > changed.rank ||
            candidate.rank === changed.rank && candidate.order > changed.order;
    }

    function desiredBody(slot) {
        return Array.from(slot.desired.values())
            .sort((a, b) => a.sequence - b.sequence)
            .map(entry => entry.css)
            .join('\n');
    }

    function removeMarker(bundle, root = state.verifiedRoot) {
        if ( bundle?.attr === undefined ) { return; }
        if ( root?.hasAttribute?.(bundle.attr) ) {
            root.removeAttribute(bundle.attr);
        }
    }

    function repairSlotMarker(slot) {
        if (
            slot.markerSuppressed ||
            slot.active?.attr === undefined ||
            suspendedBy !== undefined ||
            state.verifiedRoot !== document.documentElement ||
            isCurrentAPI() === false
        ) { return; }
        const root = document.documentElement;
        if ( root.hasAttribute(slot.active.attr) === false ) {
            root.setAttribute(slot.active.attr, '');
        }
    }

    function repairMarkers() {
        if ( suspendedBy !== undefined || isCurrentAPI() === false ) { return; }
        if (
            state.documentId !== undefined &&
            state.verifiedRoot !== document.documentElement
        ) {
            void currentAPI.refreshForScriptExecution();
            return;
        }
        for ( const slot of slots.values() ) { repairSlotMarker(slot); }
    }

    function resumeActiveHooks() {
        const resumedSlots = [];
        for ( const slot of slots.values() ) {
            if (
                slot.active === null ||
                slot.hook === undefined ||
                slot.hookActive
            ) { continue; }
            try {
                slot.hook.activatePrepared?.();
                slot.hookActive = true;
                resumedSlots.push(slot);
            } catch {
                try { slot.hook?.deactivate?.(); } catch { }
                for ( const resumedSlot of resumedSlots.reverse() ) {
                    try { resumedSlot.hook?.deactivate?.(); } catch { }
                    resumedSlot.hookActive = false;
                }
                for ( const activeSlot of slots.values() ) {
                    if ( activeSlot.active === null ) { continue; }
                    activeSlot.markerSuppressed = true;
                    activeSlot.hookActive = false;
                    removeMarker(activeSlot.active, document.documentElement);
                }
                return false;
            }
        }
        for ( const slot of slots.values() ) {
            if ( slot.active !== null ) { slot.markerSuppressed = false; }
        }
        return true;
    }

    function candidateCanaryApplied(bundle, root) {
        if ( typeof getComputedStyle !== 'function' ) { return false; }
        try {
            return getComputedStyle(root)
                .getPropertyValue(bundle.canary)
                .trim() === bundle.canaryValue;
        } catch {
            return false;
        }
    }

    async function waitForCandidateCanary(
        slot,
        bundle,
        identity,
        generation,
        intent,
        deadline
    ) {
        const root = identity.root;
        const settleDeadline = Math.min(deadline, now() + 500);
        for (;;) {
            if (
                isCurrentAPI() === false ||
                isCurrentGeneration(generation) === false ||
                suspendedBy !== undefined ||
                slot.candidate !== bundle ||
                slot.intent !== intent ||
                state.documentId !== identity.documentId ||
                state.frameId !== identity.frameId ||
                state.verifiedRoot !== root ||
                document.documentElement !== root ||
                now() >= deadline
            ) {
                return failure(
                    'CSS candidate lost its Document authority',
                    true
                );
            }
            if ( root.hasAttribute(bundle.attr) === false ) {
                root.setAttribute(bundle.attr, '');
            }
            if ( candidateCanaryApplied(bundle, root) ) { return success(); }
            const remaining = settleDeadline - now();
            if ( remaining <= 0 ) {
                return failure('CSS candidate canary was not applied');
            }
            await timeout(Math.min(25, remaining));
        }
    }

    function observeMarkers() {
        if ( markerObserver === undefined ) { return; }
        markerObserver.disconnect();
        markerObserver.observe(document, { childList: true });
        observedRoot = document.documentElement;
        const attributes = orderedSlots()
            .map(slot => slot.active?.attr)
            .filter(Boolean);
        if ( observedRoot !== null && attributes.length !== 0 ) {
            markerObserver.observe(observedRoot, {
                attributes: true,
                attributeFilter: attributes,
            });
        }
    }

    function validNativeAck(response, requestId, ensured = false) {
        return typeof response === 'object' &&
            response !== null &&
            response.ok === true &&
            response.schema === messageSchema &&
            response.requestId === requestId &&
            response.documentId === state.documentId &&
            response.frameId === state.frameId &&
            (ensured === false || response.ensured === true);
    }

    async function sendNative(message, deadline) {
        const remaining = deadline - now();
        if ( remaining <= 0 ) {
            return { outcome: { status: 'timeout' } };
        }
        const operation = Promise.resolve().then(( ) =>
            chrome.runtime.sendMessage(message)
        );
        void operation.catch(( ) => undefined);
        return {
            operation,
            outcome: await waitForReply(operation, remaining),
        };
    }

    async function ensureBundle(bundle, deadline) {
        let attempt = 0;
        while ( isCurrentAPI() && now() < deadline ) {
            const requestId = `${makeRequestId()}:ensure:${attempt}`;
            const sent = await sendNative({
                what: 'insertCSS',
                schema: messageSchema,
                requestId,
                css: bundle.exactCSS,
                scopeAttribute: bundle.attr,
                scopeCanary: bundle.canary,
                scopeCanaryValue: bundle.canaryValue,
                expectedDocumentId: state.documentId,
                expectedFrameId: state.frameId,
            }, deadline);
            const { outcome } = sent;
            if (
                outcome.status === 'resolved' &&
                validNativeAck(outcome.value, requestId, true)
            ) {
                return outcome.value;
            }
            const requestBoundNegative =
                outcome.status === 'resolved' &&
                typeof outcome.value === 'object' &&
                outcome.value !== null &&
                outcome.value.schema === messageSchema &&
                outcome.value.requestId === requestId &&
                outcome.value.documentId === state.documentId &&
                outcome.value.frameId === state.frameId &&
                outcome.value.ok === false &&
                outcome.value.ambiguous !== true;
            if ( requestBoundNegative === false ) {
                // Its private marker has never been published. Any late native
                // success is inert and is retained only for best-effort GC.
                bundle.pendingOperation = sent.operation;
                return failure(
                    outcome.status === 'rejected'
                        ? `${outcome.reason}`
                        : outcome.value?.error ||
                            'CSS ensure acknowledgement is ambiguous',
                    true
                );
            }
            const remaining = deadline - now();
            if ( remaining <= 0 ) { break; }
            await timeout(Math.min(
                retryDelays[Math.min(attempt, retryDelays.length - 1)],
                remaining
            ));
            attempt += 1;
        }
        return failure('CSS ensure deadline expired');
    }

    async function removeBundle(bundle, deadline) {
        if ( bundle?.exactCSS === undefined ) { return success(); }
        const requestId = `${makeRequestId()}:remove`;
        const { outcome } = await sendNative({
            what: 'removeCSS',
            schema: messageSchema,
            requestId,
            css: bundle.exactCSS,
            scopeAttribute: bundle.attr,
            scopeCanary: bundle.canary,
            scopeCanaryValue: bundle.canaryValue,
            expectedDocumentId: state.documentId,
            expectedFrameId: state.frameId,
        }, deadline);
        if (
            outcome.status === 'resolved' &&
            validNativeAck(outcome.value, requestId)
        ) {
            return outcome.value;
        }
        return failure(
            outcome.status === 'rejected'
                ? `${outcome.reason}`
                : outcome.value?.error ||
                    'CSS removal acknowledgement is ambiguous',
            outcome.status !== 'resolved' ||
                outcome.value?.ambiguous === true
        );
    }

    function deactivateSlot(slot) {
        slot.intent += 1;
        slot.markerSuppressed = true;
        if ( state.verifiedRoot !== document.documentElement ) {
            removeMarker(slot.candidate, state.verifiedRoot);
            removeMarker(slot.active, state.verifiedRoot);
        }
        removeMarker(slot.candidate, document.documentElement);
        removeMarker(slot.active, document.documentElement);
        if ( slot.hookActive ) {
            try { slot.hook?.deactivate?.(); } catch { }
            slot.hookActive = false;
        }
    }

    async function cleanupDirty(slot, deadline) {
        for ( const bundle of Array.from(slot.dirty) ) {
            if ( now() >= deadline ) { return; }
            if ( bundle.pendingOperation !== undefined ) {
                const pending = await waitForReply(
                    bundle.pendingOperation,
                    deadline - now()
                );
                if ( pending.status === 'timeout' ) { return; }
                bundle.pendingOperation = undefined;
            }
            const removed = await removeBundle(bundle, deadline);
            if ( removed?.ok === true ) { slot.dirty.delete(bundle); }
        }
    }

    async function reconcileSlot(slot, deadline, force = false) {
        while ( isCurrentAPI() && now() < deadline ) {
            const generation = slot.generation;
            if ( isCurrentGeneration(generation) === false ) {
                return failure('CSS owner generation changed');
            }
            const intent = slot.intent;
            const body = desiredBody(slot);
            const needsActivation = slot.wantsActivation || body !== '';
            if ( needsActivation === false ) {
                const old = slot.active;
                deactivateSlot(slot);
                slot.active = null;
                slot.candidate = null;
                if ( old !== null ) { slot.dirty.add(old); }
                await cleanupDirty(slot, deadline);
                if ( slot.dirty.size !== 0 ) {
                    return failure('CSS owner cleanup is incomplete', true);
                }
                if ( slot.desired.size === 0 && slot.wantsActivation === false ) {
                    slots.delete(slot.owner);
                }
                return success();
            }

            const identity = await freshIdentity(deadline);
            if ( identity?.ok !== true ) { return identity; }
            const root = identity.root;
            if (
                force === false &&
                slot.markerSuppressed === false &&
                slot.activeIntent >= intent &&
                slot.active?.fingerprint === (body || ':root{}') &&
                root?.hasAttribute(slot.active.attr) &&
                slot.hook?.needsActivation?.() !== true
            ) {
                return success({ fingerprint: body });
            }

            let candidate;
            try {
                candidate = makeBundle(body || ':root{}', intent);
            } catch(reason) {
                return failure(`${reason}`);
            }
            slot.candidate = candidate;
            const ensured = await ensureBundle(candidate, deadline);
            if ( ensured?.ok !== true ) {
                slot.dirty.add(candidate);
                slot.candidate = null;
                void cleanupDirty(slot, deadline);
                return ensured;
            }
            const confirmed = await requestDocumentIdentity(deadline);
            if (
                confirmed?.ok !== true ||
                confirmed.documentId !== state.documentId ||
                confirmed.frameId !== state.frameId ||
                confirmed.root !== root ||
                document.documentElement !== root ||
                isCurrentAPI() === false ||
                isCurrentGeneration(generation) === false ||
                slot.intent !== intent ||
                now() >= deadline
            ) {
                slot.dirty.add(candidate);
                slot.candidate = null;
                void cleanupDirty(slot, deadline);
                if ( slot.intent !== intent && now() < deadline ) {
                    force = true;
                    continue;
                }
                return failure(
                    confirmed?.error ||
                        'CSS candidate lost its Document authority',
                    true
                );
            }

            const old = slot.active;
            // Publish the private candidate marker only long enough to prove
            // that WebKit applied this exact USER-origin sheet. Keep the old
            // marker live until the canary and activation hook both succeed.
            root.setAttribute(candidate.attr, '');
            const canary = await waitForCandidateCanary(
                slot,
                candidate,
                confirmed,
                generation,
                intent,
                deadline
            );
            if ( canary?.ok !== true ) {
                removeMarker(candidate, root);
                slot.dirty.add(candidate);
                slot.candidate = null;
                void cleanupDirty(slot, deadline);
                return canary;
            }
            if (
                slot.hookActive === false ||
                slot.hook?.needsActivation?.() === true
            ) {
                try {
                    slot.hook?.activatePrepared?.();
                    slot.hookActive = slot.hook !== undefined;
                } catch(reason) {
                    removeMarker(candidate, root);
                    slot.dirty.add(candidate);
                    slot.candidate = null;
                    slot.markerSuppressed = old === null;
                    try { slot.hook?.deactivate?.(); } catch { }
                    slot.hookActive = false;
                    void cleanupDirty(slot, deadline);
                    return failure(`${reason}`);
                }
            }
            removeMarker(old, root);
            slot.active = candidate;
            slot.activeIntent = intent;
            slot.candidate = null;
            slot.markerSuppressed = false;
            observeMarkers();
            repairSlotMarker(slot);
            if ( old !== null ) { slot.dirty.add(old); }
            // Old payloads are already inert because their marker was removed
            // in the commit task. Cleanup is performance GC and must not turn a
            // successfully published candidate into a deadline failure.
            void cleanupDirty(slot, now() + operationWindow);
            return success({ fingerprint: body });
        }
        return failure('CSS activation deadline expired');
    }

    async function reconcileWithFollowers(slot, deadline, force) {
        const result = await reconcileSlot(slot, deadline, force);
        if ( result?.ok !== true ) { return result; }
        for ( const follower of orderedSlots() ) {
            if (
                follower === slot ||
                follows(follower, slot) === false ||
                follower.active === null
            ) { continue; }
            const replayed = await reconcileSlot(follower, deadline, true);
            if ( replayed?.ok === true ) { continue; }
            deactivateSlot(follower);
            return replayed;
        }
        return result;
    }

    function scheduleSlot(slot, deadline, force = false) {
        const requiredIntent = slot.intent;
        const operation = globalQueue
            .catch(( ) => success())
            .then(async ( ) => {
                if ( now() >= deadline ) {
                    return failure('CSS caller deadline expired');
                }
                const result = await reconcileWithFollowers(
                    slot,
                    deadline,
                    force
                );
                if ( result?.ok !== true ) { return result; }
                if (
                    slots.get(slot.owner) === slot &&
                    slot.activeIntent < requiredIntent &&
                    (slot.desired.size !== 0 || slot.wantsActivation)
                ) {
                    return failure('CSS caller mutation was not committed');
                }
                return result;
            });
        globalQueue = operation.catch(reason => failure(`${reason}`));
        void operation.catch(( ) => undefined);
        return operation;
    }

    function operationContext(options = {}) {
        const transaction = activeTransaction;
        const generation = typeof options.generation === 'object' &&
            options.generation !== null
            ? options.generation
            : transaction?.generation ?? fallbackGeneration;
        const owner = typeof options.owner === 'object' && options.owner !== null
            ? options.owner
            : transaction?.owner ?? defaultOwner;
        const lane = typeof options.lane === 'string'
            ? options.lane
            : transaction?.lane ??
                (generation === fallbackGeneration ? 'base' : 'custom');
        const deadline = Number.isFinite(options.deadline)
            ? options.deadline
            : Number.isFinite(transaction?.deadline)
                ? transaction.deadline
                : now() + operationWindow;
        return { deadline, generation, lane, owner, transaction };
    }

    function addDesiredCSS(slot, canonical, cssSequence) {
        if ( slot.desired.has(canonical) ) { return false; }
        slot.desired.set(canonical, { css: canonical, sequence: cssSequence });
        slot.intent += 1;
        return true;
    }

    function insert(css, options = {}) {
        let canonical;
        try {
            canonical = canonicalizeCSS(css);
        } catch(reason) {
            return Promise.resolve(failure(`${reason}`));
        }
        const context = operationContext(options);
        if ( isCurrentGeneration(context.generation) === false ) {
            return Promise.resolve(failure('CSS owner generation changed'));
        }
        const cssSequence = sequence++;
        if (
            context.transaction !== undefined &&
            context.transaction.owner === context.owner &&
            context.transaction.generation === context.generation &&
            context.transaction.closed === false
        ) {
            context.transaction.staged.push({
                css: canonical,
                sequence: cssSequence,
            });
            return Promise.resolve(success({ staged: true }));
        }
        let slot;
        try {
            slot = slotFor(
                context.owner,
                context.generation,
                context.lane
            );
        } catch(reason) {
            return Promise.resolve(failure(`${reason}`));
        }
        addDesiredCSS(slot, canonical, cssSequence);
        return scheduleSlot(slot, context.deadline);
    }

    function suppressAllMarkers() {
        const root = document.documentElement;
        for ( const slot of slots.values() ) {
            slot.markerSuppressed = true;
            if ( state.verifiedRoot !== root ) {
                removeMarker(slot.active, state.verifiedRoot);
                removeMarker(slot.candidate, state.verifiedRoot);
            }
            removeMarker(slot.active, root);
            removeMarker(slot.candidate, root);
        }
    }

    function pageHideHandler(event) {
        suppressAllMarkers();
        if ( event?.persisted === true ) {
            pageCacheArmed = true;
            pageCacheEpoch += 1;
            return;
        }
        const deadline = now() + operationWindow;
        for ( const slot of slots.values() ) {
            if ( slot.hookActive ) {
                try { slot.hook?.deactivate?.(); } catch { }
                slot.hookActive = false;
            }
            for ( const bundle of [ slot.candidate, slot.active, ...slot.dirty ]) {
                if ( bundle === null || bundle === undefined ) { continue; }
                void removeBundle(bundle, deadline);
            }
        }
    }

    function pageRevealHandler(event) {
        const pageShow = event?.type === 'pageshow';
        if (
            event?.type !== 'pagereveal' &&
            (pageShow === false || event?.persisted !== true)
        ) { return; }
        if ( pageCacheArmed ) {
            pageCacheArmed = false;
            recoveredPageCacheEpoch = pageCacheEpoch;
        } else if (
            pageShow ||
            pageCacheEpoch !== 0 && recoveredPageCacheEpoch === pageCacheEpoch
        ) {
            return;
        }
        suppressAllMarkers();
        const ordered = orderedSlots().filter(slot =>
            slot.desired.size !== 0 || slot.wantsActivation
        );
        if ( ordered.length === 0 ) { return; }
        void scheduleSlot(ordered[0], now() + operationWindow, true);
    }

    currentAPI = {
        documentTimeOrigin,
        get disposed() { return disposed; },
        get documentId() { return state.documentId; },
        get frameId() { return state.frameId; },
        currentDocumentGeneration,
        bindDocumentId(documentId, frameId) {
            if (
                typeof documentId !== 'string' || documentId === '' ||
                Number.isInteger(frameId) === false || frameId < 0
            ) { return false; }
            if (
                state.documentId !== undefined &&
                (state.documentId !== documentId || state.frameId !== frameId)
            ) { return false; }
            state.documentId = documentId;
            state.frameId = frameId;
            state.verifiedRoot = document.documentElement;
            observeMarkers();
            repairMarkers();
            return true;
        },
        suspendForIdentity(record) {
            beginIdentitySuspension(record);
            markerObserver?.disconnect();
            observedRoot = undefined;
        },
        cancelIdentity(record) {
            if ( suspendedBy !== record ) { return; }
            // An unverified or failed identity must never republish the active
            // commit marker. A later script execution obtains a fresh native
            // acknowledgement and resumes or replaces this API.
            finishIdentitySuspension(failure('CSS identity was cancelled'));
            suspendedBy = {};
        },
        resumeForIdentity(record, documentId, frameId) {
            if (
                suspendedBy !== record ||
                self.floorpCSSUserIdentityPendingRecord !== record ||
                this.bindDocumentId(documentId, frameId) === false
            ) { return false; }
            if ( resumeActiveHooks() === false ) {
                const result = failure('CSS activation hook could not resume');
                // Keep every operation behind the resolved failure barrier
                // until a replacement API has been installed. Otherwise an
                // overlapping stock/custom insertion could publish markers
                // after a partially resumed procedural hook failed.
                suspendedBy = { failedHookResume: true };
                finishIdentitySuspension(result);
                observeMarkers();
                return false;
            }
            suspendedBy = undefined;
            self.floorpCSSUserIdentityPendingRecord = undefined;
            finishIdentitySuspension(success());
            observeMarkers();
            repairMarkers();
            return true;
        },
        refreshDocumentIdentity(deadline = now() + operationWindow) {
            return requestDocumentIdentity(deadline);
        },
        refreshForScriptExecution() {
            const pendingRecord = self.floorpCSSUserIdentityPendingRecord;
            if (
                pendingRecord !== undefined &&
                pendingRecord === self.floorpCSSUserLatestExecutionRecord &&
                suspendedBy === pendingRecord
            ) {
                return identityBarrier;
            }
            if ( scriptIdentityRefresh !== undefined ) {
                return scriptIdentityRefresh;
            }
            const record = { deadline: now() + operationWindow };
            self.floorpCSSUserIdentityPendingRecord = record;
            this.suspendForIdentity(record);
            scriptIdentityRefresh = requestDocumentIdentity(record.deadline)
                .then(async identity => {
                    if (
                        identity?.ok !== true ||
                        self.cssAPI !== currentAPI ||
                        self.floorpCSSUserIdentityPendingRecord !== record
                    ) { return identity; }
                    if ( this.resumeForIdentity(
                        record,
                        identity.documentId,
                        identity.frameId
                    ) ) { return identity; }
                    self.floorpCSSUserIdentityPendingRecord = record;
                    self.floorpCSSUserForceAPIReplay = record;
                    const requestId = `${makeRequestId()}:refresh`;
                    const operation = Promise.resolve().then(( ) =>
                        chrome.runtime.sendMessage({
                            what: 'injectCSSProceduralAPI',
                            schema: messageSchema,
                            requestId,
                        })
                    );
                    void operation.catch(( ) => undefined);
                    const outcome = await waitForReply(
                        operation,
                        record.deadline - now()
                    );
                    if (
                        outcome.status !== 'resolved' ||
                        outcome.value?.ok !== true ||
                        outcome.value.schema !== messageSchema ||
                        outcome.value.requestId !== requestId ||
                        typeof self.cssAPI?.resumeForIdentity !== 'function' ||
                        self.cssAPI.resumeForIdentity(
                            record,
                            identity.documentId,
                            identity.frameId
                        ) === false
                    ) {
                        return failure(
                            outcome.value?.error ||
                                'CSS API replacement failed',
                            outcome.status !== 'resolved'
                        );
                    }
                    return identity;
                })
                .finally(( ) => {
                    if ( self.floorpCSSUserForceAPIReplay === record ) {
                        self.floorpCSSUserForceAPIReplay = undefined;
                    }
                    if (
                        self.floorpCSSUserIdentityPendingRecord === record &&
                        self.cssAPI === currentAPI
                    ) {
                        self.floorpCSSUserIdentityPendingRecord = undefined;
                        currentAPI.cancelIdentity(record);
                    }
                    scriptIdentityRefresh = undefined;
                });
            void scriptIdentityRefresh.catch(( ) => undefined);
            return scriptIdentityRefresh;
        },
        ensureDocumentIdentity(deadline = now() + operationWindow) {
            if ( identityOperation !== undefined ) { return identityOperation; }
            identityOperation = freshIdentity(deadline).finally(( ) => {
                identityOperation = undefined;
            });
            return identityOperation;
        },
        beginInsertionTransaction(
            generation,
            deadline,
            owner = generation,
            lane = generation === fallbackGeneration ? 'base' : 'custom'
        ) {
            if (
                activeTransaction !== undefined ||
                isCurrentGeneration(generation) === false ||
                Number.isFinite(deadline) === false ||
                typeof owner !== 'object' || owner === null
            ) {
                throw new Error('CSS insertion transaction cannot begin');
            }
            activeTransaction = {
                closed: false,
                deadline,
                generation,
                lane,
                owner,
                staged: [],
            };
            return activeTransaction;
        },
        finishInsertionTransaction(transaction) {
            if ( activeTransaction !== transaction ) {
                throw new Error('CSS insertion transaction does not match');
            }
            activeTransaction = undefined;
            transaction.closed = true;
            const slot = slotFor(
                transaction.owner,
                transaction.generation,
                transaction.lane
            );
            for ( const entry of transaction.staged ) {
                addDesiredCSS(slot, entry.css, entry.sequence);
            }
            transaction.staged.length = 0;
            void scheduleSlot(slot, transaction.deadline);
            return transaction;
        },
        rollbackInsertionTransaction(transaction) {
            if ( activeTransaction === transaction ) {
                activeTransaction = undefined;
            }
            transaction.closed = true;
            transaction.staged.length = 0;
            return success();
        },
        registerOwnerHook(
            owner,
            generation,
            hook,
            lane = generation === fallbackGeneration ? 'base' : 'custom'
        ) {
            const slot = slotFor(owner, generation, lane);
            if ( slot.hook !== undefined && slot.hook !== hook ) {
                throw new Error('CSS owner already has an activation hook');
            }
            slot.hook = hook;
            return success();
        },
        unregisterOwnerHook(owner, generation, hook) {
            const slot = slotFor(owner, generation, undefined, false);
            if ( slot === undefined || slot.hook !== hook ) {
                return success();
            }
            if ( slot.hookActive ) {
                try { slot.hook.deactivate?.(); } catch { }
                slot.hookActive = false;
            }
            slot.hook = undefined;
            if (
                slot.active === null &&
                slot.candidate === null &&
                slot.desired.size === 0 &&
                slot.dirty.size === 0 &&
                slot.wantsActivation === false
            ) {
                slots.delete(owner);
            }
            return success();
        },
        activateOwner(owner, generation, options = {}) {
            const slot = slotFor(
                owner,
                generation,
                options.lane ??
                    (generation === fallbackGeneration ? 'base' : 'custom')
            );
            if ( slot.wantsActivation === false ) {
                slot.wantsActivation = true;
                slot.intent += 1;
            }
            if (
                activeTransaction?.owner === owner &&
                activeTransaction.generation === generation
            ) { return Promise.resolve(success({ staged: true })); }
            return scheduleSlot(
                slot,
                Number.isFinite(options.deadline)
                    ? options.deadline
                    : now() + operationWindow
            );
        },
        insert,
        async commit(
            generation = currentDocumentGeneration(),
            owner = generation,
            deadline = now() + operationWindow
        ) {
            const slot = slotFor(owner, generation, undefined, false);
            if ( slot === undefined ) {
                return success({ committed: true });
            }
            const result = await scheduleSlot(slot, deadline);
            if ( result?.ok !== true ) { return result; }
            const body = desiredBody(slot);
            const fingerprint = body || ':root{}';
            const committed = slot.active?.fingerprint === fingerprint &&
                slot.markerSuppressed === false &&
                state.verifiedRoot === document.documentElement &&
                state.verifiedRoot?.hasAttribute(slot.active.attr) === true &&
                now() < deadline;
            return committed
                ? success({ committed: true, fingerprint: body })
                : failure('CSS owner did not commit');
        },
        async forgetOwner(
            owner,
            generation = currentDocumentGeneration(),
            deadline = now() + operationWindow
        ) {
            const slot = slotFor(owner, generation, undefined, false);
            if ( slot === undefined ) {
                const recovery = globalQueue
                    .catch(( ) => success())
                    .then(async ( ) => {
                        for ( const staleSlot of Array.from(slots.values()) ) {
                            if ( staleSlot.dirty.size === 0 ) { continue; }
                            await cleanupDirty(staleSlot, deadline);
                            if ( staleSlot.dirty.size !== 0 ) {
                                return failure(
                                    'Prior CSS cleanup did not complete',
                                    true
                                );
                            }
                            if (
                                staleSlot.active === null &&
                                staleSlot.candidate === null &&
                                staleSlot.desired.size === 0 &&
                                staleSlot.wantsActivation === false
                            ) {
                                slots.delete(staleSlot.owner);
                            }
                        }
                        return success();
                    });
                globalQueue = recovery.catch(reason => failure(`${reason}`));
                const queued = await waitForReply(recovery, deadline - now());
                if ( queued.status !== 'resolved' ) {
                    return failure('Prior CSS cleanup is still pending', true);
                }
                return queued.value?.ok === true
                    ? success()
                    : queued.value ??
                        failure('Prior CSS cleanup did not complete', true);
            }
            deactivateSlot(slot);
            slot.desired.clear();
            slot.wantsActivation = false;
            for ( const bundle of [ slot.candidate, slot.active ] ) {
                if ( bundle !== null ) { slot.dirty.add(bundle); }
            }
            slot.candidate = null;
            slot.active = null;
            const cleanup = globalQueue
                .catch(( ) => success())
                .then(async ( ) => {
                    await cleanupDirty(slot, deadline);
                    if ( slot.dirty.size !== 0 ) {
                        return failure(
                            'CSS owner cleanup is incomplete',
                            true
                        );
                    }
                    if (
                        slot.desired.size === 0 &&
                        slot.wantsActivation === false
                    ) {
                        slots.delete(owner);
                    }
                    return success();
                });
            globalQueue = cleanup.catch(reason => failure(`${reason}`));
            const result = await cleanup;
            return result?.ok === true ? success() : result;
        },
        beginRecoveryWindow() {
            return globalQueue;
        },
        async waitForRecovery() {
            return globalQueue;
        },
        async replay(generation, options = {}) {
            const deadline = Number.isFinite(options.deadline)
                ? options.deadline
                : now() + operationWindow;
            const selected = orderedSlots().filter(slot =>
                isCurrentGeneration(slot.generation) &&
                (options.owner === undefined || slot.owner === options.owner) &&
                (options.excludeOwner === undefined ||
                    slot.owner !== options.excludeOwner)
            );
            let result = success();
            for ( const slot of selected ) {
                result = await scheduleSlot(
                    slot,
                    deadline,
                    options.force === true
                );
                if ( result?.ok !== true ) { return result; }
            }
            return result;
        },
        dispose() {
            if ( disposed ) { return; }
            disposed = true;
            self.removeEventListener('pagehide', pageHideHandler);
            self.removeEventListener('pagereveal', pageRevealHandler);
            self.removeEventListener('pageshow', pageRevealHandler);
            markerObserver?.disconnect();
            markerObserver = undefined;
            suppressAllMarkers();
            for ( const slot of slots.values() ) {
                // A suspended procedural hook still owns selectors, node
                // tokens and timers even though hookActive is false.
                try { slot.hook?.deactivate?.(); } catch { }
                slot.hookActive = false;
                slot.intent += 1;
            }
            suspendedBy = {};
            finishIdentitySuspension(failure('CSS API was replaced', true));
        },
    };

    self.cssAPI = currentAPI;
    if ( typeof MutationObserver === 'function' ) {
        markerObserver = new MutationObserver(( ) => {
            if ( document.documentElement !== observedRoot ) {
                void currentAPI.refreshForScriptExecution();
                return;
            }
            repairMarkers();
        });
        observeMarkers();
    }
    self.addEventListener('pagehide', pageHideHandler);
    self.addEventListener('pagereveal', pageRevealHandler);
    self.addEventListener('pageshow', pageRevealHandler);

})(self.cssAPI);

void 0;
