'use strict';

// WebKit can run document_start in a transient about:blank wrapper before an
// iframe commits its final origin-fallback document. Mark the document_idle
// registration so css-user can replay only those hostname-less documents.
self.floorpCSSUserIdleReplay = true;
