/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import {
    assertSuccessfulMessageResponse,
    browser,
    runtime,
    sendMessage,
} from './ext.js';
import { dom, qs$ } from './dom.js';
import { i18n$ } from './i18n.js';
import punycode from './punycode.js';

/******************************************************************************/

const popupPanelData = {};
const  currentTab = {};
const tabURL = new URL(runtime.getURL('/'));

let popupMutationTail = Promise.resolve();
let popupMutationError;
let popupMutationRevision = 0;
let popupInitialization;
const pendingPopupRoutes = new Set();
let popupRouteError;

function queuePopupMutation(operation) {
    popupMutationRevision += 1;
    const current = popupMutationTail
        .catch(( ) => undefined)
        .then(operation);
    popupMutationTail = current.catch(reason => {
        popupMutationError ??= reason;
    });
    return current;
}

async function settlePopupMutations() {
    for (;;) {
        const pending = popupMutationTail;
        await pending;
        if ( pending === popupMutationTail ) { return; }
    }
}

function trackPopupRoute(route) {
    pendingPopupRoutes.add(route);
    void route.then(
        ( ) => {
            pendingPopupRoutes.delete(route);
        },
        reason => {
            popupRouteError ??= reason;
            pendingPopupRoutes.delete(route);
        }
    );
    return route;
}

async function settlePopupRoutes() {
    for (;;) {
        const pending = Array.from(pendingPopupRoutes);
        if ( pending.length === 0 ) { break; }
        await Promise.allSettled(pending);
    }
    const earlierRouteError = popupRouteError;
    popupRouteError = undefined;
    if ( earlierRouteError !== undefined ) {
        throw earlierRouteError;
    }
}

/******************************************************************************/

function renderAdminRules() {
    const { disabledFeatures: forbid = [] } = popupPanelData;
    if ( forbid.length === 0 ) { return; }
    dom.body.dataset.forbid = forbid.join(' ');
}

/******************************************************************************/

const BLOCKING_MODE_MAX = 3;

function showRuntimeError(reason) {
    const message = reason instanceof Error ? reason.message : `${reason}`;
    dom.text('#runtimeError', message);
}

function clearRuntimeError() {
    dom.text('#runtimeError', '');
}

function capturePopupRequest(request) {
    return Promise.resolve(request).then(
        value => ({ value }),
        error => ({ error })
    );
}

async function setFilteringMode(level, commit = false) {
    const modeSlider = qs$('.filteringModeSlider');
    modeSlider.dataset.level = level;
    if ( qs$('.filteringModeSlider.moving') === null ) {
        dom.text(
            '#filteringModeText > span:nth-of-type(1)',
            i18n$(`filteringMode${level}Name`)
        );
    }
    if ( commit !== true ) { return; }
    dom.cl.add(dom.body, 'busy');
    await commitFilteringMode();
    dom.cl.remove(dom.body, 'busy');
}

export function commitFilteringMode(
    messageSender = sendMessage,
    reloadTab = undefined,
    autoReload = popupPanelData.autoReload,
    permissionRequester = origins => browser.permissions.request({ origins })
) {
    const targetHostname = tabURL.hostname;
    if ( targetHostname === '' ) { return Promise.resolve(false); }
    const modeSlider = qs$('.filteringModeSlider');
    const afterLevel = parseInt(modeSlider.dataset.level, 10);
    const beforeLevel = parseInt(modeSlider.dataset.levelBefore, 10);
    let pendingModeRequest = Promise.resolve({ value: undefined });
    let permissionRequest = Promise.resolve({ value: true });
    if ( afterLevel > 1 ) {
        if ( beforeLevel <= 1 ) {
            try {
                pendingModeRequest = capturePopupRequest(messageSender({
                    what: 'setPendingFilteringMode',
                    tabId: currentTab.id,
                    url: tabURL.href,
                    hostname: targetHostname,
                    beforeLevel,
                    afterLevel,
                })).then(result => {
                    if ( result.error !== undefined ) { return result; }
                    try {
                        assertSuccessfulMessageResponse(result.value);
                        return result;
                    } catch(error) {
                        return { error };
                    }
                });
            } catch(reason) {
                pendingModeRequest = Promise.resolve({ error: reason });
            }
        }
        // WebKit requires permissions.request() to be invoked in the original
        // user-gesture stack. Starting it inside the serialized promise tail
        // makes every Basic -> Optimal/Complete click fail on iOS.
        try {
            permissionRequest = capturePopupRequest(permissionRequester([
                `*://*.${targetHostname}/*`,
            ]));
        } catch(reason) {
            permissionRequest = Promise.resolve({ error: reason });
        }
    }
    return queuePopupMutation(( ) => commitFilteringModeNow(
        messageSender,
        reloadTab,
        autoReload,
        targetHostname,
        afterLevel,
        beforeLevel,
        pendingModeRequest,
        permissionRequest
    ));
}

async function commitFilteringModeNow(
    messageSender,
    reloadTab,
    autoReload,
    targetHostname,
    afterLevel,
    beforeLevel,
    pendingModeRequest,
    permissionRequest
) {
    if ( await popupInitialization !== true ) { return true; }
    if ( targetHostname === '' ) { return false; }
    const modeSlider = qs$('.filteringModeSlider');
    clearRuntimeError();
    if ( afterLevel > 1 ) {
        const pendingResult = await pendingModeRequest;
        if ( pendingResult.error !== undefined ) {
            popupMutationError ??= pendingResult.error;
            setFilteringMode(beforeLevel);
            showRuntimeError(pendingResult.error);
            return false;
        }
        const permissionResult = await permissionRequest;
        if ( permissionResult.error !== undefined ) {
            popupMutationError ??= permissionResult.error;
            setFilteringMode(beforeLevel);
            showRuntimeError(permissionResult.error);
            return false;
        }
        const granted = permissionResult.value;
        if ( granted !== true ) {
            setFilteringMode(beforeLevel);
            return false;
        }
    }
    dom.text(
        '#filteringModeText > span:nth-of-type(1)',
        i18n$(`filteringMode${afterLevel}Name`)
    );
    let actualLevel;
    try {
        actualLevel = assertSuccessfulMessageResponse(await messageSender({
            what: 'setFilteringMode',
            hostname: targetHostname,
            level: afterLevel,
        }));
        if ( Number.isInteger(actualLevel) === false ) {
            throw new Error('Invalid filtering-mode response');
        }
    } catch(reason) {
        popupMutationError ??= reason;
        setFilteringMode(beforeLevel);
        showRuntimeError(reason);
        return false;
    }
    if ( actualLevel !== afterLevel ) {
        setFilteringMode(actualLevel);
    }
    modeSlider.dataset.levelBefore = `${actualLevel}`;
    popupPanelData.level = actualLevel;
    if ( actualLevel !== beforeLevel && autoReload ) {
        const justReload = tabURL.href === currentTab.url;
        self.setTimeout(( ) => {
            if ( typeof reloadTab === 'function' ) {
                reloadTab();
            } else if ( justReload ) {
                browser.tabs.reload(currentTab.id);
            } else {
                browser.tabs.update(currentTab.id, { url: tabURL.href });
            }
        }, 437);
    }
    return true;
}

self.floorpPrepareToClose = async ( ) => {
    try {
        await settlePopupRoutes();
        if ( popupMutationRevision === 0 ) {
            return { ready: true, noMutation: true };
        }
        // A popup may be dismissed before tabs.query/background startup has
        // completed. With no user mutation there is nothing to flush, so do
        // not turn that harmless timing window into a native failure alert.
        const initialized = await popupInitialization;
        if ( initialized !== true ) {
            throw new Error('Popup did not finish initializing');
        }
        await settlePopupMutations();
        const earlierMutationError = popupMutationError;
        popupMutationError = undefined;
        const modeSlider = qs$('.filteringModeSlider');
        const visibleLevel = parseInt(modeSlider.dataset.level, 10);
        const confirmedLevel = assertSuccessfulMessageResponse(
            await sendMessage({
                what: 'getFilteringMode',
                hostname: tabURL.hostname,
            })
        );
        if (
            Number.isInteger(confirmedLevel) === false ||
            confirmedLevel !== visibleLevel
        ) {
            throw new Error('Popup filtering-mode readback mismatch');
        }
        const readiness = assertSuccessfulMessageResponse(
            await sendMessage({ what: 'floorpReadiness' })
        );
        if ( readiness?.ready !== true ) {
            throw new Error(readiness?.error || 'uBO Lite is not ready');
        }
        if ( earlierMutationError !== undefined ) {
            throw earlierMutationError;
        }
        clearRuntimeError();
        return {
            ready: true,
            level: confirmedLevel,
            version: readiness.version,
        };
    } catch(reason) {
        showRuntimeError(reason);
        return {
            ready: false,
            error: reason instanceof Error ? reason.message : `${reason}`,
        };
    }
};

async function completePopupRoute(
    operation,
    expectsOpenedResponse = true
) {
    clearRuntimeError();
    if ( pendingPopupRoutes.size === 0 ) {
        popupRouteError = undefined;
    }
    try {
        await trackPopupRoute((async ( ) => {
            const response = assertSuccessfulMessageResponse(await operation);
            if ( expectsOpenedResponse && response?.opened !== true ) {
                throw new Error(response?.error || 'Popup route was not opened');
            }
            return response;
        })());
        self.close();
    } catch(reason) {
        showRuntimeError(reason);
    }
}

self.floorpCompletePopupRoute = completePopupRoute;

{
    let mx0 = 0;
    let mx1 = 0;
    let l0 = 0;
    let lMax = 0;
    let timer;

    const move = ( ) => {
        timer = undefined;
        const l1 = Math.min(Math.max(l0 + mx1 - mx0, 0), lMax);
        let level = Math.floor(l1 * BLOCKING_MODE_MAX / lMax);
        if ( qs$('body[dir="rtl"]') !== null ) {
            level = 3 - level;
        }
        const modeSlider = qs$('.filteringModeSlider');
        if ( `${level}` === modeSlider.dataset.level ) { return; }
        dom.text(
            '#filteringModeText > span:nth-of-type(2)',
            i18n$(`filteringMode${level}Name`)
        );
        setFilteringMode(level);
    };

    const moveAsync = ev => {
        if ( timer !== undefined ) { return; }
        mx1 = ev.pageX;
        timer = self.requestAnimationFrame(move);
    };

    const stop = ev => {
        if ( ev.button !== 0 ) { return; }
        const modeSlider = qs$('.filteringModeSlider');
        if ( dom.cl.has(modeSlider, 'moving') === false ) { return; }
        dom.cl.remove(modeSlider, 'moving');
        self.removeEventListener('mousemove', moveAsync, { capture: true });
        self.removeEventListener('mouseup', stop, { capture: true });
        dom.text('#filteringModeText > span:nth-of-type(2)', '');
        commitFilteringMode();
        ev.stopPropagation();
        ev.preventDefault();
        if ( timer !== undefined ) {
            self.cancelAnimationFrame(timer);
            timer = undefined;
        }
    };

    const startSliding = ev => {
        if ( ev.button !== 0 ) { return; }
        const modeButton = qs$('.filteringModeButton');
        if ( ev.currentTarget !== modeButton ) { return; }
        const modeSlider = qs$('.filteringModeSlider');
        if ( dom.cl.has(modeSlider, 'moving') ) { return; }
        modeSlider.dataset.levelBefore = modeSlider.dataset.level;
        mx0 = ev.pageX;
        const buttonRect = modeButton.getBoundingClientRect();
        l0 = buttonRect.left + buttonRect.width / 2;
        const sliderRect = modeSlider.getBoundingClientRect();
        lMax = sliderRect.width - buttonRect.width ;
        dom.cl.add(modeSlider, 'moving');
        self.addEventListener('mousemove', moveAsync, { capture: true });
        self.addEventListener('mouseup', stop, { capture: true });
        ev.stopPropagation();
        ev.preventDefault();
    };

    dom.on('.filteringModeButton', 'mousedown', startSliding);
}

dom.on(
    '.filteringModeSlider',
    'click',
    '.filteringModeSlider span[data-level]',
    ev => {
        const modeSlider = qs$('.filteringModeSlider');
        modeSlider.dataset.levelBefore = modeSlider.dataset.level;
        const span = ev.target;
        const level = parseInt(span.dataset.level, 10);
        setFilteringMode(level, true);
    }
);

if ( dom.cl.has(dom.html, 'mobile') === false ) {
    dom.on('.filteringModeSlider',
        'mouseenter',
        '.filteringModeSlider span[data-level]',
        ev => {
            const span = ev.target;
            const level = parseInt(span.dataset.level, 10);
            dom.text('#filteringModeText > span:nth-of-type(2)',
                i18n$(`filteringMode${level}Name`)
            );
        }
    );

    dom.on('.filteringModeSlider',
        'mouseleave',
        '.filteringModeSlider span[data-level]',
        ( ) => {
            dom.text('#filteringModeText > span:nth-of-type(2)', '');
        }
    );
}

/******************************************************************************/

dom.on('#gotoMatchedRules', 'click', ev => {
    if ( ev.isTrusted !== true ) { return; }
    if ( ev.button !== 0 ) { return; }
    void completePopupRoute(sendMessage({
        what: 'showMatchedRules',
        tabId: currentTab.id,
        windowId: currentTab.windowId,
        incognito: currentTab.incognito === true,
    }));
});

/******************************************************************************/

dom.on('#gotoReport', 'click', ev => {
    if ( ev.isTrusted !== true ) { return; }
    let url;
    try {
        url = new URL(currentTab.url);
    } catch {
    }
    if ( url === undefined ) { return; }
    const reportURL = new URL(runtime.getURL('/report.html'));
    reportURL.searchParams.set('tabid', currentTab.id);
    reportURL.searchParams.set('url', tabURL.href);
    reportURL.searchParams.set('mode', popupPanelData.level);
    void completePopupRoute(sendMessage({
        what: 'gotoURL',
        url: `${reportURL.pathname}${reportURL.search}`,
        windowId: currentTab.windowId,
        incognito: currentTab.incognito === true,
    }));
});

/******************************************************************************/

dom.on('#gotoDashboard', 'click', ev => {
    if ( ev.isTrusted !== true ) { return; }
    if ( ev.button !== 0 ) { return; }
    void completePopupRoute(runtime.openOptionsPage(), false);
});

/******************************************************************************/

dom.on('#gotoZapper', 'click', ( ) => {
    if ( browser.scripting === undefined ) { return; }
    void queuePopupMutation(( ) => browser.scripting.executeScript({
        files: [ '/js/scripting/tool-overlay.js', '/js/scripting/zapper.js' ],
        target: { tabId: currentTab.id },
    }));
    self.close();
});

/******************************************************************************/

dom.on('#gotoPicker', 'click', ( ) => {
    if ( browser.scripting === undefined ) { return; }
    void queuePopupMutation(( ) => browser.scripting.executeScript({
        files: [
            '/js/scripting/css-api.js',
            '/js/scripting/css-procedural-api.js',
            '/js/scripting/tool-overlay.js',
            '/js/scripting/picker.js',
        ],
        target: { tabId: currentTab.id },
    }));
    self.close();
});

/******************************************************************************/

dom.on('#gotoUnpicker', 'click', ( ) => {
    if ( browser.scripting === undefined ) { return; }
    void queuePopupMutation(( ) => browser.scripting.executeScript({
        files: [
            '/js/scripting/css-api.js',
            '/js/scripting/css-procedural-api.js',
            '/js/scripting/tool-overlay.js',
            '/js/scripting/unpicker.js',
        ],
        target: { tabId: currentTab.id },
    }));
    self.close();
});

/******************************************************************************/

async function init() {
    const [ tab ] = await browser.tabs.query({
        active: true,
        currentWindow: true,
    });
    if ( tab instanceof Object === false ) {
        throw new Error('Active tab is unavailable');
    }
    if (
        Number.isInteger(tab.id) === false ||
        Number.isInteger(tab.windowId) === false ||
        typeof tab.incognito !== 'boolean'
    ) {
        throw new Error('Active tab routing data is unavailable');
    }
    Object.assign(currentTab, tab);

    let url;
    try {
        const strictBlockURL = runtime.getURL('/strictblock.');
        url = new URL(currentTab.url);
        if ( url.href.startsWith(strictBlockURL) ) {
            url = new URL(url.hash.slice(1));
        }
        tabURL.href = url.href || '';
    } catch {
        throw new Error('Active tab URL is unavailable');
    }

    if ( url !== undefined ) {
        const response = assertSuccessfulMessageResponse(await sendMessage({
            what: 'popupPanelData',
            origin: url.origin,
            hostname: tabURL.hostname,
        }));
        const disabledFeatures = response instanceof Object &&
            response.disabledFeatures === undefined
            ? []
            : response?.disabledFeatures;
        if (
            response instanceof Object === false ||
            Number.isInteger(response.level) === false ||
            response.level < 0 ||
            response.level > BLOCKING_MODE_MAX ||
            typeof response.hasOmnipotence !== 'boolean' ||
            typeof response.autoReload !== 'boolean' ||
            typeof response.isSideloaded !== 'boolean' ||
            typeof response.developerMode !== 'boolean' ||
            Array.isArray(disabledFeatures) === false ||
            disabledFeatures.some(feature => typeof feature !== 'string') ||
            Number.isInteger(response.hasCustomFilters) === false ||
            response.hasCustomFilters < 0
        ) {
            throw new Error('Invalid popup panel data');
        }
        Object.assign(popupPanelData, response, { disabledFeatures });
    }

    renderAdminRules();

    setFilteringMode(popupPanelData.level);

    dom.text('#hostname', punycode.toUnicode(tabURL.hostname));

    dom.cl.toggle('#gotoMatchedRules', 'enabled',
        popupPanelData.isSideloaded === true &&
        popupPanelData.developerMode &&
        typeof currentTab.id === 'number' &&
        isNaN(currentTab.id) === false
    );

    const isHTTP = url.protocol === 'http:' || url.protocol === 'https:';
    dom.cl.toggle(dom.root, 'isHTTP', isHTTP);

    dom.cl.toggle('#gotoUnpicker', 'enabled', popupPanelData.hasCustomFilters);

    return true;
}

async function tryInit(attempt = 1) {
    try {
        return await init();
    } catch(reason) {
        if ( attempt >= 20 ) { throw reason; }
        await new Promise(resolve => self.setTimeout(resolve, 100));
        return tryInit(attempt + 1);
    }
}

popupInitialization = tryInit().finally(( ) => {
    dom.cl.remove(dom.body, 'loading', 'busy');
});
void popupInitialization.catch(reason => {
    popupMutationError ??= reason;
    showRuntimeError(reason);
});

/******************************************************************************/
