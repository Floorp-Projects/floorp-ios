/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2014-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/******************************************************************************/

const validActionValues = [
    'block',
    'redirect',
    'allow',
    'upgradeScheme',
    'modifyHeaders',
    'allowAllRequests',
];

const validBoolValues = [
    'false',
    'true',
];

const validHeaderOpValues = [
    'append',
    'remove',
    'set',
];

const validDomainTypeValues = [
    'firstParty',
    'thirdParty',
];

const validRequestMethodValues = [
    'connect',
    'delete',
    'get',
    'head',
    'options',
    'patch',
    'post',
    'put',
    'trace',
    'other',
];

const validResourceTypeValues = [
    'main_frame',
    'sub_frame',
    'stylesheet',
    'script',
    'image',
    'font',
    'object',
    'xmlhttprequest',
    'ping',
    'csp_report',
    'media',
    'websocket',
    'webtransport',
    'webbundle',
    'other',
];

const safariRequestMethodValues = validRequestMethodValues.filter(value =>
    value !== 'other'
);

const safariResourceTypeValues = validResourceTypeValues.filter(value =>
    [ 'csp_report', 'object', 'webbundle', 'webtransport' ].includes(value) === false
);

/******************************************************************************/

function selectParser(scope, rule, node) {
    const parser = perScopeParsers[scope.join('.')];
    if ( parser === undefined ) { return false; }
    return parser(scope, rule, node);
}

const perScopeParsers = {
    '': function(scope, rule, node) {
        const { key, val } = node;
        switch ( key ) {
        case 'action':
        case 'condition':
            if ( val !== undefined ) { return false; }
            rule[key] = {};
            scope.push(key);
            break;
        case 'id': {
            const n = parseInt(val, 10);
            if ( isNaN(n) || n < 1) { return false; }
            rule.id = n;
            break;
        }
        case 'priority': {
            const n = parseInt(val, 10);
            if ( isNaN(n) || n < 1 ) { return false; }
            rule.priority = n;
            break;
        }
        default:
            return false;
        }
        return true;
    },
    'action': function(scope, rule, node) {
        const { key, val } = node;
        switch ( key ) {
        case 'type':
            if ( validActionValues.includes(val) === false ) { return false; }
            rule.action.type = val;
            break;
        case 'redirect':
            rule.action.redirect = {};
            scope.push('redirect');
            break;
        case 'requestHeaders':
        case 'responseHeaders':
            rule.action[key] = [];
            scope.push(key);
            break;
        default:
            return false;
        }
        return true;
    },
    'action.redirect': function(scope, rule, node) {
        const { key, val } = node;
        switch ( key ) {
        case 'extensionPath':
        case 'regexSubstitution':
        case 'url':
            rule.action.redirect[key] = val;
            break;
        case 'transform':
            rule.action.redirect.transform = {};
            scope.push('transform');
            break;
        default:
            return false;
        }
        return true;
    },
    'action.redirect.transform': function(scope, rule, node) {
        const { key, val } = node;
        switch ( key ) {
        case 'fragment':
        case 'host':
        case 'path':
        case 'port':
        case 'query':
        case 'scheme': {
            if ( val === undefined ) { return false; }
            rule.action.redirect.transform[key] = val;
            break;
        }
        case 'queryTransform':
            rule.action.redirect.transform.queryTransform = {};
            scope.push('queryTransform');
            break;
        default:
            return false;
        }
        return true;
    },
    'action.redirect.transform.queryTransform': function(scope, rule, node) {
        const { key, val } = node;
        if ( val !== undefined ) { return false; }
        switch ( key ) {
        case 'addOrReplaceParams':
        case 'removeParams':
            rule.action.redirect.transform.queryTransform[key] = [];
            scope.push(key);
            break;
        default:
            return false;
        }
        return true;
    },
    'action.redirect.transform.queryTransform.addOrReplaceParams': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        rule.action.redirect.transform.queryTransform.addOrReplaceParams.push({});
        scope.push('@');
        return selectParser(scope, rule, node);
    },
    'action.redirect.transform.queryTransform.addOrReplaceParams.@': function(scope, rule, node) {
        const { key, val } = node;
        if ( val === undefined ) { return false; }
        const item = rule.action.redirect.transform.queryTransform.addOrReplaceParams.at(-1);
        switch ( key ) {
        case 'key':
        case 'value':
            item[key] = val;
            break;
        case 'replaceOnly':
            if ( validBoolValues.includes(val) === false ) { return false; }
            item.replaceOnly = val === 'true';
            break;
        default:
            return false;
        }
        return true;
    },
    'action.redirect.transform.queryTransform.removeParams': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        rule.action.redirect.transform.queryTransform.removeParams.push(node.val);
        return true;
    },
    'action.requestHeaders': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        rule.action.requestHeaders.push({});
        scope.push('@');
        return selectParser(scope, rule, node);
    },
    'action.requestHeaders.@': function(scope, rule, node) {
        const { key, val } = node;
        const item = rule.action.requestHeaders.at(-1);
        switch ( key ) {
        case 'header':
        case 'value':
            item[key] = val;
            break;
        case 'operation':
            if ( validHeaderOpValues.includes(val) === false ) { return false; }
            item.operation = val;
            break;
        default:
            return false;
        }
        return true;
    },
    'action.responseHeaders': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        rule.action.responseHeaders.push({});
        scope.push('@');
        return selectParser(scope, rule, node);
    },
    'action.responseHeaders.@': function(scope, rule, node) {
        const { key, val } = node;
        const item = rule.action.responseHeaders.at(-1);
        switch ( key ) {
        case 'header':
        case 'value':
            item[key] = val;
            break;
        case 'operation':
            if ( validHeaderOpValues.includes(val) === false ) { return false; }
            item.operation = val;
            break;
        default:
            return false;
        }
        return true;
    },
    'condition': function(scope, rule, node) {
        const { key, val } = node;
        switch ( key ) {
        case 'domainType':
            if ( validDomainTypeValues.includes(val) === false ) { return false; }
            rule.condition.domainType = val;
            break;
        case 'isUrlFilterCaseSensitive':
            if ( validBoolValues.includes(val) === false ) { return false; }
            rule.condition.isUrlFilterCaseSensitive = val === 'true';
            break;
        case 'regexFilter':
        case 'urlFilter':
            if ( val === undefined ) { return false; }
            rule.condition[key] = val;
            break;
        case 'initiatorDomains':
        case 'excludedInitiatorDomains':
        case 'requestDomains':
        case 'excludedRequestDomains':
        case 'topDomains':
        case 'excludedTopDomains':
        case 'resourceTypes':
        case 'excludedResourceTypes':
        case 'requestMethods':
        case 'excludedRequestMethods':
        case 'responseHeaders':
        case 'excludedResponseHeaders':
            rule.condition[key] = [];
            scope.push(key);
            break;
        case 'tabIds':
            rule.condition.tabIds = [];
            scope.push('tabIds');
            break;
        default:
            return false;
        }
        return true;
    },
    'condition.initiatorDomains': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        rule.condition.initiatorDomains.push(node.val);
        return true;
    },
    'condition.excludedInitiatorDomains': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        rule.condition.excludedInitiatorDomains.push(node.val);
        return true;
    },
    'condition.domains': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        rule.condition.domains.push(node.val);
        return true;
    },
    'condition.excludedDomains': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        rule.condition.excludedDomains.push(node.val);
        return true;
    },
    'condition.requestDomains': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        rule.condition.requestDomains.push(node.val);
        return true;
    },
    'condition.excludedRequestDomains': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        rule.condition.excludedRequestDomains.push(node.val);
        return true;
    },
    'condition.topDomains': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        rule.condition.topDomains.push(node.val);
        return true;
    },
    'condition.excludedTopDomains': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        rule.condition.excludedTopDomains.push(node.val);
        return true;
    },
    'condition.resourceTypes': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        if ( validResourceTypeValues.includes(node.val) === false ) { return false; }
        rule.condition.resourceTypes.push(node.val);
        return true;
    },
    'condition.excludedResourceTypes': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        if ( validResourceTypeValues.includes(node.val) === false ) { return false; }
        rule.condition.excludedResourceTypes.push(node.val);
        return true;
    },
    'condition.requestMethods': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        if ( validRequestMethodValues.includes(node.val) === false ) { return false; }
        rule.condition.requestMethods.push(node.val);
        return true;
    },
    'condition.excludedRequestMethods': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        if ( validRequestMethodValues.includes(node.val) === false ) { return false; }
        rule.condition.excludedRequestMethods.push(node.val);
        return true;
    },
    'condition.responseHeaders': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        rule.condition.responseHeaders.push({});
        scope.push('@');
        return selectParser(scope, rule, node);
    },
    'condition.responseHeaders.@': function(scope, rule, node) {
        const item = rule.condition.responseHeaders.at(-1);
        switch ( node.key ) {
        case 'header':
            if ( node.val === undefined ) { return false; }
            item.header = node.val;
            break;
        case 'values':
        case 'excludedValues':
            item[node.key] = [];
            scope.push(node.key);
            break;
        default:
            return false;
        }
        return true;
    },
    'condition.responseHeaders.@.values': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        const item = rule.condition.responseHeaders.at(-1);
        item.values.push(node.val);
        return true;
    },
    'condition.responseHeaders.@.excludedValues': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        const item = rule.condition.responseHeaders.at(-1);
        item.excludedValues.push(node.val);
        return true;
    },
    'condition.excludedResponseHeaders': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        rule.condition.excludedResponseHeaders.push({});
        scope.push('@');
        return selectParser(scope, rule, node);
    },
    'condition.excludedResponseHeaders.@': function(scope, rule, node) {
        const item = rule.condition.excludedResponseHeaders.at(-1);
        switch ( node.key ) {
        case 'header':
            if ( node.val === undefined ) { return false; }
            item.header = node.val;
            break;
        case 'values':
        case 'excludedValues':
            item[node.key] = [];
            scope.push(node.key);
            break;
        default:
            return false;
        }
        return true;
    },
    'condition.excludedResponseHeaders.@.values': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        const item = rule.condition.excludedResponseHeaders.at(-1);
        item.values.push(node.val);
        return true;
    },
    'condition.excludedResponseHeaders.@.excludedValues': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        const item = rule.condition.excludedResponseHeaders.at(-1);
        item.excludedValues.push(node.val);
        return true;
    },
    'condition.tabIds': function(scope, rule, node) {
        if ( node.list !== true ) { return false; }
        const n = parseInt(node.val, 10);
        if ( isNaN(n) || n === 0 ) { return false; }
        rule.condition.tabIds.push(n);
    },
};

/******************************************************************************/

function depthFromIndent(line) {
    const match = /^\s*/.exec(line);
    const count = match[0].length;
    if ( (count & 1) !== 0 ) { return -1; }
    return count / 2;
}

/******************************************************************************/

function nodeFromLine(line) {
    const match = reNodeParser.exec(line);
    const out = {};
    if ( match === null ) { return out; }
    if ( match[1] ) {
        out.list = true;
    }
    if ( match[4] ) {
        out.val = match[4].trim();
    } else if ( match[3] ) {
        out.key = match[2];
        out.val = match[3].trim();
        if ( out.val === "''" ) { out.val = '' };
    } else {
        out.key = match[2];
    }
    return out;
}

const reNodeParser = /^\s*(- )?(?:(\S+):( \S.*)?|(\S.*))$/;

/******************************************************************************/

function ruleFromLines(lines, indices) {
    const rule = {};
    const bad = [];
    const scope = [];
    for ( const i of indices ) {
        const line = lines[i];
        const depth = depthFromIndent(line);
        if ( depth < 0 ) {
            bad.push(i);
            continue;
        }
        scope.length = depth;
        const node = nodeFromLine(line);
        const result = selectParser(scope, rule, node);
        if ( result === false ) {
            bad.push(i);
        }
    }
    if ( bad.length !== 0 ) { return { bad }; }
    return { rule };
}

/******************************************************************************/

const isRecord = value =>
    typeof value === 'object' && value !== null && Array.isArray(value) === false;

const owns = (object, key) =>
    Object.prototype.hasOwnProperty.call(object, key);

const isNonEmptyString = value =>
    typeof value === 'string' && value.length !== 0;

const isASCIIString = value =>
    typeof value === 'string' && /^[\x00-\x7F]*$/.test(value);

function validateStringArray(
    value,
    name,
    allowEmpty = false,
    requireASCII = false
) {
    if (
        Array.isArray(value) === false ||
        (allowEmpty === false && value.length === 0) ||
        value.some(entry =>
            isNonEmptyString(entry) === false ||
            (requireASCII && isASCIIString(entry) === false)
        )
    ) {
        const contents = requireASCII ? 'ASCII string' : 'string';
        const qualifier = allowEmpty
            ? (requireASCII ? 'an' : 'a')
            : 'a non-empty';
        return `${name} must be ${qualifier} ${contents} array`;
    }
}

function validateHeaderModifications(value, name) {
    if ( Array.isArray(value) === false || value.length === 0 ) {
        return `${name} must be a non-empty array`;
    }
    for ( const entry of value ) {
        if (
            isRecord(entry) === false ||
            isNonEmptyString(entry.header) === false ||
            validHeaderOpValues.includes(entry.operation) === false
        ) {
            return `${name} contains an invalid header operation`;
        }
        if (
            entry.operation !== 'remove' &&
            typeof entry.value !== 'string'
        ) {
            return `${name} append/set operations require a value`;
        }
    }
}

function validateHeaderConditions(value, name) {
    if ( Array.isArray(value) === false || value.length === 0 ) {
        return `${name} must be a non-empty array`;
    }
    for ( const entry of value ) {
        if ( isRecord(entry) === false || isNonEmptyString(entry.header) === false ) {
            return `${name} contains an invalid header condition`;
        }
        for ( const key of [ 'values', 'excludedValues' ] ) {
            if ( entry[key] === undefined ) { continue; }
            const error = validateStringArray(entry[key], `${name}.${key}`);
            if ( error !== undefined ) { return error; }
        }
    }
}

function validateQueryTransform(value) {
    if ( isRecord(value) === false ) {
        return 'redirect.transform.queryTransform must be an object';
    }
    const { addOrReplaceParams, removeParams } = value;
    if ( addOrReplaceParams === undefined && removeParams === undefined ) {
        return 'redirect.transform.queryTransform must not be empty';
    }
    if ( addOrReplaceParams !== undefined ) {
        if ( Array.isArray(addOrReplaceParams) === false || addOrReplaceParams.length === 0 ) {
            return 'redirect.transform.queryTransform.addOrReplaceParams must not be empty';
        }
        for ( const entry of addOrReplaceParams ) {
            if (
                isRecord(entry) === false ||
                typeof entry.key !== 'string' ||
                typeof entry.value !== 'string' ||
                (entry.replaceOnly !== undefined && typeof entry.replaceOnly !== 'boolean')
            ) {
                return 'redirect.transform.queryTransform contains an invalid replacement';
            }
        }
    }
    if ( removeParams !== undefined ) {
        const error = validateStringArray(
            removeParams,
            'redirect.transform.queryTransform.removeParams'
        );
        if ( error !== undefined ) { return error; }
    }
}

function validateRedirect(value, condition) {
    if ( isRecord(value) === false ) {
        return 'redirect action requires a redirect object';
    }
    const targetKeys = [ 'extensionPath', 'regexSubstitution', 'transform', 'url' ]
        .filter(key => owns(value, key));
    if ( targetKeys.length !== 1 ) {
        return 'redirect action requires exactly one redirect target';
    }
    const targetKey = targetKeys[0];
    if ( targetKey !== 'transform' ) {
        if ( isNonEmptyString(value[targetKey]) === false ) {
            return `redirect.${targetKey} must be a non-empty string`;
        }
        if (
            targetKey === 'regexSubstitution' &&
            isNonEmptyString(condition.regexFilter) === false
        ) {
            return 'redirect.regexSubstitution requires condition.regexFilter';
        }
        if ( targetKey === 'extensionPath' && value.extensionPath.startsWith('/') === false ) {
            return 'redirect.extensionPath must start with /';
        }
        if ( targetKey === 'url' ) {
            try {
                const url = new URL(value.url);
                if ( url.protocol !== 'http:' && url.protocol !== 'https:' ) {
                    return 'redirect.url must use http or https';
                }
            } catch {
                return 'redirect.url must be a valid URL';
            }
        }
        return;
    }
    const transform = value.transform;
    if ( isRecord(transform) === false || Object.keys(transform).length === 0 ) {
        return 'redirect.transform must be a non-empty object';
    }
    if ( owns(transform, 'query') && owns(transform, 'queryTransform') ) {
        return 'redirect.transform query and queryTransform are mutually exclusive';
    }
    for ( const [ key, entry ] of Object.entries(transform) ) {
        if ( key === 'queryTransform' ) {
            const error = validateQueryTransform(entry);
            if ( error !== undefined ) { return error; }
        } else if ( typeof entry !== 'string' ) {
            return `redirect.transform.${key} must be a string`;
        }
    }
    if (
        typeof transform.fragment === 'string' &&
        transform.fragment !== '' &&
        transform.fragment.startsWith('#') === false
    ) {
        return 'redirect.transform.fragment must be empty or start with #';
    }
    if (
        typeof transform.query === 'string' &&
        transform.query !== '' &&
        transform.query.startsWith('?') === false
    ) {
        return 'redirect.transform.query must be empty or start with ?';
    }
    if (
        typeof transform.port === 'string' &&
        transform.port !== '' &&
        (/^[0-9]+$/.test(transform.port) === false || Number(transform.port) > 65535)
    ) {
        return 'redirect.transform.port must be empty or a valid uint16';
    }
    if ( typeof transform.scheme === 'string' ) {
        if (
            /^[A-Za-z][A-Za-z0-9+.-]*$/.test(transform.scheme) === false ||
            transform.scheme.toLowerCase() === 'javascript'
        ) {
            return 'redirect.transform.scheme is invalid';
        }
    }
}

/**
 * Strictly validates a fully submitted user rule without changing the loose
 * parser used while the dashboard editor contains an incomplete draft.
 */
export function validateDNRRuleShape(rule) {
    if ( isRecord(rule) === false ) { return 'rule must be an object'; }
    if ( isRecord(rule.action) === false ) { return 'rule action is required'; }
    if ( validActionValues.includes(rule.action.type) === false ) {
        return 'rule action type is invalid';
    }
    if ( isRecord(rule.condition) === false ) { return 'rule condition is required'; }
    if ( rule.id !== undefined && (!Number.isInteger(rule.id) || rule.id < 1) ) {
        return 'rule id must be a positive integer';
    }
    if (
        rule.priority !== undefined &&
        (!Number.isInteger(rule.priority) || rule.priority < 1)
    ) {
        return 'rule priority must be a positive integer';
    }

    const { action, condition } = rule;
    if ( action.type === 'redirect' ) {
        const error = validateRedirect(action.redirect, condition);
        if ( error !== undefined ) { return error; }
    } else if ( action.redirect !== undefined ) {
        return 'redirect payload is valid only for redirect actions';
    }

    const headerKeys = [ 'requestHeaders', 'responseHeaders' ];
    if ( action.type === 'modifyHeaders' ) {
        if ( headerKeys.every(key => action[key] === undefined) ) {
            return 'modifyHeaders requires requestHeaders or responseHeaders';
        }
        for ( const key of headerKeys ) {
            if ( action[key] === undefined ) { continue; }
            const error = validateHeaderModifications(action[key], key);
            if ( error !== undefined ) { return error; }
        }
    } else if ( headerKeys.some(key => action[key] !== undefined) ) {
        return 'header modifications require a modifyHeaders action';
    }
    if ( action.type === 'modifyHeaders' ) {
        return 'modifyHeaders user rules are unsupported by Safari';
    }

    if ( condition.urlFilter !== undefined && condition.regexFilter !== undefined ) {
        return 'urlFilter and regexFilter are mutually exclusive';
    }
    if (
        condition.urlFilter !== undefined &&
        typeof condition.urlFilter !== 'string'
    ) {
        return 'urlFilter must be a string';
    }
    if (
        condition.regexFilter !== undefined &&
        isNonEmptyString(condition.regexFilter) === false
    ) {
        return 'regexFilter must be a non-empty string';
    }
    for ( const key of [ 'urlFilter', 'regexFilter' ] ) {
        if ( condition[key] === undefined ) { continue; }
        if ( isASCIIString(condition[key]) === false ) {
            return `${key} must contain only ASCII characters`;
        }
    }
    if (
        condition.regexFilter !== undefined &&
        (
            condition.requestDomains !== undefined ||
            (condition.excludedRequestDomains?.length ?? 0) !== 0
        )
    ) {
        return 'regexFilter with request-domain conditions is unsupported by Safari 26.0';
    }
    if (
        condition.isUrlFilterCaseSensitive !== undefined &&
        typeof condition.isUrlFilterCaseSensitive !== 'boolean'
    ) {
        return 'isUrlFilterCaseSensitive must be a boolean';
    }
    if (
        condition.domainType !== undefined &&
        validDomainTypeValues.includes(condition.domainType) === false
    ) {
        return 'domainType is invalid';
    }
    for ( const pair of [ [ 'resourceTypes', 'excludedResourceTypes' ] ] ) {
        if ( condition[pair[0]] !== undefined && condition[pair[1]] !== undefined ) {
            return `${pair[0]} and ${pair[1]} are mutually exclusive`;
        }
    }
    const emptyArrayAllowedKeys = new Set([
        'excludedInitiatorDomains',
        'excludedRequestDomains',
        'excludedResourceTypes',
        'excludedTopDomains',
    ]);
    const domainKeys = new Set([
        'initiatorDomains',
        'excludedInitiatorDomains',
        'requestDomains',
        'excludedRequestDomains',
        'topDomains',
        'excludedTopDomains',
    ]);
    for ( const key of [
        ...domainKeys,
        'resourceTypes',
        'excludedResourceTypes',
        'requestMethods',
        'excludedRequestMethods',
    ] ) {
        if ( condition[key] === undefined ) { continue; }
        const error = validateStringArray(
            condition[key],
            key,
            emptyArrayAllowedKeys.has(key),
            domainKeys.has(key)
        );
        if ( error !== undefined ) { return error; }
    }
    for ( const key of [ 'responseHeaders', 'excludedResponseHeaders' ] ) {
        if ( condition[key] === undefined ) { continue; }
        const error = validateHeaderConditions(condition[key], key);
        if ( error !== undefined ) { return error; }
    }
    if (
        condition.responseHeaders !== undefined ||
        condition.excludedResponseHeaders !== undefined
    ) {
        return 'response-header conditions are unsupported by Safari';
    }
    if (
        condition.tabIds !== undefined &&
        (
            Array.isArray(condition.tabIds) === false ||
            condition.tabIds.length === 0 ||
            condition.tabIds.some(id => Number.isInteger(id) === false || id === 0)
        )
    ) {
        return 'tabIds must be a non-empty array of non-zero integers';
    }
    if ( condition.tabIds !== undefined ) {
        return 'tabIds user rules are unsupported by Safari';
    }
    if ( condition.excludedTabIds !== undefined ) {
        return 'excludedTabIds user rules are unsupported by Safari';
    }
    if (
        condition.topDomains !== undefined ||
        (condition.excludedTopDomains?.length ?? 0) !== 0
    ) {
        return 'topDomains user rules are unsupported by Safari';
    }
    for ( const key of [ 'requestMethods', 'excludedRequestMethods' ] ) {
        if ( condition[key]?.some(method =>
            safariRequestMethodValues.includes(method) === false
        ) ) {
            return `${key} contains a request method unsupported by Safari`;
        }
    }
    for ( const key of [ 'resourceTypes', 'excludedResourceTypes' ] ) {
        if ( condition[key]?.some(type =>
            safariResourceTypeValues.includes(type) === false
        ) ) {
            return `${key} contains a resource type unsupported by Safari`;
        }
    }
    if ( action.type === 'allowAllRequests' ) {
        for ( const key of [
            'domainType',
            'initiatorDomains',
            'requestDomains',
            'requestMethods',
            'excludedRequestMethods',
        ] ) {
            if ( condition[key] !== undefined ) {
                return `allowAllRequests does not support ${key} on Safari`;
            }
        }
        if ( (condition.excludedInitiatorDomains?.length ?? 0) !== 0 ) {
            return 'allowAllRequests does not support excludedInitiatorDomains on Safari';
        }
        if ( (condition.excludedRequestDomains?.length ?? 0) !== 0 ) {
            return 'allowAllRequests does not support excludedRequestDomains on Safari';
        }
        if ( condition.isUrlFilterCaseSensitive === true ) {
            return 'allowAllRequests does not support case-sensitive filters on Safari';
        }
        if ( Array.isArray(condition.resourceTypes) === false ) {
            return 'allowAllRequests requires resourceTypes';
        }
        if (
            condition.resourceTypes.length !== 1 ||
            condition.resourceTypes[0] !== 'main_frame'
        ) {
            return 'allowAllRequests supports only main_frame on Safari';
        }
    }
}

/******************************************************************************/

export function getDNRRuleShapeErrors(rules) {
    if ( Array.isArray(rules) === false ) {
        return [ 'rules must be an array' ];
    }
    const errors = [];
    for ( let i = 0; i < rules.length; i++ ) {
        const detail = validateDNRRuleShape(rules[i]);
        if ( detail === undefined ) { continue; }
        errors.push(`rule ${i + 1}: ${detail}`);
    }
    return errors;
}

/******************************************************************************/

export function rulesFromText(text) {
    const rules = [];
    const bad = [];
    const lines = [ ...text.split(/\n\r|\r\n|\n|\r/), '---' ];
    const indices = [];
    for ( let i = 0; i < lines.length; i++ ) {
        const line = lines[i].trimEnd();
        if ( line.trim().startsWith('#') ) { continue; }
        if ( line !== '---' && line !== '...' ) {
            indices.push(i);
            continue;
        }
        // Discard leading empty lines
        while ( indices.length !== 0 ) {
            const s = lines[indices[0]].trim();
            if ( s.length !== 0 ) { break; }
            indices.shift();
        }
        // Discard trailing empty lines
        while ( indices.length !== 0 ) {
            const s = lines[indices.at(-1)].trim();
            if ( s.length !== 0 ) { break; }
            indices.pop();
        }
        if ( indices.length === 0 ) { continue; }
        const result = ruleFromLines(lines, indices);
        if ( result.bad ) {
            bad.push(...result.bad.slice(0, 4));
        } else if ( result.rule ) {
            rules.push(result.rule);
        }
        indices.length = 0;
    }
    return { rules, bad };
}

/******************************************************************************/

export function validatedRulesFromText(text) {
    const parsed = rulesFromText(text);
    return {
        ...parsed,
        shapeErrors: getDNRRuleShapeErrors(parsed.rules),
    };
}

/******************************************************************************/

function textFromValue(val, depth) {
    const indent = '  '.repeat(depth);
    switch ( typeof val ) {
    case 'boolean':
    case 'number':
        return `${val}`;
    case 'string':
        if ( val === '' ) { return "''"; }
        return val;
    }
    const out = [];
    if ( Array.isArray(val) ) {
        for ( const a of val ) {
            const s = textFromValue(a, depth+1);
            if ( s === undefined ) { continue; }
            out.push(`${indent}- ${s.trimStart()}`);
        }
        return out.join('\n');
    }
    if ( val instanceof Object ) {
        for ( const [ a, b ] of Object.entries(val) ) {
            const s = textFromValue(b, depth+1);
            if ( s === undefined ) { continue; }
            if ( b instanceof Object ) {
                out.push(`${indent}${a}:\n${s}`);
            } else {
                out.push(`${indent}${a}: ${s}`);
            }
        }
        return out.join('\n');
    }
}

/******************************************************************************/

export function textFromRules(rules, option = {}) {
    if ( Array.isArray(rules) === false ) {
        if ( rules instanceof Object === false ) { return; }
        rules = [ rules ];
    }
    const out = [];
    for ( const rule of rules ) {
        if ( option.keepId !== true && rule.id ) { rule.id = undefined };
        const text = textFromValue(rule, 0);
        if ( text === undefined ) { continue; }
        out.push(text, '---' );
    }
    if ( out.length !== 0 ) {
        out.unshift('---');
        out.push('');
    }
    return out.join('\n');
}
