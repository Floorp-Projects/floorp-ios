/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import {
    adminRead,
    localRead, localRemove, localWrite,
    sessionRead, sessionWrite,
    webextFlavor,
} from './ext.js';

import {
    enableRulesets,
    getEnabledRulesets,
    getRulesetDetails,
    setStrictBlockMode,
} from './ruleset-manager.js';

import {
    getDefaultFilteringMode,
    readFilteringModeDetails,
} from './mode-manager.js';

import {
    rulesetConfig,
    saveRulesetConfig,
} from './config.js';

import { broadcastMessage } from './utils.js';
import { dnr } from './ext-compat.js';
import { registerContentScripts } from './scripting-manager.js';
import { setPopupBlockMode } from './prevent-popup.js';
import { ubolErr, ubolLog } from './debug.js';

/******************************************************************************/

export async function loadAdminConfig(apply = false) {
    const [
        popupBlockMode,
        showBlockedCount,
        strictBlockMode,
    ] = await Promise.all([
        adminReadEx('popupBlockMode', true),
        adminReadEx('showBlockedCount', true),
        adminReadEx('strictBlockMode', true),
    ]);
    await applyAdminConfig(
        { popupBlockMode, showBlockedCount, strictBlockMode },
        apply
    );
}

/******************************************************************************/

async function applyAdminConfig(config, apply = false) {
    const toApply = [];
    let modified = false;
    for ( const [ key, val ] of Object.entries(config) ) {
        if ( typeof val !== typeof rulesetConfig[key] ) { continue; }
        // Retried managed-policy side effects must run even when the durable
        // config was already saved before an earlier native API failure.
        if ( apply ) { toApply.push(key); }
        if ( val === rulesetConfig[key] ) { continue; }
        rulesetConfig[key] = val;
        modified = true;
    }
    if ( modified ) { await saveRulesetConfig(); }
    if ( apply !== true ) { return; }
    while ( toApply.length !== 0 ) {
        const key = toApply.pop();
        switch ( key ) {
        case 'popupBlockMode': {
            const { popupBlockMode } = config;
            await setPopupBlockMode(popupBlockMode, true);
            broadcastMessage({ popupBlockMode });
            break;
        }
        case 'showBlockedCount': {
            if ( typeof dnr.setExtensionActionOptions !== 'function' ) { break; }
            const { showBlockedCount } = config;
            await dnr.setExtensionActionOptions({
                displayActionCountAsBadgeText: showBlockedCount,
            });
            broadcastMessage({ showBlockedCount });
            break;
        }
        case 'strictBlockMode': {
            const { strictBlockMode } = config;
            const result = await setStrictBlockMode(strictBlockMode, true);
            if ( result?.error ) { throw new Error(result.error); }
            broadcastMessage({ strictBlockMode });
            break;
        }
        default:
            break;
        }
    }
}

/******************************************************************************/

let runAdminSettingsMutation = async operation => {
    const result = await operation();
    if ( result?.foregroundReconciliationRequired ) {
        throw new Error('Foreground ruleset reconciliation is required');
    }
    return true;
};

export function setAdminSettingsMutationRunner(runner) {
    if ( typeof runner !== 'function' ) {
        throw new TypeError('Admin settings mutation runner must be a function');
    }
    runAdminSettingsMutation = runner;
}

/******************************************************************************/

const adminSettings = {
    keys: new Map(),
    timer: undefined,
    processing: false,
    deferred: false,
    change(key, value) {
        // The token distinguishes a change which arrived while an earlier
        // snapshot was being applied, even when both managed values compare
        // equal. Only the exact snapshot which completed may be removed.
        this.keys.set(key, { token: {}, value });
        this.deferred = false;
        this.schedule();
    },
    schedule() {
        if ( this.timer !== undefined || this.processing || this.deferred ) {
            return;
        }
        this.timer = self.setTimeout(( ) => {
            this.timer = undefined;
            this.processing = true;
            void this.process().catch(reason => {
                // A persistent managed-policy or storage error must not keep
                // Safari's background process awake in a tight retry loop.
                // A new managed value or a successful foreground recovery
                // explicitly resumes the retained token snapshot.
                this.deferred = true;
                ubolErr(`adminSettings.process/${reason}`);
            }).finally(( ) => {
                this.processing = false;
                if ( this.keys.size !== 0 && this.deferred === false ) {
                    this.schedule();
                }
            });
        }, 127);
    },
    async process() {
        const snapshot = new Map(this.keys);
        if ( snapshot.size === 0 ) { return; }
        const completed = await runAdminSettingsMutation(async ( ) => {
            if ( snapshot.has('rulesets') ) {
                ubolLog('admin setting "rulesets" changed');
                const result = await enableRulesets(
                    rulesetConfig.enabledRulesets,
                    true,
                    webextFlavor !== 'safari'
                );
                if ( result.foregroundReconciliationRequired ) {
                    return result;
                }
                if ( result.error ) { throw new Error(result.error); }
                await registerContentScripts(true);
                const results = await Promise.all([
                    getAdminRulesets(),
                    getEnabledRulesets(),
                ]);
                const [ adminRulesets, enabledRulesets ] = results;
                broadcastMessage({ adminRulesets, enabledRulesets });
            }
            if ( snapshot.has('defaultFiltering') ) {
                ubolLog('admin setting "defaultFiltering" changed');
                await readFilteringModeDetails(true);
                await registerContentScripts(true);
                const defaultFilteringMode = await getDefaultFilteringMode();
                broadcastMessage({ defaultFilteringMode });
            }
            if ( snapshot.has('noFiltering') ) {
                ubolLog('admin setting "noFiltering" changed');
                const filteringModeDetails = await readFilteringModeDetails(true);
                await registerContentScripts(true);
                broadcastMessage({ filteringModeDetails });
            }
            if ( snapshot.has('popupBlockMode') ) {
                ubolLog('admin setting "popupBlockMode" changed');
                const { value: popupBlockMode } = snapshot.get('popupBlockMode');
                await applyAdminConfig({ popupBlockMode }, true);
                await registerContentScripts(true);
            }
            if ( snapshot.has('showBlockedCount') ) {
                ubolLog('admin setting "showBlockedCount" changed');
                const { value: showBlockedCount } = snapshot.get('showBlockedCount');
                await applyAdminConfig({ showBlockedCount }, true);
            }
            if ( snapshot.has('strictBlockMode') ) {
                ubolLog('admin setting "strictBlockMode" changed');
                const { value: strictBlockMode } = snapshot.get('strictBlockMode');
                await applyAdminConfig({ strictBlockMode }, true);
            }
            return true;
        });
        if ( completed !== true ) {
            this.deferred = true;
            return;
        }
        for ( const [ key, entry ] of snapshot ) {
            if ( this.keys.get(key) === entry ) { this.keys.delete(key); }
        }
    }
};

export function resumeAdminSettingsProcessing() {
    adminSettings.deferred = false;
    if ( adminSettings.keys.size !== 0 ) { adminSettings.schedule(); }
}

/******************************************************************************/

export async function getAdminRulesets(fresh = false) {
    const [
        adminList,
        rulesetDetails,
    ] = await Promise.all([
        adminReadEx('rulesets', fresh),
        getRulesetDetails(),
    ]);
    const adminRulesets = new Set(Array.isArray(adminList) && adminList || []);
    if ( adminRulesets.has('-default') ) {
        adminRulesets.delete('-default');
        for ( const ruleset of rulesetDetails.values() ) {
            if ( ruleset.enabled !== true ) { continue; }
            if ( adminRulesets.has(`+${ruleset.id}`) ) { continue; }
            adminRulesets.add(`-${ruleset.id}`);
        }
    }
    if ( adminRulesets.has('+default') ) {
        adminRulesets.delete('+default');
        for ( const ruleset of rulesetDetails.values() ) {
            if ( ruleset.enabled !== true ) { continue; }
            if ( adminRulesets.has(`-${ruleset.id}`) ) { continue; }
            adminRulesets.add(`+${ruleset.id}`);
        }
    }
    if ( adminRulesets.has('-*') ) {
        adminRulesets.delete('-*');
        for ( const ruleset of rulesetDetails.values() ) {
            if ( ruleset.enabled ) { continue; }
            if ( adminRulesets.has(`+${ruleset.id}`) ) { continue; }
            adminRulesets.add(`-${ruleset.id}`);
        }
    }
    return Array.from(adminRulesets);
}

/******************************************************************************/

export async function adminReadEx(key, fresh = false) {
    let cacheValue;
    const session = await sessionRead(`admin.${key}`);
    if ( session ) {
        cacheValue = session.data;
    } else {
        const local = await localRead(`admin.${key}`);
        if ( local ) {
            cacheValue = local.data;
        }
        await localRemove(`admin_${key}`); // TODO: remove eventually
    }
    const value = await adminRead(key);
    const adminKey = `admin.${key}`;
    await Promise.all([
        sessionWrite(adminKey, { data: value }),
        localWrite(adminKey, { data: value }),
    ]);
    if ( JSON.stringify(value) !== JSON.stringify(cacheValue) ) {
        if ( fresh ) { return value; }
        adminSettings.change(key, value);
    }
    return cacheValue;
}

/******************************************************************************/
