/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import {
    MODE_BASIC,
    MODE_OPTIMAL,
    defaultFilteringModes,
    getDefaultFilteringMode,
    getFilteringMode,
    getFilteringModeDetails,
    persistHostPermissions,
    setDefaultFilteringMode,
    setFilteringMode,
    setFilteringModeDetails,
    syncWithBrowserPermissions,
} from './mode-manager.js';

import {
    addCustomFilters,
    customFiltersFromHostname,
    getAllCustomFilters,
    getSandboxFilters,
    hasCustomFilters,
    injectCustomFilters,
    mutateCustomFiltersAtomically,
    removeAllCustomFilters,
    removeCustomFilters,
    replaceAllCustomFiltersAtomically,
    replaceCustomFiltersAtomically,
    setSandboxFilters,
    startCustomFilters,
    terminateCustomFilters,
} from './filter-manager.js';

import {
    addImportedLists,
    getImportedLists,
    removeImportedLists,
    updateImportedLists,
} from './imported-lists.js';

import {
    adminReadEx,
    getAdminRulesets,
    loadAdminConfig,
} from './admin.js';

import {
    broadcastMessage,
    hostnameFromMatch,
    hostnamesFromMatches,
} from './utils.js';

import {
    browser,
    localRead, localRemove, localReplace, localSnapshot, localWrite,
    runtime,
    sessionAccessLevel,
    sessionClear,
    supportsUserScripts,
    webextFlavor,
} from './ext.js';

import {
    defaultConfig,
    loadRulesetConfig,
    process,
    rulesetConfig,
    saveRulesetConfig,
} from './config.js';

import {
    enableRulesets,
    excludeFromStrictBlock,
    getDefaultRulesetsFromEnv,
    getEffectiveUserRules,
    getEnabledRulesets,
    getEnabledRulesetsDetails,
    getRulesetDetails,
    getRulesetRules,
    patchDefaultRulesets,
    setStrictBlockMode,
    updateDynamicAndSessionRules,
    updateSessionRules,
    validateUserDnrRules,
    updateUserRules,
} from './ruleset-manager.js';

import {
    getConsoleOutput,
    getMatchedRules,
    isSideloaded,
    toggleDeveloperMode,
    ubolErr,
    ubolLog,
} from './debug.js';

import {
    getRegisteredContentScripts,
    pruneCSSCache,
    registerContentScripts,
} from './scripting-manager.js';

import {
    gotoURL,
    hasBroadHostPermissions,
} from './ext-utils.js';

import {
    processDueJobs,
    resetJobsAlarm,
} from './alarms.js';

import {
    registerUserScripts,
    updateCompiledFilters,
} from './compiled-filters.js';

import {
    dnr,
    releaseRealmRulesetStartupGate,
    resetSafariRealmReadiness,
    waitForRealmRulesetUpdates,
} from './ext-compat.js';
import { setPopupBlockMode } from './prevent-popup.js';
import { supportsOffscreenDocument } from './ext-offscreen.js';
import { toggleToolbarIcon } from './action.js';

/******************************************************************************/

const UBOL_ORIGIN = runtime.getURL('').replace(/\/$/, '').toLowerCase();
const canShowBlockedCount = typeof dnr.setExtensionActionOptions === 'function';

let pendingPermissionRequest;

/******************************************************************************/

function getCurrentVersion() {
    return runtime.getManifest().version;
}

/******************************************************************************/

async function reloadTab(tabId, url = '') {
    return new Promise(resolve => {
        self.setTimeout(( ) => {
            if ( url !== '' ) {
                browser.tabs.update(tabId, { url });
            } else {
                browser.tabs.reload(tabId);
            }
            resolve();
        }, 437);
    });
}

// When a new host permission is granted through the popup panel
async function onPermissionGrantedThruExtension(details, origins) {
    await persistHostPermissions();
    const defaultMode = await getDefaultFilteringMode();
    if ( defaultMode >= MODE_OPTIMAL ) { return; }
    if ( Array.isArray(origins) === false ) { return; }
    const hostnames = hostnamesFromMatches(origins);
    if ( hostnames.includes(details.hostname) === false ) { return; }
    const beforeLevel = await getFilteringMode(details.hostname);
    if ( beforeLevel === details.afterLevel ) { return; }
    const afterLevel = await setFilteringMode(details.hostname, details.afterLevel, true);
    if ( afterLevel !== details.afterLevel ) { return; }
    await Promise.all([
        registerContentScripts(true),
        registerUserScripts(),
    ]);
    if ( rulesetConfig.autoReload !== true ) { return; }
    await reloadTab(details.tabId, details.url);
}

// When a new host permission is granted through the browser
async function onPermissionGrantedThruBrowser(origins) {
    const modified = await syncWithBrowserPermissions(true);
    if ( modified === false ) { return; }
    await registerContentScripts(true);
    if ( rulesetConfig.autoReload !== true ) { return; }
    if ( origins.length !== 1 ) { return; }
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    const tabId = tabs?.[0]?.id;
    if ( typeof tabId !== 'number' || tabId === -1 ) { return; }
    const results = await browser.scripting.executeScript({
        target: { tabId, frameIds: [ 0 ] },
        func: ( ) => document.location.hostname,
    }).catch(( ) => {
    });
    const tabHostname = results?.[0]?.result;
    if ( typeof tabHostname !== 'string' ) { return; }
    const hostname = hostnameFromMatch(origins[0]);
    if ( tabHostname.endsWith(hostname) === false ) { return; }
    const pos = tabHostname.length - hostname.length;
    if ( pos !== 0 && tabHostname.charAt(pos-1) !== '.' ) { return; }
    await reloadTab(tabId);
}

// https://github.com/uBlockOrigin/uBOL-home/issues/280
async function onPermissionsAdded(permissions, details) {
    const { origins = [] } = permissions;
    return details !== undefined
        ? onPermissionGrantedThruExtension(details, origins)
        : onPermissionGrantedThruBrowser(origins);
}

async function onPermissionsRemoved() {
    const modified = await syncWithBrowserPermissions(true);
    if ( modified === false ) { return false; }
    await registerContentScripts(true);
    return true;
}

let backgroundMutationTail = Promise.resolve();
let backgroundMutationError;
let foregroundRulesetReconciliationRequired = false;

function queueBackgroundMutation(operation) {
    const result = backgroundMutationTail
        .catch(( ) => undefined)
        .then(operation);
    backgroundMutationTail = result.then(
        ( ) => { backgroundMutationError = undefined; },
        reason => { backgroundMutationError = reason; }
    );
    return result;
}

async function waitForBackgroundMutations() {
    for (;;) {
        const pending = backgroundMutationTail;
        await pending;
        if ( pending === backgroundMutationTail ) { break; }
    }
    if ( backgroundMutationError !== undefined ) {
        throw backgroundMutationError;
    }
}

function onPermissionsChanged(op, permissions) {
    const pendingDetails = op === 'added' ? pendingPermissionRequest : undefined;
    if ( op === 'added' ) {
        pendingPermissionRequest = undefined;
    }
    return queueBackgroundMutation(async ( ) => {
        await ensureFullyInitialized();
        return op === 'removed'
            ? onPermissionsRemoved()
            : onPermissionsAdded(permissions, pendingDetails);
    });
}

/******************************************************************************/

async function applyRulesets(rulesets) {
    const result = await enableRulesets(
        rulesets,
        true,
        webextFlavor !== 'safari'
    );
    if ( result.foregroundReconciliationRequired ) {
        foregroundRulesetReconciliationRequired = true;
        throw new Error('Foreground ruleset reconciliation is required');
    }
    if ( result.error ) { throw new Error(result.error); }
    const enabledRulesets = result.enabledRulesets || [];
    rulesetConfig.enabledRulesets = enabledRulesets;
    await saveRulesetConfig();
    // Converge imported compiled filters even when the persisted enabled bits
    // already match. A previous process may have died after that write but
    // before compilation/script registration completed.
    await updateCompiledFilters();
    await Promise.all([
        registerContentScripts(true),
        registerUserScripts(),
        updateUserRules(true),
    ]);
    broadcastMessage({ enabledRulesets: rulesetConfig.enabledRulesets });
}

async function reconcileCustomFilterState() {
    await Promise.all([
        registerContentScripts(true),
        updateCompiledFilters().then(( ) => registerUserScripts()),
    ]);
}

const SETTINGS_RESTORE_JOURNAL_KEY = 'floorp.settingsRestoreJournal.v1';

async function restoreRolledBackSettingsSideEffects() {
    if ( canShowBlockedCount ) {
        await dnr.setExtensionActionOptions({
            displayActionCountAsBadgeText: rulesetConfig.showBlockedCount,
        });
    }
    await resetJobsAlarm();
}

async function reconcileSettingsState({
    reloadStorage = true,
    fullDNR = true,
    resetSession = false,
    allowStaticMutation = webextFlavor !== 'safari',
} = {}) {
    if ( reloadStorage ) {
        if ( resetSession ) {
            await sessionClear();
            resetSafariRealmReadiness();
        }
        await loadRulesetConfig();
    }
    await getFilteringModeDetails(true, true);
    const enabledResult = await enableRulesets(
        rulesetConfig.enabledRulesets,
        true,
        allowStaticMutation
    );
    if ( enabledResult.foregroundReconciliationRequired === true ) {
        foregroundRulesetReconciliationRequired = true;
        return { foregroundReconciliationRequired: true };
    }
    if ( enabledResult.error ) {
        throw new Error(enabledResult.error);
    }
    if ( Array.isArray(enabledResult.enabledRulesets) === false ) {
        throw new Error('Enabled ruleset readback was unavailable');
    }
    rulesetConfig.enabledRulesets = enabledResult.enabledRulesets;
    await saveRulesetConfig();
    if ( fullDNR && enabledResult.stockUpdated !== true ) {
        const dnrResult = await updateDynamicAndSessionRules();
        if ( dnrResult?.error ) { throw new Error(dnrResult.error); }
    } else if ( fullDNR === false ) {
        const sessionResult = await updateSessionRules();
        if ( sessionResult?.error ) { throw new Error(sessionResult.error); }
    }
    await updateCompiledFilters();
    await updateUserRules(true);
    const [ effectiveUserRules, storedUserRuleCount ] = await Promise.all([
        getEffectiveUserRules(),
        localRead('userDnrRuleCount'),
    ]);
    if ( (storedUserRuleCount || 0) !== effectiveUserRules.length ) {
        throw new Error('User-rule DNR readback mismatch');
    }
    await Promise.all([
        registerContentScripts(true),
        registerUserScripts(),
    ]);
    toggleDeveloperMode(rulesetConfig.developerMode);
    const confirmedRulesets = await getEnabledRulesets();
    const expected = rulesetConfig.enabledRulesets.slice().sort();
    const actual = confirmedRulesets.slice().sort();
    if ( JSON.stringify(actual) !== JSON.stringify(expected) ) {
        throw new Error('Settings restore ruleset readback mismatch');
    }
    const defaultFilteringMode = await getDefaultFilteringMode();
    // Re-publish the authoritative state after either a commit or rollback.
    // A different dashboard surface may otherwise retain an intermediate
    // restore broadcast even though durable protection was rolled back.
    broadcastMessage({
        autoReload: rulesetConfig.autoReload,
        defaultFilteringMode,
        developerMode: rulesetConfig.developerMode,
        enabledRulesets: confirmedRulesets,
        popupBlockMode: rulesetConfig.popupBlockMode,
        showBlockedCount: rulesetConfig.showBlockedCount,
        strictBlockMode: rulesetConfig.strictBlockMode,
    });
    foregroundRulesetReconciliationRequired = false;
    return { ready: true };
}

async function validateSettingsRestore(targetConfig) {
    if (
        typeof targetConfig !== 'object' ||
        targetConfig === null ||
        Array.isArray(targetConfig)
    ) {
        throw new Error('Settings restore DNR preflight failed: backup must be an object');
    }
    const dnrRules = targetConfig.dnrRules;
    if ( dnrRules === undefined ) {
        return validateUserDnrRules('', targetConfig.developerMode === true);
    }
    if (
        Array.isArray(dnrRules) === false ||
        dnrRules.some(line => typeof line !== 'string')
    ) {
        throw new Error(
            'Settings restore DNR preflight failed: dnrRules must be a string array'
        );
    }
    return validateUserDnrRules(
        dnrRules.join('\n'),
        targetConfig.developerMode === true
    );
}

async function beginSettingsRestore() {
    const existing = await localRead(SETTINGS_RESTORE_JOURNAL_KEY);
    if ( existing instanceof Object ) {
        const rollback = await rollbackSettingsRestore(existing.id);
        if ( rollback?.foregroundReconciliationRequired === true ) {
            return rollback;
        }
        if ( rollback?.rolledBack !== true ) {
            throw new Error('Interrupted settings rollback response was invalid');
        }
    }
    const beforeLocal = await localSnapshot([ SETTINGS_RESTORE_JOURNAL_KEY ]);
    const id = crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`;
    await localWrite(SETTINGS_RESTORE_JOURNAL_KEY, {
        version: 1,
        id,
        phase: 'applying',
        beforeLocal,
    });
    return { id };
}

async function commitSettingsRestore(id) {
    const journal = await localRead(SETTINGS_RESTORE_JOURNAL_KEY);
    if ( journal?.id !== id ) {
        throw new Error('Settings restore journal does not match');
    }
    const result = await reconcileSettingsState({
        reloadStorage: false,
        fullDNR: true,
    });
    if ( result?.foregroundReconciliationRequired ) {
        return result;
    }
    await localRemove(SETTINGS_RESTORE_JOURNAL_KEY);
    return { committed: true };
}

async function rollbackSettingsRestore(id) {
    const journal = await localRead(SETTINGS_RESTORE_JOURNAL_KEY);
    if ( journal instanceof Object === false || journal.id !== id ) {
        throw new Error('Settings restore journal does not match');
    }
    await localWrite(SETTINGS_RESTORE_JOURNAL_KEY, {
        ...journal,
        phase: 'rollingBack',
    });
    await localReplace(journal.beforeLocal, [ SETTINGS_RESTORE_JOURNAL_KEY ]);
    const result = await reconcileSettingsState({ resetSession: true });
    if ( result?.foregroundReconciliationRequired ) {
        return result;
    }
    await restoreRolledBackSettingsSideEffects();
    await localRemove(SETTINGS_RESTORE_JOURNAL_KEY);
    return { rolledBack: true };
}

async function reconcileDashboardState() {
    const result = await reconcileSettingsState({
        reloadStorage: true,
        fullDNR: true,
    });
    if ( result?.foregroundReconciliationRequired ) {
        return {
            ready: false,
            foregroundReconciliationRequired: true,
            error: 'Foreground ruleset reconciliation is required',
        };
    }
    backgroundMutationError = undefined;
    return { ready: true };
}

let protectionRecoveryTail = Promise.resolve();

function recoverProtectionState() {
    const operation = protectionRecoveryTail
        .catch(( ) => undefined)
        .then(async ( ) => {
            const journal = await localRead(SETTINGS_RESTORE_JOURNAL_KEY);
            if ( journal instanceof Object ) {
                await rollbackSettingsRestore(journal.id);
            } else {
                const result = await reconcileSettingsState({
                    reloadStorage: true,
                    fullDNR: true,
                });
                if ( result?.foregroundReconciliationRequired ) {
                    throw new Error('Foreground ruleset reconciliation is required');
                }
            }
            backgroundMutationError = undefined;
        });
    protectionRecoveryTail = operation.catch(( ) => undefined);
    return operation;
}

async function mutateFilteringModeAndScripts(mutation) {
    const beforeDetails = await getFilteringModeDetails(true);
    try {
        const result = await mutation();
        await Promise.all([ registerContentScripts(true), registerUserScripts() ]);
        return result;
    } catch(reason) {
        try {
            await setFilteringModeDetails(beforeDetails, true);
            await Promise.all([ registerContentScripts(true), registerUserScripts() ]);
        } catch(rollbackReason) {
            throw new Error(`${reason}; filtering-mode rollback failed: ${rollbackReason}`);
        }
        throw reason;
    }
}

/******************************************************************************/

async function setDeveloperMode(state) {
    const beforeState = rulesetConfig.developerMode;
    try {
        rulesetConfig.developerMode = state === true;
        toggleDeveloperMode(rulesetConfig.developerMode);
        await saveRulesetConfig();
        await Promise.all([
            updateUserRules(true),
            registerUserScripts(),
        ]);
        broadcastMessage({ developerMode: rulesetConfig.developerMode });
        return rulesetConfig.developerMode;
    } catch(reason) {
        rulesetConfig.developerMode = beforeState;
        toggleDeveloperMode(beforeState);
        try {
            await saveRulesetConfig();
            await Promise.all([
                updateUserRules(true),
                registerUserScripts(),
            ]);
        } catch(rollbackReason) {
            throw new AggregateError(
                [ reason, rollbackReason ],
                'Developer-mode update and rollback both failed'
            );
        }
        throw reason;
    }
}

/******************************************************************************/

async function onMessage(request, sender) {

    const tabId = sender?.tab?.id ?? false;
    const frameId = tabId && (sender?.frameId ?? false);

    // Does not require extension to be fully initialized

    // Does not require a trusted origin.

    switch ( request.what ) {

    case 'insertCSS':
        if ( frameId === false ) { return false; }
        // https://bugs.webkit.org/show_bug.cgi?id=262491
        if ( frameId !== 0 && webextFlavor === 'safari' ) { return; }
        return browser.scripting.insertCSS({
            css: request.css,
            origin: 'USER',
            target: { tabId, frameIds: [ frameId ] },
        }).catch(reason => {
            ubolErr(`insertCSS/${reason}`);
        });

    case 'removeCSS':
        if ( frameId === false ) { return false; }
        // https://bugs.webkit.org/show_bug.cgi?id=262491
        if ( frameId !== 0 && webextFlavor === 'safari' ) { return; }
        return browser.scripting.removeCSS({
            css: request.css,
            origin: 'USER',
            target: { tabId, frameIds: [ frameId ] },
        }).catch(reason => {
            ubolErr(`removeCSS/${reason}`);
        });

    case 'injectCSSProceduralAPI':
        return browser.scripting.executeScript({
            files: [ '/js/scripting/css-procedural-api.js' ],
            target: { tabId, frameIds: [ frameId ] },
            injectImmediately: true,
        }).catch(reason => {
            ubolErr(`executeScript/${reason}`);
        });

    default:
        break;
    }

    if ( request.what === 'floorpFinalizeForegroundReconciliation' ) {
        if ( sender?.id !== runtime.id ) { return false; }
        if ( sender?.origin?.toLowerCase() !== UBOL_ORIGIN ) { return false; }
        try {
            // The foreground page owns a separate JS realm, so its successful
            // static-ruleset mutation cannot update this background realm's
            // in-memory seen-realm cache. The foreground wrapper already
            // removed the session marker before the mutation; mirror that
            // invalidation here before allowing navigation readiness again.
            resetSafariRealmReadiness();
            const journal = await localRead(SETTINGS_RESTORE_JOURNAL_KEY);
            let result;
            if ( journal?.phase === 'rollingBack' ) {
                result = await rollbackSettingsRestore(journal.id);
            } else {
                result = await reconcileSettingsState({
                    reloadStorage: true,
                    fullDNR: true,
                    allowStaticMutation: false,
                });
            }
            if ( result?.foregroundReconciliationRequired ) {
                return {
                    ready: false,
                    version: getCurrentVersion(),
                    foregroundReconciliationRequired: true,
                    error: 'Foreground ruleset reconciliation did not converge',
                };
            }
            foregroundRulesetReconciliationRequired = false;
            backgroundMutationError = undefined;
            releaseRealmRulesetStartupGate();
            return {
                ready: true,
                version: getCurrentVersion(),
                foregroundReconciliationRequired: false,
                rolledBack: result?.rolledBack === true,
            };
        } catch(reason) {
            foregroundRulesetReconciliationRequired = true;
            return {
                ready: false,
                version: getCurrentVersion(),
                foregroundReconciliationRequired: true,
                error: `${reason}`,
            };
        }
    }

    if ( request.what === 'floorpReadiness' ) {
        if ( sender?.id !== runtime.id ) { return false; }
        if ( sender?.origin?.toLowerCase() !== UBOL_ORIGIN ) { return false; }
        const readinessErrors = [];
        try {
            await ensureFullyInitialized();
        } catch(reason) {
            readinessErrors.push(reason);
        }
        if ( foregroundRulesetReconciliationRequired ) {
            return {
                ready: false,
                version: getCurrentVersion(),
                foregroundReconciliationRequired: true,
                error: 'Foreground ruleset reconciliation is required',
            };
        }
        try {
            await waitForRealmRulesetUpdates();
        } catch(reason) {
            readinessErrors.push(reason);
        }
        try {
            await waitForBackgroundMutations();
        } catch(reason) {
            try {
                await recoverProtectionState();
            } catch(recoveryReason) {
                readinessErrors.push(reason, recoveryReason);
            }
        }
        const restoreJournal = await localRead(SETTINGS_RESTORE_JOURNAL_KEY);
        if ( restoreJournal instanceof Object ) {
            readinessErrors.push(new Error('Settings restore recovery is pending'));
        }
        if ( readinessErrors.length !== 0 ) {
            ubolErr(readinessErrors[0]);
            return {
                ready: false,
                version: getCurrentVersion(),
                error: `${readinessErrors[0]}`,
            };
        }
        return { ready: true, version: getCurrentVersion() };
    }

    // Requires extension to be fully initialized

    await ensureFullyInitialized();

    // Does not require a trusted origin.

    switch ( request.what ) {

    case 'toggleToolbarIcon': {
        if ( tabId ) {
            toggleToolbarIcon(tabId);
        }
        return;
    }

    case 'startCustomFilters':
        if ( frameId === false ) { return; }
        return startCustomFilters(tabId, frameId);

    case 'terminateCustomFilters':
        if ( frameId === false ) { return; }
        return terminateCustomFilters(tabId, frameId);

    case 'injectCustomFilters':
        if ( frameId === false ) { return; }
        return injectCustomFilters(tabId, frameId, request.hostname);

    default:
        break;
    }

    // Requires a trusted origin.

    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/runtime/MessageSender
    //   Firefox API does not set `sender.origin`
    const isTrustedOrigin = sender?.origin === undefined ||
        sender.origin.toLowerCase() === UBOL_ORIGIN;
    if ( isTrustedOrigin === false ) { return; }

    switch ( request.what ) {

    case 'validateSettingsRestore':
        return validateSettingsRestore(request.targetConfig);

    case 'beginSettingsRestore':
        return beginSettingsRestore();

    case 'commitSettingsRestore':
        return commitSettingsRestore(request.id);

    case 'rollbackSettingsRestore':
        return rollbackSettingsRestore(request.id);

    case 'floorpReconcileDashboardState':
        return reconcileDashboardState();

    case 'applyRulesets': {
        await applyRulesets(request.enabledRulesets);
        if ( request.toRemove ) {
            await removeImportedLists(request.toRemove);
        }
        return;
    }

    case 'removeDisabledImportedLists': {
        const enabled = new Set(await getEnabledRulesets());
        const toRemove = (request.rulesetIds || []).filter(
            id => enabled.has(id) === false
        );
        if ( toRemove.length !== 0 ) {
            await removeImportedLists(toRemove);
        }
        return { ready: true };
    }

    case 'getDefaultConfig': {
        const rulesets = await getDefaultRulesetsFromEnv();
        return {
            autoReload: defaultConfig.autoReload,
            developerMode: defaultConfig.developerMode,
            showBlockedCount: defaultConfig.showBlockedCount,
            strictBlockMode: defaultConfig.strictBlockMode,
            popupBlockMode: defaultConfig.popupBlockMode,
            rulesets,
            filteringModes: Object.assign(defaultFilteringModes),
        };
    }

    case 'getCurrentConfig':
        return rulesetConfig;

    case 'getOptionsPageData': {
        const [
            hasOmnipotence,
            defaultFilteringMode,
            rulesetDetails,
            enabledRulesets,
            adminRulesets,
            disabledFeatures,
        ] = await Promise.all([
            hasBroadHostPermissions(),
            getDefaultFilteringMode(),
            getRulesetDetails(),
            getEnabledRulesets(),
            getAdminRulesets(),
            adminReadEx('disabledFeatures'),
        ]);
        process.firstRun = false;
        return {
            hasOmnipotence,
            defaultFilteringMode,
            enabledRulesets,
            adminRulesets,
            maxNumberOfEnabledRulesets: dnr.MAX_NUMBER_OF_ENABLED_STATIC_RULESETS,
            rulesetDetails: Array.from(rulesetDetails.values()),
            autoReload: rulesetConfig.autoReload,
            showBlockedCount: rulesetConfig.showBlockedCount,
            canShowBlockedCount,
            strictBlockMode: rulesetConfig.strictBlockMode,
            popupBlockMode: rulesetConfig.popupBlockMode,
            firstRun: process.firstRun,
            isSideloaded,
            developerMode: rulesetConfig.developerMode,
            disabledFeatures,
            supportsCompiledFilters: supportsOffscreenDocument,
            supportsUserScripts: supportsUserScripts(),
        };
    }

    case 'getEnabledRulesets':
        return getEnabledRulesets();

    case 'getRulesetDetails': {
        const rulesetDetails = await getRulesetDetails();
        return Array.from(rulesetDetails.values());
    }

    case 'getEnabledRulesetsDetails':
        return getEnabledRulesetsDetails();

    case 'getRulesetRules':
        return getRulesetRules(request.id);

    case 'hasBroadHostPermissions':
        return hasBroadHostPermissions();

    case 'setAutoReload': {
        const beforeState = rulesetConfig.autoReload;
        try {
            rulesetConfig.autoReload = request.state === true;
            await saveRulesetConfig();
        } catch(reason) {
            rulesetConfig.autoReload = beforeState;
            await saveRulesetConfig().catch(( ) => undefined);
            throw reason;
        }
        broadcastMessage({ autoReload: rulesetConfig.autoReload });
        return;
    }

    case 'setShowBlockedCount': {
        const beforeState = rulesetConfig.showBlockedCount;
        try {
            rulesetConfig.showBlockedCount = request.state === true;
            if ( canShowBlockedCount ) {
                await dnr.setExtensionActionOptions({
                    displayActionCountAsBadgeText: rulesetConfig.showBlockedCount,
                });
            }
            await saveRulesetConfig();
        } catch(reason) {
            rulesetConfig.showBlockedCount = beforeState;
            if ( canShowBlockedCount ) {
                await dnr.setExtensionActionOptions({
                    displayActionCountAsBadgeText: beforeState,
                }).catch(( ) => undefined);
            }
            await saveRulesetConfig().catch(( ) => undefined);
            throw reason;
        }
        broadcastMessage({ showBlockedCount: rulesetConfig.showBlockedCount });
        return;
    }

    case 'setStrictBlockMode': {
        const beforeState = rulesetConfig.strictBlockMode;
        try {
            const result = await setStrictBlockMode(request.state, true);
            if ( result?.error ) { throw new Error(result.error); }
        } catch(reason) {
            try {
                const rollback = await setStrictBlockMode(beforeState, true);
                if ( rollback?.error ) { throw new Error(rollback.error); }
            } catch(rollbackReason) {
                throw new Error(`${reason}; strict-block rollback failed: ${rollbackReason}`);
            }
            throw reason;
        }
        broadcastMessage({ strictBlockMode: rulesetConfig.strictBlockMode });
        return;
    }

    case 'setPopupBlockMode': {
        const beforeState = rulesetConfig.popupBlockMode;
        try {
            await setPopupBlockMode(request.state, true);
            await registerContentScripts(true);
        } catch(reason) {
            try {
                await setPopupBlockMode(beforeState, true);
                await registerContentScripts(true);
            } catch(rollbackReason) {
                throw new Error(`${reason}; popup-mode rollback failed: ${rollbackReason}`);
            }
            throw reason;
        }
        broadcastMessage({ popupBlockMode: rulesetConfig.popupBlockMode });
        return;
    }

    case 'setDeveloperMode':
        return setDeveloperMode(request.state);

    case 'popupPanelData': {
        const results = await Promise.all([
            hasBroadHostPermissions(),
            getFilteringMode(request.hostname),
            adminReadEx('disabledFeatures'),
            hasCustomFilters(request.hostname),
        ]);
        return {
            hasOmnipotence: results[0],
            level: results[1],
            autoReload: rulesetConfig.autoReload,
            isSideloaded,
            developerMode: rulesetConfig.developerMode,
            disabledFeatures: results[2],
            hasCustomFilters: results[3],
        };
    }

    case 'getFilteringMode': {
        return getFilteringMode(request.hostname);
    }

    case 'gotoURL': {
        const windowId = Number.isInteger(request.windowId)
            ? request.windowId
            : sender?.tab?.windowId;
        const incognito = typeof request.incognito === 'boolean'
            ? request.incognito
            : sender?.tab?.incognito;
        try {
            const result = await gotoURL(request.url, request.type, windowId, incognito);
            return { opened: true, ...result };
        } catch(reason) {
            const error = `${reason}`;
            ubolErr(`gotoURL/${error}`);
            return { opened: false, error };
        }
    }

    case 'setFilteringMode': {
        const beforeLevel = await getFilteringMode(request.hostname);
        if ( request.level === beforeLevel ) { return beforeLevel; }
        const afterLevel = await mutateFilteringModeAndScripts(( ) =>
            setFilteringMode(request.hostname, request.level, true)
        );
        return afterLevel;
    }

    case 'setPendingFilteringMode':
        pendingPermissionRequest = request;
        return;

    case 'getDefaultFilteringMode': {
        return getDefaultFilteringMode();
    }

    case 'setDefaultFilteringMode': {
        const beforeLevel = await getDefaultFilteringMode();
        if ( request.level === beforeLevel ) { return beforeLevel; }
        const afterLevel = await mutateFilteringModeAndScripts(( ) =>
            setDefaultFilteringMode(request.level, true)
        );
        return afterLevel;
    }

    case 'getFilteringModeDetails':
        return getFilteringModeDetails(true);

    case 'setFilteringModeDetails': {
        await mutateFilteringModeAndScripts(( ) =>
            setFilteringModeDetails(request.modes, true)
        );
        const defaultFilteringMode = await getDefaultFilteringMode();
        broadcastMessage({ defaultFilteringMode });
        return getFilteringModeDetails(true);
    }

    case 'excludeFromStrictBlock':
        return excludeFromStrictBlock(request.hostname, request.permanent);

    case 'getMatchedRules':
        return getMatchedRules(request.tabId);

    case 'showMatchedRules':
        try {
            await browser.tabs.create({
                active: true,
                url: `/matched-rules.html?tab=${request.tabId}`,
                ...(Number.isInteger(request.windowId) ? { windowId: request.windowId } : {}),
            });
            return { opened: true };
        } catch(reason) {
            const error = `${reason}`;
            ubolErr(`tabs.create/${error}`);
            return { opened: false, error };
        }

    case 'getAllDynamicRules':
        return dnr.getDynamicRules();

    case 'getAllSessionRules':
        return dnr.getSessionRules();

    case 'getEffectiveUserRules':
        return getEffectiveUserRules();

    case 'updateUserDnrRules':
        return updateUserRules(true);

    case 'getAllCustomFilters':
        return getAllCustomFilters();

    case 'replaceCustomFilters': {
        const { before, after } = request;
        if (
            before instanceof Object === false ||
            after instanceof Object === false ||
            typeof before.hostname !== 'string' ||
            typeof after.hostname !== 'string' ||
            Array.isArray(before.selectors) === false ||
            Array.isArray(after.selectors) === false
        ) {
            throw new Error('Invalid custom-filter replacement');
        }
        return replaceCustomFiltersAtomically(
            before,
            after,
            reconcileCustomFilterState
        );
    }

    case 'replaceAllCustomFilters': {
        if ( Array.isArray(request.entries) === false ) {
            throw new Error('Invalid custom-filter replacement');
        }
        return replaceAllCustomFiltersAtomically(
            request.entries,
            reconcileCustomFilterState
        );
    }

    case 'addCustomFilters': {
        return mutateCustomFiltersAtomically(
            ( ) => addCustomFilters(request.hostname, request.selectors),
            reconcileCustomFilterState
        );
    }

    case 'addManyCustomFilters': {
        return mutateCustomFiltersAtomically(async ( ) => {
            const results = [];
            for ( const [ hostname, selectors ] of request.entries ) {
                if ( typeof hostname !== 'string' || hostname === '' ) { continue; }
                if ( Array.isArray(selectors) === false || selectors.length === 0 ) {
                    continue;
                }
                results.push(await addCustomFilters(hostname, selectors));
            }
            return results.some(Boolean);
        }, reconcileCustomFilterState);
    }

    case 'removeCustomFilters': {
        return mutateCustomFiltersAtomically(
            ( ) => removeCustomFilters(request.hostname, request.selectors),
            reconcileCustomFilterState
        );
    }

    case 'removeAllCustomFilters': {
        return mutateCustomFiltersAtomically(
            ( ) => removeAllCustomFilters(request.hostname),
            reconcileCustomFilterState
        );
    }

    case 'getSandboxFilters':
        return getSandboxFilters();

    case 'setSandboxFilters': {
        const before = await getSandboxFilters();
        try {
            await setSandboxFilters(request.text);
            await updateCompiledFilters();
            await Promise.all([ registerUserScripts(), updateUserRules(true) ]);
            return;
        } catch(reason) {
            try {
                await setSandboxFilters(before);
                await updateCompiledFilters();
                await Promise.all([ registerUserScripts(), updateUserRules(true) ]);
            } catch(rollbackReason) {
                throw new AggregateError(
                    [ reason, rollbackReason ],
                    'Sandbox-filter update and rollback both failed'
                );
            }
            throw reason;
        }
    }

    case 'customFiltersFromHostname':
        return customFiltersFromHostname(request.hostname);

    case 'getRegisteredContentScripts':
        return getRegisteredContentScripts();

    case 'getConsoleOutput':
        return getConsoleOutput();

    case 'importFilterList': {
        const modified = await addImportedLists([ request.url ]);
        if ( modified !== true ) { break; }
        const rulesets = await getEnabledRulesets();
        rulesets.push(request.url);
        await applyRulesets(rulesets);
        return;
    }

    case 'getImportedLists': {
        return getImportedLists();
    }

    case 'updateImportedLists': {
        const count = await updateImportedLists();
        if ( count === 0 ) { break; }
        await updateCompiledFilters();
        await Promise.all([ registerUserScripts(), updateUserRules(true) ]);
        return;
    }

    case 'pruneCSSCache': {
        return pruneCSSCache();
    }

    // This is used to ensure we are not suspended while busy fetching filter
    // lists from remote servers.
    case 'keepAlive':
        return;

    default:
        break;
    }
}

/******************************************************************************/

function onCommand(command, tab) {
    switch ( command ) {
    case 'enter-zapper-mode': {
        if ( browser.scripting === undefined ) { return; }
        browser.scripting.executeScript({
            files: [ '/js/scripting/tool-overlay.js', '/js/scripting/zapper.js' ],
            target: { tabId: tab.id },
        });
        break;
    }
    case 'enter-picker-mode': {
        if ( browser.scripting === undefined ) { return; }
        browser.scripting.executeScript({
            files: [
                '/js/scripting/css-procedural-api.js',
                '/js/scripting/tool-overlay.js',
                '/js/scripting/picker.js',
            ],
            target: { tabId: tab.id },
        });
        break;
    }
    default:
        break;
    }
}

/******************************************************************************/

async function startSession(allowStaticMutation = true) {
    const currentVersion = getCurrentVersion();
    const isNewVersion = currentVersion !== rulesetConfig.version;

    // Admin settings override user settings
    await loadAdminConfig();

    // The default rulesets may have changed, find out new ruleset to enable,
    // obsolete ruleset to remove.
    if ( isNewVersion ) {
        ubolLog(`Version change: ${rulesetConfig.version} => ${currentVersion}`);
        rulesetConfig.version = currentVersion;
        await patchDefaultRulesets();
        await saveRulesetConfig();
    }

    const {
        stockUpdated,
        importedUpdated,
        enabledRulesets,
        error: enableRulesetsError,
        foregroundReconciliationRequired,
    } = await enableRulesets(
        rulesetConfig.enabledRulesets,
        true,
        allowStaticMutation
    );
    if ( foregroundReconciliationRequired ) {
        return { foregroundReconciliationRequired: true };
    }
    if ( enableRulesetsError ) { throw new Error(enableRulesetsError); }
    if ( stockUpdated || importedUpdated ) {
        rulesetConfig.enabledRulesets = enabledRulesets;
        await saveRulesetConfig();
    }

    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/declarativeNetRequest#rulesets
    // "The set of enabled static rulesets is persisted across sessions but not across extension updates"
    // "[Dynamic] rules persist across sessions and extension updates"
    // "[Session] rules do not persist across browser sessions"
    // enableRulesets() already rebuilds dynamic/session rules after a static
    // ruleset change. Avoid repeating the expensive WebKit compilation on
    // first launch, where a single long-lived readiness reply can otherwise
    // outlive the MV3 background page.
    if ( stockUpdated !== true && isNewVersion ) {
        const result = await updateDynamicAndSessionRules();
        if ( result?.error ) { throw new Error(result.error); }
    } else if ( stockUpdated !== true ) {
        const result = await updateSessionRules();
        if ( result?.error ) { throw new Error(result.error); }
    }

    // Permissions may have been removed while the extension was disabled
    const permissionsUpdated = await syncWithBrowserPermissions(true);

    // Toggling "user scripts" permission doesn't cause a permissions change
    // event.
    const userScriptsChanged = supportsUserScripts() !== rulesetConfig.userScripts;
    if ( userScriptsChanged ) {
        rulesetConfig.userScripts = !rulesetConfig.userScripts;
        await saveRulesetConfig();
    }

    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/scripting/RegisteredContentScript#persistacrosssessions
    // "When an extension updates, content scripts are cleared"
    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/userScripts#extension_updates
    // "User scripts are cleared when an extension updates"
    const promises = [];
    const shouldInject = isNewVersion || permissionsUpdated ||
        isSideloaded && rulesetConfig.developerMode;
    if ( shouldInject || stockUpdated ) {
        promises.push(registerContentScripts(true));
    }
    if ( importedUpdated ) {
        promises.push(
            updateCompiledFilters().then(( ) =>
                Promise.all([ registerUserScripts(), updateUserRules(true) ])
            )
        );
    } else if ( shouldInject ) {
        promises.push(registerUserScripts(), updateUserRules(true));
    } else if ( userScriptsChanged ) {
        promises.push(registerUserScripts());
    }
    if ( promises.length ) {
        await Promise.all(promises);
    }

    // Cosmetic filtering-related content scripts cache fitlering data in
    // session storage.
    await sessionAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });

    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/declarativeNetRequest
    //   Firefox API does not support `dnr.setExtensionActionOptions`
    if ( canShowBlockedCount ) {
        await dnr.setExtensionActionOptions({
            displayActionCountAsBadgeText: rulesetConfig.showBlockedCount,
        });
    }

    // Switch to basic filtering if uBOL doesn't have broad permissions at
    // install time.
    if ( process.firstRun ) {
        const enableOptimal = await hasBroadHostPermissions();
        if ( enableOptimal === false ) {
            const afterLevel = await setDefaultFilteringMode(MODE_BASIC, true);
            if ( afterLevel === MODE_BASIC ) {
                await registerContentScripts(true);
                process.firstRun = false;
            }
        }
    }

    // Required to ensure up to date properties are available when needed
    const disabledFeatures = await adminReadEx('disabledFeatures', true);
    if ( Array.isArray(disabledFeatures) ) {
        if ( disabledFeatures.includes('develop') ) {
            if ( rulesetConfig.developerMode ) {
                await setDeveloperMode(false);
            }
        }
    }

    return { ready: true };
}

/******************************************************************************/

async function start() {
    if ( supportsUserScripts() && runtime.onUserScriptMessage ) {
        await browser.userScripts.configureWorld({ messaging: true });
    }
    const restoreJournal = await localRead(SETTINGS_RESTORE_JOURNAL_KEY);
    if ( restoreJournal instanceof Object ) {
        const rollbackResult = await rollbackSettingsRestore(restoreJournal.id);
        if ( rollbackResult?.foregroundReconciliationRequired ) {
            foregroundRulesetReconciliationRequired = true;
            return;
        }
    }
    await loadRulesetConfig();

    if ( process.wakeupRun === false ) {
        const sessionResult = await startSession(webextFlavor !== 'safari');
        if ( sessionResult?.foregroundReconciliationRequired ) {
            foregroundRulesetReconciliationRequired = true;
            return;
        }
    }

    // A background process may be evicted at any await boundary of an earlier
    // mutation. Reconcile every protected surface from durable local state on
    // every wake before readiness can become true.
    const reconcileResult = await reconcileSettingsState({
        reloadStorage: true,
        fullDNR: true,
    });
    if ( reconcileResult?.foregroundReconciliationRequired ) { return; }

    toggleDeveloperMode(rulesetConfig.developerMode);
}

/******************************************************************************/

// https://github.com/uBlockOrigin/uBOL-home/issues/199
// Force a restart of the extension once when an "internal error" occurs

const floorpInitialization = start().then(async ( ) => {
    await localRemove('goodStart');
});
floorpInitialization.then(
    ( ) => {
        if ( foregroundRulesetReconciliationRequired === false ) {
            releaseRealmRulesetStartupGate();
        }
    },
    releaseRealmRulesetStartupGate
);

const isFullyInitialized = floorpInitialization.then(( ) => false);
void isFullyInitialized.catch(( ) => undefined);

async function ensureFullyInitialized() {
    try {
        return await isFullyInitialized;
    } catch(reason) {
        ubolErr(reason);
        await recoverProtectionState();
        return false;
    }
}

const backgroundMutationMessages = new Set([
    'applyRulesets',
    'beginSettingsRestore',
    'commitSettingsRestore',
    'rollbackSettingsRestore',
    'floorpReconcileDashboardState',
    'floorpFinalizeForegroundReconciliation',
    'removeDisabledImportedLists',
    'setAutoReload',
    'setShowBlockedCount',
    'setStrictBlockMode',
    'setPopupBlockMode',
    'setDeveloperMode',
    'setFilteringMode',
    'setPendingFilteringMode',
    'setDefaultFilteringMode',
    'setFilteringModeDetails',
    'excludeFromStrictBlock',
    'updateUserDnrRules',
    'replaceCustomFilters',
    'replaceAllCustomFilters',
    'addCustomFilters',
    'addManyCustomFilters',
    'removeCustomFilters',
    'removeAllCustomFilters',
    'setSandboxFilters',
    'importFilterList',
    'updateImportedLists',
    'pruneCSSCache',
]);

function dispatchMessage(request, sender) {
    if ( backgroundMutationMessages.has(request.what) ) {
        return queueBackgroundMutation(( ) => onMessage(request, sender));
    }
    return onMessage(request, sender);
}

runtime.onMessage.addListener((request, sender, callback) => {
    if ( request.what.includes(':') ) { return; }
    dispatchMessage(request, sender).then(callback, reason => {
        const error = `${reason}`;
        ubolErr(`onMessage/${request.what}/${error}`);
        callback({ error });
    });
    return true;
});

if ( supportsUserScripts() && runtime.onUserScriptMessage ) {
    runtime.onUserScriptMessage.addListener((request, sender, callback) => {
        dispatchMessage(request, sender).then(callback, reason => {
            const error = `${reason}`;
            ubolErr(`onUserScriptMessage/${request.what}/${error}`);
            callback({ error });
        });
        return true;
    });
}

browser.permissions.onRemoved.addListener((...args) => {
    onPermissionsChanged('removed', ...args).catch(reason => {
        ubolErr(`permissions.onRemoved/${reason}`);
    });
});

browser.permissions.onAdded.addListener((...args) => {
    onPermissionsChanged('added', ...args).catch(reason => {
        ubolErr(`permissions.onAdded/${reason}`);
    });
});

browser.commands.onCommand.addListener((...args) => {
    ensureFullyInitialized().then(( ) => {
        onCommand(...args);
    }).catch(reason => ubolErr(`commands.onCommand/${reason}`));
});

browser.alarms.onAlarm.addListener(alarm => {
    if ( alarm.name !== 'deferredJobs' ) { return; }
    ensureFullyInitialized().then(( ) => {
        if ( process.wakeupRun === false && process.firstAlarm !== true ) {
            process.firstAlarm = true;
            return resetJobsAlarm();
        }
        processDueJobs(onMessage);
    }).catch(reason => ubolErr(`alarms.onAlarm/${reason}`));
});
