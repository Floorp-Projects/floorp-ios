/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import {
    MODE_BASIC,
    MODE_OPTIMAL,
    defaultFilteringModes,
    getDefaultFilteringMode,
    getFilteringMode,
    getFilteringModeDetails,
    persistHostPermissions,
    setDefaultFilteringMode,
    setFilteringMode,
    setFilteringModeDetails,
    syncWithBrowserPermissions,
} from './mode-manager.js';

import {
    addCustomFilters,
    assertSuccessfulScriptInjection,
    committedCustomFilterMutationSnapshot,
    committedSettingsRestoreSnapshot,
    customFilterModeStorageKeys,
    customFilterMutationJournalKey,
    customFilteringEnabledFromStorageSnapshot,
    customFilterStorageKeys,
    customFiltersFromHostname,
    getAllCustomFilters,
    getSandboxFilters,
    hasCustomFilters,
    injectCustomFilters,
    mutateCustomFiltersAtomically,
    removeAllCustomFilters,
    removeCustomFilters,
    recoverCustomFilterMutation,
    replaceAllCustomFiltersAtomically,
    replaceCustomFiltersAtomically,
    setSandboxFilters,
    settingsRestoreJournalKey,
    startCustomFilters,
    terminateCustomFilters,
} from './filter-manager.js';

import {
    addImportedLists,
    getImportedLists,
    removeImportedLists,
    updateImportedLists,
} from './imported-lists.js';

import {
    adminReadEx,
    getAdminRulesets,
    loadAdminConfig,
    resumeAdminSettingsProcessing,
    setAdminSettingsMutationRunner,
} from './admin.js';

import {
    broadcastMessage,
    hostnameFromMatch,
    hostnamesFromMatches,
} from './utils.js';

import {
    browser,
    localRead, localRemove, localReplace, localSnapshot, localWrite,
    runtime,
    sessionAccessLevel,
    sessionClear,
    supportsUserScripts,
    webextFlavor,
} from './ext.js';

import {
    defaultConfig,
    loadRulesetConfig,
    process,
    rulesetConfig,
    saveRulesetConfig,
} from './config.js';

import {
    enableRulesets,
    excludeFromStrictBlock,
    getDefaultRulesetsFromEnv,
    getEffectiveUserRules,
    getEnabledRulesets,
    getEnabledRulesetsDetails,
    getRulesetDetails,
    getRulesetRules,
    patchDefaultRulesets,
    setStrictBlockMode,
    updateDynamicAndSessionRules,
    updateSessionRules,
    validateUserDnrRules,
    updateUserRules,
} from './ruleset-manager.js';

import {
    getConsoleOutput,
    getMatchedRules,
    isSideloaded,
    toggleDeveloperMode,
    ubolErr,
    ubolLog,
} from './debug.js';

import {
    getRegisteredContentScripts,
    pruneCSSCache,
    registerContentScripts,
} from './scripting-manager.js';

import {
    gotoURL,
    hasBroadHostPermissions,
} from './ext-utils.js';

import {
    processDueJobs,
    resetJobsAlarm,
} from './alarms.js';

import {
    registerUserScripts,
    updateCompiledFilters,
} from './compiled-filters.js';

import {
    dnr,
    releaseRealmRulesetStartupGate,
    resetSafariRealmReadiness,
    waitForRealmRulesetUpdates,
} from './ext-compat.js';
import { setPopupBlockMode } from './prevent-popup.js';
import { supportsOffscreenDocument } from './ext-offscreen.js';
import { toggleToolbarIcon } from './action.js';

/******************************************************************************/

const UBOL_ORIGIN = runtime.getURL('').replace(/\/$/, '').toLowerCase();
const canShowBlockedCount = typeof dnr.setExtensionActionOptions === 'function';

let pendingPermissionRequest;

/******************************************************************************/

function getCurrentVersion() {
    return runtime.getManifest().version;
}

/******************************************************************************/

function isTrustedFloorpExtensionPageSender(sender) {
    const senderOrigin = typeof sender?.origin === 'string'
        ? sender.origin.replace(/\/$/, '').toLowerCase()
        : '';
    if ( sender?.id === runtime.id && senderOrigin === UBOL_ORIGIN ) {
        return true;
    }
    if ( typeof sender?.url !== 'string' ) { return false; }
    try {
        const senderURL = new URL(sender.url);
        const senderURLOrigin =
            `${senderURL.protocol}//${senderURL.host}`.toLowerCase();
        return senderURLOrigin === UBOL_ORIGIN;
    } catch {
        return false;
    }
}

/******************************************************************************/

async function reloadTab(tabId, url = '') {
    return new Promise(resolve => {
        self.setTimeout(( ) => {
            if ( url !== '' ) {
                browser.tabs.update(tabId, { url });
            } else {
                browser.tabs.reload(tabId);
            }
            resolve();
        }, 437);
    });
}

// When a new host permission is granted through the popup panel
async function onPermissionGrantedThruExtension(details, origins) {
    await persistHostPermissions();
    const defaultMode = await getDefaultFilteringMode();
    if ( defaultMode >= MODE_OPTIMAL ) { return; }
    if ( Array.isArray(origins) === false ) { return; }
    const hostnames = hostnamesFromMatches(origins);
    if ( hostnames.includes(details.hostname) === false ) { return; }
    const beforeLevel = await getFilteringMode(details.hostname);
    if ( beforeLevel === details.afterLevel ) { return; }
    const afterLevel = await setFilteringMode(details.hostname, details.afterLevel, true);
    if ( afterLevel !== details.afterLevel ) { return; }
    await Promise.all([
        registerContentScripts(true),
        registerUserScripts(),
    ]);
    if ( rulesetConfig.autoReload !== true ) { return; }
    await reloadTab(details.tabId, details.url);
}

// When a new host permission is granted through the browser
async function onPermissionGrantedThruBrowser(origins) {
    const modified = await syncWithBrowserPermissions(true);
    if ( modified === false ) { return; }
    await registerContentScripts(true);
    if ( rulesetConfig.autoReload !== true ) { return; }
    if ( origins.length !== 1 ) { return; }
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    const tabId = tabs?.[0]?.id;
    if ( typeof tabId !== 'number' || tabId === -1 ) { return; }
    const results = await browser.scripting.executeScript({
        target: { tabId, frameIds: [ 0 ] },
        func: ( ) => document.location.hostname,
    }).catch(( ) => {
    });
    const tabHostname = results?.[0]?.result;
    if ( typeof tabHostname !== 'string' ) { return; }
    const hostname = hostnameFromMatch(origins[0]);
    if ( tabHostname.endsWith(hostname) === false ) { return; }
    const pos = tabHostname.length - hostname.length;
    if ( pos !== 0 && tabHostname.charAt(pos-1) !== '.' ) { return; }
    await reloadTab(tabId);
}

// https://github.com/uBlockOrigin/uBOL-home/issues/280
async function onPermissionsAdded(permissions, details) {
    const { origins = [] } = permissions;
    return details !== undefined
        ? onPermissionGrantedThruExtension(details, origins)
        : onPermissionGrantedThruBrowser(origins);
}

async function onPermissionsRemoved() {
    const modified = await syncWithBrowserPermissions(true);
    if ( modified === false ) { return false; }
    await registerContentScripts(true);
    return true;
}

let backgroundMutationTail = Promise.resolve();
let backgroundMutationError;
let foregroundRulesetReconciliationRequired = false;

class SettingsRestoreConflictError extends Error {
}

function queueBackgroundMutation(operation) {
    const result = backgroundMutationTail
        .catch(( ) => undefined)
        .then(operation);
    backgroundMutationTail = result.then(
        ( ) => undefined,
        reason => {
            if ( reason instanceof SettingsRestoreConflictError === false ) {
                backgroundMutationError = reason;
            }
        }
    );
    return result;
}

async function waitForBackgroundMutations() {
    for (;;) {
        const pending = backgroundMutationTail;
        await pending;
        if ( pending === backgroundMutationTail ) { break; }
    }
    if ( backgroundMutationError !== undefined ) {
        throw backgroundMutationError;
    }
}

async function onPermissionsChanged(op, permissions) {
    const pendingDetails = op === 'added' ? pendingPermissionRequest : undefined;
    if ( op === 'added' ) {
        pendingPermissionRequest = undefined;
    }
    const pendingJournal = await readSettingsRestoreJournal();
    if ( pendingJournal instanceof Object ) { return false; }
    await ensureFullyInitialized();
    return withSettingsRestoreLock(( ) =>
        queueBackgroundMutation(async ( ) => {
            const journal = await readSettingsRestoreJournal();
            if ( journal instanceof Object ) {
                // Commit, rollback, or the next cold start resynchronizes the
                // browser-owned permission state before publishing readiness.
                return false;
            }
            return op === 'removed'
                ? onPermissionsRemoved()
                : onPermissionsAdded(permissions, pendingDetails);
        })
    );
}

/******************************************************************************/

async function applyRulesets(rulesets) {
    const result = await enableRulesets(
        rulesets,
        true,
        webextFlavor !== 'safari'
    );
    if ( result.foregroundReconciliationRequired ) {
        foregroundRulesetReconciliationRequired = true;
        throw new Error('Foreground ruleset reconciliation is required');
    }
    if ( result.error ) { throw new Error(result.error); }
    const enabledRulesets = result.enabledRulesets || [];
    rulesetConfig.enabledRulesets = enabledRulesets;
    await saveRulesetConfig();
    // Converge imported compiled filters even when the persisted enabled bits
    // already match. A previous process may have died after that write but
    // before compilation/script registration completed.
    await updateCompiledFilters();
    await Promise.all([
        registerContentScripts(true),
        registerUserScripts(),
        updateUserRules(true),
    ]);
    broadcastMessage({ enabledRulesets: rulesetConfig.enabledRulesets });
}

async function reconcileCustomFilterState() {
    await Promise.all([
        registerContentScripts(true),
        updateCompiledFilters().then(( ) => registerUserScripts()),
    ]);
}

const SETTINGS_RESTORE_JOURNAL_KEY = settingsRestoreJournalKey;
const SETTINGS_RESTORE_LOCK_NAME = 'floorp.ubol.settings-restore.v1';
const SETTINGS_RESTORE_PRESERVED_KEYS = [
    SETTINGS_RESTORE_JOURNAL_KEY,
    'dashboard.activePane',
    'dashboard.develop.editor',
    'goodStart',
    'hideUnusedFilterLists',
    'picker.view',
];
const SETTINGS_RESTORE_PRESERVED_PREFIXES = [ 'admin.', 'admin_' ];
let activeSettingsRestoreId;
let settingsRestoreLockTail = Promise.resolve();

function validateSettingsRestoreJournal(journal) {
    const isPlainObject = value => {
        if ( typeof value !== 'object' || value === null || Array.isArray(value) ) {
            return false;
        }
        const prototype = Object.getPrototypeOf(value);
        return prototype === Object.prototype || prototype === null;
    };
    if (
        isPlainObject(journal) === false ||
        journal.version !== 1 ||
        typeof journal.id !== 'string' ||
        journal.id === '' ||
        [ 'applying', 'committingForeground', 'rollingBack' ]
            .includes(journal.phase) === false ||
        isPlainObject(journal.beforeLocal) === false
    ) {
        throw new Error('Settings restore journal is invalid');
    }
    if ( Object.hasOwn(journal.beforeLocal, SETTINGS_RESTORE_JOURNAL_KEY) ) {
        throw new Error('Settings restore snapshot contains its own journal');
    }
    if ( journal.phase === 'committingForeground' ) {
        validatedSettingsRestoreRulesets(journal.targetEnabledRulesets);
    }
    return journal;
}

async function readSettingsRestoreJournal() {
    const journal = await localRead(SETTINGS_RESTORE_JOURNAL_KEY);
    if ( journal === undefined ) { return; }
    return validateSettingsRestoreJournal(journal);
}

function withSettingsRestoreLock(operation) {
    const lockManager = globalThis.navigator?.locks;
    if ( typeof lockManager?.request === 'function' ) {
        return lockManager.request(
            SETTINGS_RESTORE_LOCK_NAME,
            { mode: 'exclusive' },
            operation
        );
    }
    if ( webextFlavor === 'safari' ) {
        throw new Error('Settings restore lock is unavailable');
    }
    const current = settingsRestoreLockTail
        .catch(( ) => undefined)
        .then(operation);
    settingsRestoreLockTail = current.catch(( ) => undefined);
    return current;
}

async function foregroundReconciliationReadiness() {
    const journal = await readSettingsRestoreJournal();
    const terminalRestore =
        journal?.phase === 'committingForeground' ||
        journal?.phase === 'rollingBack';
    return {
        ready: false,
        version: getCurrentVersion(),
        foregroundReconciliationRequired: true,
        ...(terminalRestore ? { settingsRestoreId: journal.id } : {}),
        error: 'Foreground ruleset reconciliation is required',
    };
}

async function restoreRolledBackSettingsSideEffects() {
    if ( canShowBlockedCount ) {
        await dnr.setExtensionActionOptions({
            displayActionCountAsBadgeText: rulesetConfig.showBlockedCount,
        });
    }
    await resetJobsAlarm();
}

async function reconcileSettingsState({
    reloadStorage = true,
    fullDNR = true,
    resetSession = false,
    allowStaticMutation = webextFlavor !== 'safari',
} = {}) {
    if ( reloadStorage ) {
        if ( resetSession ) {
            await sessionClear();
            resetSafariRealmReadiness();
        }
        await loadRulesetConfig();
    }
    await loadAdminConfig(true);
    await syncWithBrowserPermissions(true);
    await getFilteringModeDetails(true, true);
    const enabledResult = await enableRulesets(
        rulesetConfig.enabledRulesets,
        true,
        allowStaticMutation
    );
    if ( enabledResult.foregroundReconciliationRequired === true ) {
        foregroundRulesetReconciliationRequired = true;
        return { foregroundReconciliationRequired: true };
    }
    if ( enabledResult.error ) {
        throw new Error(enabledResult.error);
    }
    if ( Array.isArray(enabledResult.enabledRulesets) === false ) {
        throw new Error('Enabled ruleset readback was unavailable');
    }
    rulesetConfig.enabledRulesets = enabledResult.enabledRulesets;
    await saveRulesetConfig();
    if ( fullDNR && enabledResult.stockUpdated !== true ) {
        const dnrResult = await updateDynamicAndSessionRules();
        if ( dnrResult?.error ) { throw new Error(dnrResult.error); }
    } else if ( fullDNR === false ) {
        const sessionResult = await updateSessionRules();
        if ( sessionResult?.error ) { throw new Error(sessionResult.error); }
    }
    await updateCompiledFilters();
    await updateUserRules(true);
    const [ effectiveUserRules, storedUserRuleCount ] = await Promise.all([
        getEffectiveUserRules(),
        localRead('userDnrRuleCount'),
    ]);
    if ( (storedUserRuleCount || 0) !== effectiveUserRules.length ) {
        throw new Error('User-rule DNR readback mismatch');
    }
    await Promise.all([
        registerContentScripts(true),
        registerUserScripts(),
    ]);
    toggleDeveloperMode(rulesetConfig.developerMode);
    const confirmedRulesets = await getEnabledRulesets();
    const expected = rulesetConfig.enabledRulesets.slice().sort();
    const actual = confirmedRulesets.slice().sort();
    if ( JSON.stringify(actual) !== JSON.stringify(expected) ) {
        throw new Error('Settings restore ruleset readback mismatch');
    }
    const defaultFilteringMode = await getDefaultFilteringMode();
    // Re-publish the authoritative state after either a commit or rollback.
    // A different dashboard surface may otherwise retain an intermediate
    // restore broadcast even though durable protection was rolled back.
    broadcastMessage({
        autoReload: rulesetConfig.autoReload,
        defaultFilteringMode,
        developerMode: rulesetConfig.developerMode,
        enabledRulesets: confirmedRulesets,
        popupBlockMode: rulesetConfig.popupBlockMode,
        showBlockedCount: rulesetConfig.showBlockedCount,
        strictBlockMode: rulesetConfig.strictBlockMode,
    });
    foregroundRulesetReconciliationRequired = false;
    backgroundMutationError = undefined;
    resumeAdminSettingsProcessing();
    return { ready: true };
}

async function validateSettingsRestore(targetConfig) {
    if (
        typeof targetConfig !== 'object' ||
        targetConfig === null ||
        Array.isArray(targetConfig)
    ) {
        throw new Error('Settings restore DNR preflight failed: backup must be an object');
    }
    const dnrRules = targetConfig.dnrRules;
    if ( dnrRules === undefined ) {
        return validateUserDnrRules('', targetConfig.developerMode === true);
    }
    if (
        Array.isArray(dnrRules) === false ||
        dnrRules.some(line => typeof line !== 'string')
    ) {
        throw new Error(
            'Settings restore DNR preflight failed: dnrRules must be a string array'
        );
    }
    return validateUserDnrRules(
        dnrRules.join('\n'),
        targetConfig.developerMode === true
    );
}

async function beginSettingsRestoreNow() {
    const existing = await readSettingsRestoreJournal();
    if ( existing instanceof Object ) {
        if ( activeSettingsRestoreId === existing.id ) {
            throw new SettingsRestoreConflictError(
                'Settings restore is already in progress'
            );
        }
        const rollback = await rollbackSettingsRestore(existing.id);
        if ( rollback?.foregroundReconciliationRequired === true ) {
            return rollback;
        }
        if ( rollback?.rolledBack !== true ) {
            throw new Error('Interrupted settings rollback response was invalid');
        }
    }
    const beforeLocal = await localSnapshot([ SETTINGS_RESTORE_JOURNAL_KEY ]);
    const id = crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`;
    await localWrite(SETTINGS_RESTORE_JOURNAL_KEY, {
        version: 1,
        id,
        phase: 'applying',
        beforeLocal,
    });
    activeSettingsRestoreId = id;
    return { id };
}

async function narrowCommittedCustomFilterRegistrations() {
    await registerContentScripts(true).catch(reason => {
        // The published selector snapshot and effective-mode gate remain
        // authoritative if Safari retains a now-superfluous broad row. A later
        // startup or mutation will converge the persistent registrations.
        ubolErr(`narrowCustomFilterRegistrations/${reason}`);
    });
}

function validatedSettingsRestoreRulesets(value) {
    if (
        Array.isArray(value) === false ||
        value.some(id => typeof id !== 'string' || id === '')
    ) {
        throw new Error('Settings restore ruleset target is invalid');
    }
    return Array.from(new Set(value));
}

async function commitSettingsRestore(id, requestedRulesets) {
    const journal = await readSettingsRestoreJournal();
    if ( journal?.id !== id ) {
        throw new Error('Settings restore journal does not match');
    }
    let targetEnabledRulesets;
    if ( journal.phase === 'applying' ) {
        targetEnabledRulesets = validatedSettingsRestoreRulesets(
            requestedRulesets
        );
        await localWrite(SETTINGS_RESTORE_JOURNAL_KEY, {
            ...journal,
            phase: 'committingForeground',
            targetEnabledRulesets,
        });
    } else if ( journal.phase === 'committingForeground' ) {
        targetEnabledRulesets = validatedSettingsRestoreRulesets(
            journal.targetEnabledRulesets
        );
        if ( requestedRulesets !== undefined ) {
            const requested = validatedSettingsRestoreRulesets(
                requestedRulesets
            );
            if ( JSON.stringify(requested) !== JSON.stringify(targetEnabledRulesets) ) {
                throw new Error('Settings restore ruleset target does not match');
            }
        }
    } else {
        throw new Error('Settings restore cannot be committed in this phase');
    }
    await loadRulesetConfig();
    rulesetConfig.enabledRulesets = targetEnabledRulesets;
    await saveRulesetConfig();
    const result = await reconcileSettingsState({
        reloadStorage: false,
        fullDNR: true,
    });
    if ( result?.foregroundReconciliationRequired ) {
        return { ...result, settingsRestoreId: id };
    }
    await localRemove(SETTINGS_RESTORE_JOURNAL_KEY);
    activeSettingsRestoreId = undefined;
    await narrowCommittedCustomFilterRegistrations();
    return { committed: true };
}

async function rollbackSettingsRestore(id) {
    const journal = await readSettingsRestoreJournal();
    if ( journal instanceof Object === false || journal.id !== id ) {
        throw new Error('Settings restore journal does not match');
    }
    await localWrite(SETTINGS_RESTORE_JOURNAL_KEY, {
        ...journal,
        phase: 'rollingBack',
    });
    await localReplace(
        journal.beforeLocal,
        SETTINGS_RESTORE_PRESERVED_KEYS,
        SETTINGS_RESTORE_PRESERVED_PREFIXES
    );
    const result = await reconcileSettingsState({ resetSession: true });
    if ( result?.foregroundReconciliationRequired ) {
        return { ...result, settingsRestoreId: id };
    }
    await restoreRolledBackSettingsSideEffects();
    await localRemove(SETTINGS_RESTORE_JOURNAL_KEY);
    activeSettingsRestoreId = undefined;
    await narrowCommittedCustomFilterRegistrations();
    return { rolledBack: true };
}

async function reconcileDashboardState() {
    const result = await reconcileSettingsState({
        reloadStorage: true,
        fullDNR: true,
    });
    if ( result?.foregroundReconciliationRequired ) {
        return {
            ready: false,
            foregroundReconciliationRequired: true,
            error: 'Foreground ruleset reconciliation is required',
        };
    }
    backgroundMutationError = undefined;
    return { ready: true };
}

let protectionRecoveryTail = Promise.resolve();

function recoverProtectionState() {
    const operation = protectionRecoveryTail
        .catch(( ) => undefined)
        .then(( ) => withSettingsRestoreLock(( ) =>
            queueBackgroundMutation(async ( ) => {
                const journal = await readSettingsRestoreJournal();
                let result;
                if ( journal instanceof Object ) {
                    result = await rollbackSettingsRestore(journal.id);
                } else {
                    result = await reconcileSettingsState({
                        reloadStorage: true,
                        fullDNR: true,
                    });
                }
                if ( result?.foregroundReconciliationRequired ) {
                    foregroundRulesetReconciliationRequired = true;
                    throw new Error(
                        'Foreground ruleset reconciliation is required'
                    );
                }
                backgroundMutationError = undefined;
                return result;
            })
        ));
    protectionRecoveryTail = operation.catch(( ) => undefined);
    return operation;
}

async function mutateFilteringModeAndScripts(mutation) {
    const beforeDetails = await getFilteringModeDetails(true);
    try {
        const result = await mutation();
        await Promise.all([ registerContentScripts(true), registerUserScripts() ]);
        return result;
    } catch(reason) {
        try {
            await setFilteringModeDetails(beforeDetails, true);
            await Promise.all([ registerContentScripts(true), registerUserScripts() ]);
        } catch(rollbackReason) {
            throw new Error(`${reason}; filtering-mode rollback failed: ${rollbackReason}`);
        }
        throw reason;
    }
}

/******************************************************************************/

async function setDeveloperMode(state) {
    const beforeState = rulesetConfig.developerMode;
    try {
        rulesetConfig.developerMode = state === true;
        toggleDeveloperMode(rulesetConfig.developerMode);
        await saveRulesetConfig();
        await Promise.all([
            updateUserRules(true),
            registerUserScripts(),
        ]);
        broadcastMessage({ developerMode: rulesetConfig.developerMode });
        return rulesetConfig.developerMode;
    } catch(reason) {
        rulesetConfig.developerMode = beforeState;
        toggleDeveloperMode(beforeState);
        try {
            await saveRulesetConfig();
            await Promise.all([
                updateUserRules(true),
                registerUserScripts(),
            ]);
        } catch(rollbackReason) {
            throw new AggregateError(
                [ reason, rollbackReason ],
                'Developer-mode update and rollback both failed'
            );
        }
        throw reason;
    }
}

/******************************************************************************/

const CUSTOM_FILTER_MESSAGE_SCHEMA = 1;

function documentTargetFromSender(sender) {
    const tabId = sender?.tab?.id;
    const documentId = sender?.documentId;
    if (
        Number.isInteger(tabId) === false ||
        tabId < 0 ||
        typeof documentId !== 'string' ||
        documentId.trim() === ''
    ) {
        return;
    }
    return { tabId, documentIds: [ documentId ] };
}

function physicalCSSTarget(documentTarget) {
    return { tabId: documentTarget.tabId, allFrames: true };
}

function customFilterAck(requestId, details, reason) {
    const response = {
        ok: reason === undefined,
        schema: CUSTOM_FILTER_MESSAGE_SCHEMA,
        requestId: typeof requestId === 'string' ? requestId : null,
    };
    if ( reason !== undefined ) {
        response.error = `${reason}`;
        return response;
    }
    response.plainSelectors = details.plainSelectors;
    response.proceduralSelectors = details.proceduralSelectors;
    return response;
}

function cssInsertAck(
    requestId,
    documentTarget,
    frameId,
    reason = null,
    ambiguous = false
) {
    const succeeded = reason === null;
    const response = {
        ok: succeeded,
        schema: CUSTOM_FILTER_MESSAGE_SCHEMA,
        requestId: typeof requestId === 'string' ? requestId : null,
        documentId: documentTarget?.documentIds?.[0] ?? null,
        frameId: Number.isInteger(frameId) ? frameId : null,
    };
    if ( succeeded === false ) {
        response.error = `${reason}`;
        if ( ambiguous ) { response.ambiguous = true; }
    }
    return response;
}

function validateFloorpCSSScopeRequest(request) {
    const marker = /^data-floorp-ubol-([a-f0-9]{32})$/
        .exec(request.scopeAttribute);
    if ( marker === null ) {
        throw new Error('Invalid CSS document scope marker');
    }
    const expectedCanary = `--floorp-ubol-canary-${marker[1]}`;
    if (
        request.scopeCanary !== expectedCanary ||
        /^floorp-[a-f0-9]{32}$/.test(request.scopeCanaryValue) === false ||
        request.scopeCanaryValue.slice('floorp-'.length) === marker[1]
    ) {
        throw new Error('Invalid CSS document scope canary');
    }
    const wrapper = `:where(:root[${request.scopeAttribute}])`;
    const prefix = `${wrapper} {\n` +
        `${request.scopeCanary}: ${request.scopeCanaryValue} !important;\n}\n`;
    if ( request.css.startsWith(prefix) === false ) {
        throw new Error('CSS payload does not match its document scope');
    }
    const body = request.css.slice(prefix.length);
    if ( body.trim() === '' ) {
        throw new Error('CSS payload has no document-scoped effect rules');
    }

    function skipTrivia(text, start) {
        let cursor = start;
        while ( cursor < text.length ) {
            if ( /\s/.test(text[cursor]) ) {
                cursor += 1;
                continue;
            }
            if ( text[cursor] === '/' && text[cursor + 1] === '*' ) {
                const end = text.indexOf('*/', cursor + 2);
                if ( end === -1 ) {
                    throw new Error('CSS payload has an unterminated comment');
                }
                cursor = end + 2;
                continue;
            }
            break;
        }
        return cursor;
    }

    function splitSelectors(header) {
        const selectors = [];
        let start = 0;
        let quote = '';
        let brackets = 0;
        let parentheses = 0;
        for ( let i = 0; i < header.length; i += 1 ) {
            const char = header[i];
            if ( quote !== '' ) {
                if ( char === '\\' ) { i += 1; }
                else if ( char === quote ) { quote = ''; }
                continue;
            }
            if ( char === '"' || char === "'" ) {
                quote = char;
                continue;
            }
            if ( char === '\\' ) { i += 1; continue; }
            if ( char === '[' ) { brackets += 1; continue; }
            if ( char === ']' ) { brackets -= 1; continue; }
            if ( char === '(' ) { parentheses += 1; continue; }
            if ( char === ')' ) { parentheses -= 1; continue; }
            if ( char !== ',' || brackets !== 0 || parentheses !== 0 ) {
                continue;
            }
            selectors.push(header.slice(start, i).trim());
            start = i + 1;
        }
        selectors.push(header.slice(start).trim());
        if (
            quote !== '' || brackets !== 0 || parentheses !== 0 ||
            selectors.some(selector => selector === '')
        ) {
            throw new Error('CSS payload has an invalid selector list');
        }
        return selectors;
    }

    function matchingBrace(text, opening) {
        let depth = 1;
        let quote = '';
        let comment = false;
        for ( let i = opening + 1; i < text.length; i += 1 ) {
            const char = text[i];
            const next = text[i + 1];
            if ( comment ) {
                if ( char === '*' && next === '/' ) {
                    comment = false;
                    i += 1;
                }
                continue;
            }
            if ( quote !== '' ) {
                if ( char === '\\' ) { i += 1; }
                else if ( char === quote ) { quote = ''; }
                continue;
            }
            if ( char === '/' && next === '*' ) {
                comment = true;
                i += 1;
                continue;
            }
            if ( char === '"' || char === "'" ) {
                quote = char;
                continue;
            }
            if ( char === '\\' ) { i += 1; continue; }
            if ( char === '{' ) { depth += 1; continue; }
            if ( char !== '}' ) { continue; }
            depth -= 1;
            if ( depth === 0 ) { return i; }
        }
        throw new Error('CSS payload has unbalanced rule blocks');
    }

    function validateRuleList(text) {
        let cursor = 0;
        let effectRuleCount = 0;
        while ( (cursor = skipTrivia(text, cursor)) < text.length ) {
            let quote = '';
            let comment = false;
            let brackets = 0;
            let parentheses = 0;
            let opening = -1;
            for ( let i = cursor; i < text.length; i += 1 ) {
                const char = text[i];
                const next = text[i + 1];
                if ( comment ) {
                    if ( char === '*' && next === '/' ) {
                        comment = false;
                        i += 1;
                    }
                    continue;
                }
                if ( quote !== '' ) {
                    if ( char === '\\' ) { i += 1; }
                    else if ( char === quote ) { quote = ''; }
                    continue;
                }
                if ( char === '/' && next === '*' ) {
                    comment = true;
                    i += 1;
                    continue;
                }
                if ( char === '"' || char === "'" ) {
                    quote = char;
                    continue;
                }
                if ( char === '\\' ) { i += 1; continue; }
                if ( char === '[' ) { brackets += 1; continue; }
                if ( char === ']' ) { brackets -= 1; continue; }
                if ( char === '(' ) { parentheses += 1; continue; }
                if ( char === ')' ) { parentheses -= 1; continue; }
                if ( brackets !== 0 || parentheses !== 0 ) { continue; }
                if ( char === ';' || char === '}' ) {
                    throw new Error('CSS payload escapes its scoped rule list');
                }
                if ( char === '{' ) {
                    opening = i;
                    break;
                }
            }
            if ( opening === -1 ) {
                throw new Error('CSS payload contains an incomplete rule');
            }
            const header = text.slice(cursor, opening).trim();
            const closing = matchingBrace(text, opening);
            if ( header.startsWith('@') ) {
                const name = /^@([a-z-]+)(?:\s|\(|$)/i.exec(header)
                    ?.[1]?.toLowerCase();
                if (
                    [ 'media', 'supports', 'container' ].includes(name) ===
                        false
                ) {
                    throw new Error('CSS payload contains a global at-rule');
                }
                const nestedEffectRuleCount = validateRuleList(
                    text.slice(opening + 1, closing)
                );
                if ( nestedEffectRuleCount === 0 ) {
                    throw new Error(
                        'CSS conditional has no document-scoped effect rules'
                    );
                }
                effectRuleCount += nestedEffectRuleCount;
            } else {
                const selectors = splitSelectors(header);
                if ( selectors.some(selector =>
                    (
                        selector.startsWith(`${wrapper} :is(`) === false &&
                        selector.startsWith(`${wrapper}:is(`) === false
                    ) || /:is\(\s*\)/.test(selector)
                ) ) {
                    throw new Error('CSS selector is outside its document scope');
                }
                effectRuleCount += 1;
            }
            cursor = closing + 1;
        }
        return effectRuleCount;
    }

    if ( validateRuleList(body) === 0 ) {
        throw new Error('CSS payload has no document-scoped effect rules');
    }
}

function customFilterHostname(request, sender) {
    if ( request?.schema !== CUSTOM_FILTER_MESSAGE_SCHEMA ) {
        throw new Error('Unsupported custom-filter message schema');
    }
    if (
        typeof request.requestId !== 'string' ||
        request.requestId === '' ||
        request.requestId.length > 128
    ) {
        throw new Error('Invalid custom-filter request ID');
    }
    if (
        typeof request.hostname !== 'string' ||
        request.hostname.length > 253
    ) {
        throw new Error('Invalid custom-filter hostname');
    }
    let senderHostname = '';
    try {
        const senderURL = new URL(sender?.url);
        if ( senderURL.protocol === 'http:' || senderURL.protocol === 'https:' ) {
            senderHostname = senderURL.hostname.toLowerCase();
        }
    } catch {
    }
    if ( senderHostname === '' ) {
        throw new Error('Custom-filter sender hostname mismatch');
    }

    let requestedURL;
    try {
        requestedURL = new URL(`https://${request.hostname}/`);
    } catch {
        throw new Error('Invalid custom-filter hostname');
    }
    if (
        requestedURL.username !== '' ||
        requestedURL.password !== '' ||
        requestedURL.port !== '' ||
        requestedURL.pathname !== '/' ||
        requestedURL.search !== '' ||
        requestedURL.hash !== ''
    ) {
        throw new Error('Invalid custom-filter hostname');
    }
    const hostname = requestedURL.hostname.toLowerCase();
    if ( hostname === '' || senderHostname !== hostname ) {
        throw new Error('Custom-filter sender hostname mismatch');
    }
    return hostname;
}

function authoritativeCustomFilterSnapshot(localState) {
    const settingsSnapshot = committedSettingsRestoreSnapshot(
        localState[SETTINGS_RESTORE_JOURNAL_KEY]
    );
    if ( settingsSnapshot !== undefined ) {
        // A settings transaction owns user-controlled modes and selectors,
        // but managed policy remains live authority and may change outside
        // that transaction. Explicit undefined values also remove policy that
        // existed in the last-committed user snapshot.
        return {
            ...settingsSnapshot,
            'admin.defaultFiltering': localState['admin.defaultFiltering'],
            'admin.noFiltering': localState['admin.noFiltering'],
        };
    }
    const mutationSnapshot = committedCustomFilterMutationSnapshot(
        localState[customFilterMutationJournalKey]
    );
    if ( mutationSnapshot !== undefined ) {
        return {
            ...Object.fromEntries(customFilterModeStorageKeys.map(key => [
                key,
                localState[key],
            ])),
            ...mutationSnapshot,
        };
    }
    return localState;
}

/******************************************************************************/

async function onMessage(request, sender) {

    const tabId = sender?.tab?.id ?? false;
    const frameId = tabId && (sender?.frameId ?? false);
    const documentTarget = documentTargetFromSender(sender);

    // Does not require extension to be fully initialized

    // Does not require a trusted origin.

    switch ( request.what ) {

    case 'floorpCSSDocumentIdentity': {
        const requestId = request?.requestId;
        try {
            if ( documentTarget === undefined ) {
                throw new Error('Missing sender document ID');
            }
            if ( request?.schema !== CUSTOM_FILTER_MESSAGE_SCHEMA ) {
                throw new Error('Unsupported CSS document identity schema');
            }
            if (
                typeof requestId !== 'string' ||
                requestId === '' ||
                requestId.length > 128
            ) {
                throw new Error('Invalid CSS document identity request ID');
            }
            return cssInsertAck(requestId, documentTarget, sender?.frameId);
        } catch(reason) {
            return cssInsertAck(
                requestId,
                documentTarget,
                sender?.frameId,
                reason ?? new Error('CSS document identity failed')
            );
        }
    }

    case 'insertCSS': {
        const requestId = request?.requestId;
        let inserted = false;
        let cleanupAmbiguous = false;
        let cssTarget;
        try {
            if ( documentTarget === undefined ) {
                throw new Error('Missing sender document ID');
            }
            if (
                request?.schema !== undefined &&
                request.schema !== CUSTOM_FILTER_MESSAGE_SCHEMA
            ) {
                throw new Error('Unsupported CSS insertion message schema');
            }
            if (
                requestId !== undefined &&
                (
                    typeof requestId !== 'string' ||
                    requestId === '' ||
                    requestId.length > 128
                )
            ) {
                throw new Error('Invalid CSS insertion request ID');
            }
            if ( typeof request?.css !== 'string' || request.css === '' ) {
                throw new Error('Invalid CSS insertion payload');
            }
            if (
                request.schema === undefined &&
                sender?.frameId !== 0
            ) {
                throw new Error('Legacy CSS insertion is main-frame only');
            }
            if ( request.schema === CUSTOM_FILTER_MESSAGE_SCHEMA ) {
                validateFloorpCSSScopeRequest(request);
                if (
                    request.expectedDocumentId !==
                        documentTarget.documentIds[0] ||
                    request.expectedFrameId !== sender?.frameId
                ) {
                    throw new Error('CSS insertion sender identity changed');
                }
                cssTarget = physicalCSSTarget(documentTarget);
                // removeCSS removes every exact matching dynamic sheet in
                // WebKit. Starting each candidate with this idempotent cleanup
                // makes the broker restart-safe and bounds a physical payload
                // to one copy without retaining a Service Worker receipt.
                await browser.scripting.removeCSS({
                    css: request.css,
                    origin: 'USER',
                    target: cssTarget,
                });
            } else {
                cssTarget = documentTarget;
            }
            await browser.scripting.insertCSS({
                css: request.css,
                origin: 'USER',
                // WebKit frame targeting is inconsistent for origin-fallback
                // documents. The private nesting marker makes this explicit
                // all-frame distribution active only in the sender Document.
                target: cssTarget,
            });
            inserted = true;
            if ( request.schema === CUSTOM_FILTER_MESSAGE_SCHEMA ) {
                const response = cssInsertAck(
                    requestId,
                    documentTarget,
                    sender?.frameId
                );
                response.ensured = true;
                return response;
            }
            return cssInsertAck(
                requestId,
                documentTarget,
                sender?.frameId
            );
        } catch(reason) {
            if (
                inserted
            ) {
                try {
                    await browser.scripting.removeCSS({
                        css: request.css,
                        origin: 'USER',
                        target: cssTarget,
                    });
                } catch {
                    cleanupAmbiguous = true;
                }
            }
            ubolErr(`insertCSS/${reason}`);
            return cssInsertAck(
                requestId,
                documentTarget,
                sender?.frameId,
                reason ?? new Error('Native CSS insertion failed'),
                cleanupAmbiguous
            );
        }
    }

    case 'removeCSS': {
        const requestId = request?.requestId;
        let cssTarget;
        try {
            if ( documentTarget === undefined ) {
                throw new Error('Missing sender document ID');
            }
            if (
                request?.schema !== undefined &&
                request.schema !== CUSTOM_FILTER_MESSAGE_SCHEMA
            ) {
                throw new Error('Unsupported CSS removal message schema');
            }
            if (
                requestId !== undefined &&
                (
                    typeof requestId !== 'string' ||
                    requestId === '' ||
                    requestId.length > 128
                )
            ) {
                throw new Error('Invalid CSS removal request ID');
            }
            if ( typeof request?.css !== 'string' || request.css === '' ) {
                throw new Error('Invalid CSS removal payload');
            }
            if (
                request.schema === undefined &&
                sender?.frameId !== 0
            ) {
                throw new Error('Legacy CSS removal is main-frame only');
            }
            if ( request.schema === CUSTOM_FILTER_MESSAGE_SCHEMA ) {
                validateFloorpCSSScopeRequest(request);
                if (
                    request.expectedDocumentId !==
                        documentTarget.documentIds[0] ||
                    request.expectedFrameId !== sender?.frameId
                ) {
                    throw new Error('CSS removal sender identity changed');
                }
                cssTarget = physicalCSSTarget(documentTarget);
            } else {
                cssTarget = documentTarget;
            }
            await browser.scripting.removeCSS({
                css: request.css,
                origin: 'USER',
                target: cssTarget,
            });
            return cssInsertAck(
                requestId,
                documentTarget,
                sender?.frameId
            );
        } catch(reason) {
            ubolErr(`removeCSS/${reason}`);
            return cssInsertAck(
                requestId,
                documentTarget,
                sender?.frameId,
                reason ?? new Error('Native CSS removal failed')
            );
        }
    }

    case 'injectCSSProceduralAPI': {
        if ( documentTarget === undefined ) {
            return customFilterAck(
                request.requestId,
                undefined,
                'Missing sender document ID'
            );
        }
        try {
            const results = await browser.scripting.executeScript({
                files: [
                    '/js/scripting/css-api.js',
                    '/js/scripting/css-procedural-api.js',
                ],
                target: documentTarget,
                injectImmediately: true,
            });
            assertSuccessfulScriptInjection(
                results,
                'injectCSSProceduralAPI/executeScript'
            );
            return customFilterAck(request.requestId, {
                plainSelectors: [],
                proceduralSelectors: [],
            });
        } catch(reason) {
            ubolErr(`injectCSSProceduralAPI/${reason}`);
            return customFilterAck(request.requestId, undefined, reason);
        }
    }

    // A registered document-start or document-idle script can be the event
    // that wakes Safari's nonpersistent background. Bind every injection to
    // that exact document and, while a mutation exists, read its authoritative
    // committed snapshot. Neither path depends on full startup reconciliation,
    // so keep this response ahead of that potentially long-running work.
    case 'injectCustomFilters': {
        const requestId = request?.requestId;
        try {
            if ( documentTarget === undefined ) {
                throw new Error('Missing sender document ID');
            }
            const hostname = customFilterHostname(request, sender);
            // Read both recovery journals, filtering policy, and only this
            // hostname ancestry's site.* documents in one storage operation.
            // A second live read could otherwise cross journal publication
            // and expose uncommitted selectors to this document.
            const localState = await localSnapshot([], [
                SETTINGS_RESTORE_JOURNAL_KEY,
                customFilterMutationJournalKey,
                ...customFilterModeStorageKeys,
                ...customFilterStorageKeys(hostname),
            ]);
            const storageSnapshot = authoritativeCustomFilterSnapshot(localState);
            if (
                customFilteringEnabledFromStorageSnapshot(
                    storageSnapshot,
                    hostname
                ) === false
            ) {
                return customFilterAck(requestId, {
                    plainSelectors: [],
                    proceduralSelectors: [],
                });
            }
            const details = await injectCustomFilters(
                documentTarget,
                hostname,
                storageSnapshot
            );
            return customFilterAck(requestId, details);
        } catch(reason) {
            ubolErr(`injectCustomFilters/${reason}`);
            return customFilterAck(requestId, undefined, reason);
        }
    }

    default:
        break;
    }

    if ( request.what === 'floorpAuthorizeForegroundReconciliation' ) {
        const trustedSender = isTrustedFloorpExtensionPageSender(sender);
        if ( trustedSender === false ) { return false; }
        // Authorization begins a durable foreground handoff. Keep native
        // readiness fail-closed until the same or a replacement extension
        // page finalizes and the background revalidates every surface.
        foregroundRulesetReconciliationRequired = true;
        return { authorized: true };
    }

    if ( request.what === 'floorpFinalizeForegroundReconciliation' ) {
        const trustedSender = isTrustedFloorpExtensionPageSender(sender);
        if ( trustedSender === false ) { return false; }
        try {
            // The foreground page owns a separate JS realm, so its successful
            // static-ruleset mutation cannot update this background realm's
            // in-memory seen-realm cache. The foreground wrapper already
            // removed the session marker before the mutation; mirror that
            // invalidation here before allowing navigation readiness again.
            resetSafariRealmReadiness();
            const journal = await readSettingsRestoreJournal();
            let result;
            if ( journal?.phase === 'rollingBack' ) {
                result = await rollbackSettingsRestore(journal.id);
            } else if ( journal?.phase === 'committingForeground' ) {
                result = await commitSettingsRestore(journal.id);
            } else {
                result = await reconcileSettingsState({
                    reloadStorage: true,
                    fullDNR: true,
                    allowStaticMutation: false,
                });
            }
            if ( result?.foregroundReconciliationRequired ) {
                return {
                    ready: false,
                    version: getCurrentVersion(),
                    foregroundReconciliationRequired: true,
                    error: 'Foreground ruleset reconciliation did not converge',
                };
            }
            foregroundRulesetReconciliationRequired = false;
            backgroundMutationError = undefined;
            releaseRealmRulesetStartupGate();
            return {
                ready: true,
                version: getCurrentVersion(),
                foregroundReconciliationRequired: false,
                committed: result?.committed === true,
                rolledBack: result?.rolledBack === true,
            };
        } catch(reason) {
            foregroundRulesetReconciliationRequired = true;
            return {
                ready: false,
                version: getCurrentVersion(),
                foregroundReconciliationRequired: true,
                error: `${reason}`,
            };
        }
    }

    if ( request.what === 'floorpReadiness' ) {
        const trustedSender = isTrustedFloorpExtensionPageSender(sender);
        if ( trustedSender === false ) { return false; }
        const readinessErrors = [];
        let initializationError;
        try {
            await ensureFullyInitialized();
        } catch(reason) {
            // A protected queue error is recovered again below. Do not retain
            // a transient first error after that same readiness call has
            // successfully converged every protected surface.
            initializationError = reason;
        }
        if ( foregroundRulesetReconciliationRequired ) {
            return foregroundReconciliationReadiness();
        }
        let activeRestoreJournal;
        try {
            activeRestoreJournal = await readSettingsRestoreJournal();
        } catch(reason) {
            readinessErrors.push(reason);
        }
        if (
            activeRestoreJournal instanceof Object &&
            activeSettingsRestoreId === activeRestoreJournal.id
        ) {
            return {
                ready: false,
                version: getCurrentVersion(),
                restoreInProgress: true,
                error: 'Settings restore is in progress',
            };
        }
        try {
            await waitForRealmRulesetUpdates();
        } catch(reason) {
            readinessErrors.push(reason);
        }
        try {
            await waitForBackgroundMutations();
        } catch(reason) {
            try {
                if ( initializationError === undefined ) {
                    await recoverProtectionState();
                } else {
                    // Route startup recovery through the memoizing helper so
                    // the successful retry is reused by the handler itself
                    // and by every later message in this worker lifetime.
                    await ensureFullyInitialized();
                }
                initializationError = undefined;
            } catch(recoveryReason) {
                readinessErrors.push(reason, recoveryReason);
            }
        }
        if ( initializationError !== undefined ) {
            try {
                await ensureFullyInitialized();
                initializationError = undefined;
            } catch(reason) {
                readinessErrors.push(reason);
            }
        }
        if ( foregroundRulesetReconciliationRequired ) {
            return foregroundReconciliationReadiness();
        }
        let restoreJournal;
        try {
            restoreJournal = await readSettingsRestoreJournal();
        } catch(reason) {
            readinessErrors.push(reason);
        }
        if ( restoreJournal instanceof Object ) {
            readinessErrors.push(new Error('Settings restore recovery is pending'));
        }
        if ( readinessErrors.length !== 0 ) {
            ubolErr(readinessErrors[0]);
            return {
                ready: false,
                version: getCurrentVersion(),
                error: `${readinessErrors[0]}`,
            };
        }
        return { ready: true, version: getCurrentVersion() };
    }

    // Requires extension to be fully initialized

    await ensureFullyInitialized();

    // Does not require a trusted origin.

    switch ( request.what ) {

    case 'toggleToolbarIcon': {
        if ( tabId ) {
            toggleToolbarIcon(tabId);
        }
        return;
    }

    case 'startCustomFilters':
        if ( frameId === false ) { return; }
        return startCustomFilters(tabId, frameId, sender?.documentId);

    case 'terminateCustomFilters':
        if ( frameId === false ) { return; }
        return terminateCustomFilters(tabId, frameId, sender?.documentId);

    default:
        break;
    }

    // Requires a trusted origin.

    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/runtime/MessageSender
    //   Firefox API does not set `sender.origin`
    const isTrustedOrigin = sender?.origin === undefined ||
        sender.origin.toLowerCase() === UBOL_ORIGIN;
    if ( isTrustedOrigin === false ) { return; }

    switch ( request.what ) {

    case 'validateSettingsRestore':
        return validateSettingsRestore(request.targetConfig);

    case 'beginSettingsRestore':
        return beginSettingsRestoreNow();

    case 'commitSettingsRestore':
        return commitSettingsRestore(request.id, request.enabledRulesets);

    case 'rollbackSettingsRestore':
        return rollbackSettingsRestore(request.id);

    case 'floorpReconcileDashboardState':
        return reconcileDashboardState();

    case 'applyRulesets': {
        await applyRulesets(request.enabledRulesets);
        if ( request.toRemove ) {
            await removeImportedLists(request.toRemove);
        }
        return;
    }

    case 'removeDisabledImportedLists': {
        const enabled = new Set(await getEnabledRulesets());
        const toRemove = (request.rulesetIds || []).filter(
            id => enabled.has(id) === false
        );
        if ( toRemove.length !== 0 ) {
            await removeImportedLists(toRemove);
        }
        return { ready: true };
    }

    case 'getDefaultConfig': {
        const rulesets = await getDefaultRulesetsFromEnv();
        return {
            autoReload: defaultConfig.autoReload,
            developerMode: defaultConfig.developerMode,
            showBlockedCount: defaultConfig.showBlockedCount,
            strictBlockMode: defaultConfig.strictBlockMode,
            popupBlockMode: defaultConfig.popupBlockMode,
            rulesets,
            filteringModes: Object.assign(defaultFilteringModes),
        };
    }

    case 'getCurrentConfig':
        return rulesetConfig;

    case 'getOptionsPageData': {
        const [
            hasOmnipotence,
            defaultFilteringMode,
            rulesetDetails,
            enabledRulesets,
            adminRulesets,
            disabledFeatures,
        ] = await Promise.all([
            hasBroadHostPermissions(),
            getDefaultFilteringMode(),
            getRulesetDetails(),
            getEnabledRulesets(),
            getAdminRulesets(),
            adminReadEx('disabledFeatures'),
        ]);
        process.firstRun = false;
        return {
            hasOmnipotence,
            defaultFilteringMode,
            enabledRulesets,
            adminRulesets,
            maxNumberOfEnabledRulesets: dnr.MAX_NUMBER_OF_ENABLED_STATIC_RULESETS,
            rulesetDetails: Array.from(rulesetDetails.values()),
            autoReload: rulesetConfig.autoReload,
            showBlockedCount: rulesetConfig.showBlockedCount,
            canShowBlockedCount,
            strictBlockMode: rulesetConfig.strictBlockMode,
            popupBlockMode: rulesetConfig.popupBlockMode,
            firstRun: process.firstRun,
            isSideloaded,
            developerMode: rulesetConfig.developerMode,
            disabledFeatures,
            supportsCompiledFilters: supportsOffscreenDocument,
            supportsUserScripts: supportsUserScripts(),
        };
    }

    case 'getEnabledRulesets':
        return getEnabledRulesets();

    case 'getRulesetDetails': {
        const rulesetDetails = await getRulesetDetails();
        return Array.from(rulesetDetails.values());
    }

    case 'getEnabledRulesetsDetails':
        return getEnabledRulesetsDetails();

    case 'getRulesetRules':
        return getRulesetRules(request.id);

    case 'hasBroadHostPermissions':
        return hasBroadHostPermissions();

    case 'setAutoReload': {
        const beforeState = rulesetConfig.autoReload;
        try {
            rulesetConfig.autoReload = request.state === true;
            await saveRulesetConfig();
        } catch(reason) {
            rulesetConfig.autoReload = beforeState;
            await saveRulesetConfig().catch(( ) => undefined);
            throw reason;
        }
        broadcastMessage({ autoReload: rulesetConfig.autoReload });
        return;
    }

    case 'setShowBlockedCount': {
        const beforeState = rulesetConfig.showBlockedCount;
        try {
            rulesetConfig.showBlockedCount = request.state === true;
            if ( canShowBlockedCount ) {
                await dnr.setExtensionActionOptions({
                    displayActionCountAsBadgeText: rulesetConfig.showBlockedCount,
                });
            }
            await saveRulesetConfig();
        } catch(reason) {
            rulesetConfig.showBlockedCount = beforeState;
            if ( canShowBlockedCount ) {
                await dnr.setExtensionActionOptions({
                    displayActionCountAsBadgeText: beforeState,
                }).catch(( ) => undefined);
            }
            await saveRulesetConfig().catch(( ) => undefined);
            throw reason;
        }
        broadcastMessage({ showBlockedCount: rulesetConfig.showBlockedCount });
        return;
    }

    case 'setStrictBlockMode': {
        const beforeState = rulesetConfig.strictBlockMode;
        try {
            const result = await setStrictBlockMode(request.state, true);
            if ( result?.error ) { throw new Error(result.error); }
        } catch(reason) {
            try {
                const rollback = await setStrictBlockMode(beforeState, true);
                if ( rollback?.error ) { throw new Error(rollback.error); }
            } catch(rollbackReason) {
                throw new Error(`${reason}; strict-block rollback failed: ${rollbackReason}`);
            }
            throw reason;
        }
        broadcastMessage({ strictBlockMode: rulesetConfig.strictBlockMode });
        return;
    }

    case 'setPopupBlockMode': {
        const beforeState = rulesetConfig.popupBlockMode;
        try {
            await setPopupBlockMode(request.state, true);
            await registerContentScripts(true);
        } catch(reason) {
            try {
                await setPopupBlockMode(beforeState, true);
                await registerContentScripts(true);
            } catch(rollbackReason) {
                throw new Error(`${reason}; popup-mode rollback failed: ${rollbackReason}`);
            }
            throw reason;
        }
        broadcastMessage({ popupBlockMode: rulesetConfig.popupBlockMode });
        return;
    }

    case 'setDeveloperMode':
        return setDeveloperMode(request.state);

    case 'popupPanelData': {
        const results = await Promise.all([
            hasBroadHostPermissions(),
            getFilteringMode(request.hostname),
            adminReadEx('disabledFeatures'),
            hasCustomFilters(request.hostname),
        ]);
        return {
            hasOmnipotence: results[0],
            level: results[1],
            autoReload: rulesetConfig.autoReload,
            isSideloaded,
            developerMode: rulesetConfig.developerMode,
            disabledFeatures: results[2],
            hasCustomFilters: results[3],
        };
    }

    case 'getFilteringMode': {
        return getFilteringMode(request.hostname);
    }

    case 'gotoURL': {
        const windowId = Number.isInteger(request.windowId)
            ? request.windowId
            : sender?.tab?.windowId;
        const incognito = typeof request.incognito === 'boolean'
            ? request.incognito
            : sender?.tab?.incognito;
        try {
            const result = await gotoURL(request.url, request.type, windowId, incognito);
            return { opened: true, ...result };
        } catch(reason) {
            const error = `${reason}`;
            ubolErr(`gotoURL/${error}`);
            return { opened: false, error };
        }
    }

    case 'setFilteringMode': {
        const beforeLevel = await getFilteringMode(request.hostname);
        if ( request.level === beforeLevel ) { return beforeLevel; }
        const afterLevel = await mutateFilteringModeAndScripts(( ) =>
            setFilteringMode(request.hostname, request.level, true)
        );
        return afterLevel;
    }

    case 'setPendingFilteringMode':
        pendingPermissionRequest = request;
        return;

    case 'getDefaultFilteringMode': {
        return getDefaultFilteringMode();
    }

    case 'setDefaultFilteringMode': {
        const beforeLevel = await getDefaultFilteringMode();
        if ( request.level === beforeLevel ) { return beforeLevel; }
        const afterLevel = await mutateFilteringModeAndScripts(( ) =>
            setDefaultFilteringMode(request.level, true)
        );
        return afterLevel;
    }

    case 'getFilteringModeDetails':
        return getFilteringModeDetails(true);

    case 'setFilteringModeDetails': {
        await mutateFilteringModeAndScripts(( ) =>
            setFilteringModeDetails(request.modes, true)
        );
        const defaultFilteringMode = await getDefaultFilteringMode();
        broadcastMessage({ defaultFilteringMode });
        return getFilteringModeDetails(true);
    }

    case 'excludeFromStrictBlock':
        return excludeFromStrictBlock(request.hostname, request.permanent);

    case 'getMatchedRules':
        return getMatchedRules(request.tabId);

    case 'showMatchedRules':
        try {
            await browser.tabs.create({
                active: true,
                url: `/matched-rules.html?tab=${request.tabId}`,
                ...(Number.isInteger(request.windowId) ? { windowId: request.windowId } : {}),
            });
            return { opened: true };
        } catch(reason) {
            const error = `${reason}`;
            ubolErr(`tabs.create/${error}`);
            return { opened: false, error };
        }

    case 'getAllDynamicRules':
        return dnr.getDynamicRules();

    case 'getAllSessionRules':
        return dnr.getSessionRules();

    case 'getEffectiveUserRules':
        return getEffectiveUserRules();

    case 'updateUserDnrRules':
        return updateUserRules(true);

    case 'replaceUserDnrRules': {
        if ( typeof request.text !== 'string' ) {
            throw new Error('Invalid user-rule text');
        }
        const before = await localRead('userDnrRules');
        try {
            if ( request.text !== '' ) {
                await localWrite('userDnrRules', request.text);
            } else {
                await localRemove('userDnrRules');
            }
            return await updateUserRules(true);
        } catch(reason) {
            if ( typeof before === 'string' && before !== '' ) {
                await localWrite('userDnrRules', before);
            } else {
                await localRemove('userDnrRules');
            }
            throw reason;
        }
    }

    case 'replaceSettingsRestoreImportedLists': {
        if (
            Array.isArray(request.toAdd) === false ||
            Array.isArray(request.toRemove) === false
        ) {
            throw new Error('Invalid imported-list restore mutation');
        }
        if ( request.toRemove.length !== 0 ) {
            await removeImportedLists(request.toRemove);
        }
        if ( request.toAdd.length !== 0 ) {
            await addImportedLists(request.toAdd);
        }
        return { updated: true };
    }

    case 'getAllCustomFilters':
        return getAllCustomFilters();

    case 'replaceCustomFilters': {
        const { before, after } = request;
        if (
            before instanceof Object === false ||
            after instanceof Object === false ||
            typeof before.hostname !== 'string' ||
            typeof after.hostname !== 'string' ||
            Array.isArray(before.selectors) === false ||
            Array.isArray(after.selectors) === false
        ) {
            throw new Error('Invalid custom-filter replacement');
        }
        return replaceCustomFiltersAtomically(
            before,
            after,
            reconcileCustomFilterState
        );
    }

    case 'replaceAllCustomFilters': {
        if ( Array.isArray(request.entries) === false ) {
            throw new Error('Invalid custom-filter replacement');
        }
        return replaceAllCustomFiltersAtomically(
            request.entries,
            reconcileCustomFilterState
        );
    }

    case 'addCustomFilters': {
        return mutateCustomFiltersAtomically(
            ( ) => addCustomFilters(request.hostname, request.selectors),
            reconcileCustomFilterState
        );
    }

    case 'addManyCustomFilters': {
        return mutateCustomFiltersAtomically(async ( ) => {
            const results = [];
            for ( const [ hostname, selectors ] of request.entries ) {
                if ( typeof hostname !== 'string' || hostname === '' ) { continue; }
                if ( Array.isArray(selectors) === false || selectors.length === 0 ) {
                    continue;
                }
                results.push(await addCustomFilters(hostname, selectors));
            }
            return results.some(Boolean);
        }, reconcileCustomFilterState);
    }

    case 'removeCustomFilters': {
        return mutateCustomFiltersAtomically(
            ( ) => removeCustomFilters(request.hostname, request.selectors),
            reconcileCustomFilterState
        );
    }

    case 'removeAllCustomFilters': {
        return mutateCustomFiltersAtomically(
            ( ) => removeAllCustomFilters(request.hostname),
            reconcileCustomFilterState
        );
    }

    case 'getSandboxFilters':
        return getSandboxFilters();

    case 'setSandboxFilters': {
        const before = await getSandboxFilters();
        try {
            await setSandboxFilters(request.text);
            await updateCompiledFilters();
            await Promise.all([ registerUserScripts(), updateUserRules(true) ]);
            return;
        } catch(reason) {
            try {
                await setSandboxFilters(before);
                await updateCompiledFilters();
                await Promise.all([ registerUserScripts(), updateUserRules(true) ]);
            } catch(rollbackReason) {
                throw new AggregateError(
                    [ reason, rollbackReason ],
                    'Sandbox-filter update and rollback both failed'
                );
            }
            throw reason;
        }
    }

    case 'customFiltersFromHostname':
        return customFiltersFromHostname(request.hostname);

    case 'getRegisteredContentScripts':
        return getRegisteredContentScripts();

    case 'getConsoleOutput':
        return getConsoleOutput();

    case 'importFilterList': {
        const modified = await addImportedLists([ request.url ]);
        if ( modified !== true ) { break; }
        const rulesets = await getEnabledRulesets();
        rulesets.push(request.url);
        await applyRulesets(rulesets);
        return;
    }

    case 'getImportedLists': {
        return getImportedLists();
    }

    case 'updateImportedLists': {
        const count = await updateImportedLists();
        if ( count === 0 ) { break; }
        await updateCompiledFilters();
        await Promise.all([ registerUserScripts(), updateUserRules(true) ]);
        return;
    }

    case 'pruneCSSCache': {
        return pruneCSSCache();
    }

    // This is used to ensure we are not suspended while busy fetching filter
    // lists from remote servers.
    case 'keepAlive':
        return;

    default:
        break;
    }
}

/******************************************************************************/

function onCommand(command, tab) {
    switch ( command ) {
    case 'enter-zapper-mode': {
        if ( browser.scripting === undefined ) { return; }
        browser.scripting.executeScript({
            files: [ '/js/scripting/tool-overlay.js', '/js/scripting/zapper.js' ],
            target: { tabId: tab.id },
        });
        break;
    }
    case 'enter-picker-mode': {
        if ( browser.scripting === undefined ) { return; }
        browser.scripting.executeScript({
            files: [
                '/js/scripting/css-api.js',
                '/js/scripting/css-procedural-api.js',
                '/js/scripting/tool-overlay.js',
                '/js/scripting/picker.js',
            ],
            target: { tabId: tab.id },
        });
        break;
    }
    default:
        break;
    }
}

/******************************************************************************/

async function startSession(allowStaticMutation = true) {
    const currentVersion = getCurrentVersion();
    const isNewVersion = currentVersion !== rulesetConfig.version;

    // Admin settings override user settings
    await loadAdminConfig();

    // The default rulesets may have changed, find out new ruleset to enable,
    // obsolete ruleset to remove.
    if ( isNewVersion ) {
        ubolLog(`Version change: ${rulesetConfig.version} => ${currentVersion}`);
        rulesetConfig.version = currentVersion;
        await patchDefaultRulesets();
        await saveRulesetConfig();
    }

    const {
        stockUpdated,
        importedUpdated,
        enabledRulesets,
        error: enableRulesetsError,
        foregroundReconciliationRequired,
    } = await enableRulesets(
        rulesetConfig.enabledRulesets,
        true,
        allowStaticMutation
    );
    if ( foregroundReconciliationRequired ) {
        return { foregroundReconciliationRequired: true };
    }
    if ( enableRulesetsError ) { throw new Error(enableRulesetsError); }
    if ( stockUpdated || importedUpdated ) {
        rulesetConfig.enabledRulesets = enabledRulesets;
        await saveRulesetConfig();
    }

    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/declarativeNetRequest#rulesets
    // "The set of enabled static rulesets is persisted across sessions but not across extension updates"
    // "[Dynamic] rules persist across sessions and extension updates"
    // "[Session] rules do not persist across browser sessions"
    // enableRulesets() already rebuilds dynamic/session rules after a static
    // ruleset change. Avoid repeating the expensive WebKit compilation on
    // first launch, where a single long-lived readiness reply can otherwise
    // outlive the MV3 background page.
    if ( stockUpdated !== true && isNewVersion ) {
        const result = await updateDynamicAndSessionRules();
        if ( result?.error ) { throw new Error(result.error); }
    } else if ( stockUpdated !== true ) {
        const result = await updateSessionRules();
        if ( result?.error ) { throw new Error(result.error); }
    }

    // Permissions may have been removed while the extension was disabled
    const permissionsUpdated = await syncWithBrowserPermissions(true);

    // Toggling "user scripts" permission doesn't cause a permissions change
    // event.
    const userScriptsChanged = supportsUserScripts() !== rulesetConfig.userScripts;
    if ( userScriptsChanged ) {
        rulesetConfig.userScripts = !rulesetConfig.userScripts;
        await saveRulesetConfig();
    }

    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/scripting/RegisteredContentScript#persistacrosssessions
    // "When an extension updates, content scripts are cleared"
    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/userScripts#extension_updates
    // "User scripts are cleared when an extension updates"
    const promises = [];
    const shouldInject = isNewVersion || permissionsUpdated ||
        isSideloaded && rulesetConfig.developerMode;
    if ( shouldInject || stockUpdated ) {
        promises.push(registerContentScripts(true));
    }
    if ( importedUpdated ) {
        promises.push(
            updateCompiledFilters().then(( ) =>
                Promise.all([ registerUserScripts(), updateUserRules(true) ])
            )
        );
    } else if ( shouldInject ) {
        promises.push(registerUserScripts(), updateUserRules(true));
    } else if ( userScriptsChanged ) {
        promises.push(registerUserScripts());
    }
    if ( promises.length ) {
        await Promise.all(promises);
    }

    // Cosmetic filtering-related content scripts cache fitlering data in
    // session storage.
    await sessionAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });

    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/declarativeNetRequest
    //   Firefox API does not support `dnr.setExtensionActionOptions`
    if ( canShowBlockedCount ) {
        await dnr.setExtensionActionOptions({
            displayActionCountAsBadgeText: rulesetConfig.showBlockedCount,
        });
    }

    // Switch to basic filtering if uBOL doesn't have broad permissions at
    // install time.
    if ( process.firstRun ) {
        const enableOptimal = await hasBroadHostPermissions();
        if ( enableOptimal === false ) {
            const afterLevel = await setDefaultFilteringMode(MODE_BASIC, true);
            if ( afterLevel === MODE_BASIC ) {
                await registerContentScripts(true);
                process.firstRun = false;
            }
        }
    }

    // Required to ensure up to date properties are available when needed
    const disabledFeatures = await adminReadEx('disabledFeatures', true);
    if ( Array.isArray(disabledFeatures) ) {
        if ( disabledFeatures.includes('develop') ) {
            if ( rulesetConfig.developerMode ) {
                await setDeveloperMode(false);
            }
        }
    }

    return { ready: true };
}

/******************************************************************************/

async function recoverInterruptedSettingsRestoreAtStart() {
    // Avoid joining the cross-realm lock when no restore exists. Ordinary
    // foreground reconciliation may hold the same lock while relying on this
    // background's early finalizer, but it has no transaction to roll back.
    const pendingJournal = await readSettingsRestoreJournal();
    if ( pendingJournal instanceof Object === false ) { return; }
    // Acquire the cross-realm lease before entering the mutation queue. If a
    // foreground DNR transition survived a background eviction, its early
    // authorize/finalize messages can terminally publish while startup waits.
    return withSettingsRestoreLock(( ) =>
        queueBackgroundMutation(async ( ) => {
            const journal = await readSettingsRestoreJournal();
            if ( journal instanceof Object === false ) { return; }
            const result = await rollbackSettingsRestore(journal.id);
            if ( result?.foregroundReconciliationRequired ) {
                foregroundRulesetReconciliationRequired = true;
            }
            return result;
        })
    );
}

async function start() {
    if ( supportsUserScripts() && runtime.onUserScriptMessage ) {
        await browser.userScripts.configureWorld({ messaging: true });
    }
    const rollbackResult = await recoverInterruptedSettingsRestoreAtStart();
    if ( rollbackResult?.foregroundReconciliationRequired ) {
        return;
    }
    return withSettingsRestoreLock(( ) =>
        queueBackgroundMutation(async ( ) => {
            await recoverCustomFilterMutation();
            await loadRulesetConfig();

            if ( process.wakeupRun === false ) {
                const sessionResult = await startSession(
                    webextFlavor !== 'safari'
                );
                if ( sessionResult?.foregroundReconciliationRequired ) {
                    foregroundRulesetReconciliationRequired = true;
                    return;
                }
            }

            // A background process may be evicted at any await boundary of an
            // earlier mutation. Reconcile every protected surface from
            // durable local state on every wake before readiness can be true.
            const reconcileResult = await reconcileSettingsState({
                reloadStorage: true,
                fullDNR: true,
            });
            if ( reconcileResult?.foregroundReconciliationRequired ) { return; }

            toggleDeveloperMode(rulesetConfig.developerMode);
        })
    );
}

/******************************************************************************/

// https://github.com/uBlockOrigin/uBOL-home/issues/199
// Force a restart of the extension once when an "internal error" occurs

const floorpInitialization = start().then(async ( ) => {
    await localRemove('goodStart');
});
floorpInitialization.then(
    ( ) => {
        if ( foregroundRulesetReconciliationRequired === false ) {
            releaseRealmRulesetStartupGate();
        }
    },
    releaseRealmRulesetStartupGate
);

const isFullyInitialized = floorpInitialization.then(( ) => false);
void isFullyInitialized.catch(( ) => undefined);

let initializationRecovery;

async function ensureFullyInitialized() {
    try {
        return await isFullyInitialized;
    } catch(reason) {
        ubolErr(reason);
        if ( initializationRecovery === undefined ) {
            initializationRecovery = recoverProtectionState();
            void initializationRecovery.catch(( ) => undefined);
        }
        const recovery = initializationRecovery;
        try {
            await recovery;
        } catch(reason) {
            if ( initializationRecovery === recovery ) {
                initializationRecovery = undefined;
            }
            throw reason;
        }
        return false;
    }
}

setAdminSettingsMutationRunner(async operation => {
    await ensureFullyInitialized();
    return withSettingsRestoreLock(( ) =>
        queueBackgroundMutation(async ( ) => {
            const journal = await readSettingsRestoreJournal();
            if (
                journal instanceof Object ||
                foregroundRulesetReconciliationRequired
            ) {
                return false;
            }
            const result = await operation();
            if ( result?.foregroundReconciliationRequired ) {
                foregroundRulesetReconciliationRequired = true;
                return false;
            }
            return true;
        })
    );
});

const backgroundMutationMessages = new Set([
    'applyRulesets',
    'beginSettingsRestore',
    'commitSettingsRestore',
    'rollbackSettingsRestore',
    'floorpAuthorizeForegroundReconciliation',
    'floorpReconcileDashboardState',
    'floorpFinalizeForegroundReconciliation',
    'removeDisabledImportedLists',
    'setAutoReload',
    'setShowBlockedCount',
    'setStrictBlockMode',
    'setPopupBlockMode',
    'setDeveloperMode',
    'setFilteringMode',
    'setPendingFilteringMode',
    'setDefaultFilteringMode',
    'setFilteringModeDetails',
    'excludeFromStrictBlock',
    'updateUserDnrRules',
    'replaceUserDnrRules',
    'replaceSettingsRestoreImportedLists',
    'replaceCustomFilters',
    'replaceAllCustomFilters',
    'addCustomFilters',
    'addManyCustomFilters',
    'removeCustomFilters',
    'removeAllCustomFilters',
    'setSandboxFilters',
    'importFilterList',
    'updateImportedLists',
    'pruneCSSCache',
]);

const settingsRestoreOwnedMutationMessages = new Set([
    'setAutoReload',
    'setShowBlockedCount',
    'setDeveloperMode',
    'setStrictBlockMode',
    'setPopupBlockMode',
    'setFilteringModeDetails',
    'replaceAllCustomFilters',
    'setSandboxFilters',
    'replaceUserDnrRules',
    'replaceSettingsRestoreImportedLists',
    'floorpAuthorizeForegroundReconciliation',
    'floorpFinalizeForegroundReconciliation',
]);

async function assertSettingsRestoreMutationOwner(request) {
    if ( request.what === 'beginSettingsRestore' ) { return; }
    const journal = await readSettingsRestoreJournal();
    const isTerminalRequest = request.what === 'commitSettingsRestore' ||
        request.what === 'rollbackSettingsRestore';
    const ownerId = isTerminalRequest
        ? request.id
        : request.settingsRestoreId;
    if ( journal instanceof Object === false ) {
        if ( ownerId !== undefined ) {
            throw new SettingsRestoreConflictError(
                'Settings restore transaction has expired'
            );
        }
        return;
    }
    if (
        isTerminalRequest &&
        (
            request.settingsRestoreId !== request.id ||
            request.id !== journal.id
        )
    ) {
        throw new SettingsRestoreConflictError(
            'Settings restore journal does not match'
        );
    }
    const liveOwner = activeSettingsRestoreId === journal.id;
    const ownedRequest = ownerId === journal.id;
    const isOwnedMutation = settingsRestoreOwnedMutationMessages.has(
        request.what
    ) || isTerminalRequest;
    const isForegroundMessage =
        request.what === 'floorpAuthorizeForegroundReconciliation' ||
        request.what === 'floorpFinalizeForegroundReconciliation';
    if (
        journal.phase === 'applying' &&
        liveOwner &&
        ownedRequest &&
        isOwnedMutation &&
        isForegroundMessage === false
    ) {
        return;
    }
    if ( journal.phase === 'committingForeground' && ownedRequest ) {
        if (
            isForegroundMessage ||
            liveOwner && isTerminalRequest
        ) {
            return;
        }
    }
    if ( journal.phase === 'rollingBack' ) {
        if (
            ownedRequest &&
            (
                request.what === 'rollbackSettingsRestore' ||
                isForegroundMessage
            )
        ) {
            return;
        }
        const isInterruptedForegroundRecovery =
            activeSettingsRestoreId === undefined &&
            ownerId === undefined &&
            (
                isForegroundMessage
            );
        if ( isInterruptedForegroundRecovery ) { return; }
    }
    throw new SettingsRestoreConflictError('Settings restore is in progress');
}

function dispatchMessage(request, sender) {
    if ( request.what === 'beginSettingsRestore' ) {
        // Initialization may itself wait for the cross-realm lease while it
        // recovers an interrupted transaction. Do not acquire the lease or
        // occupy the mutation queue until that startup work has settled.
        return ensureFullyInitialized().then(( ) =>
            withSettingsRestoreLock(( ) =>
                queueBackgroundMutation(async ( ) => {
                    await assertSettingsRestoreMutationOwner(request);
                    return onMessage(request, sender);
                })
            )
        );
    }
    if ( backgroundMutationMessages.has(request.what) ) {
        const enqueue = ( ) => queueBackgroundMutation(async ( ) => {
            await assertSettingsRestoreMutationOwner(request);
            return onMessage(request, sender);
        });
        if (
            request.what === 'floorpAuthorizeForegroundReconciliation' ||
            request.what === 'floorpFinalizeForegroundReconciliation'
        ) {
            return enqueue();
        }
        // Startup recovery owns Web Lock -> mutation queue. All ordinary
        // mutations must settle initialization before entering that queue or
        // they can invert the order and block the foreground finalizer.
        return ensureFullyInitialized().then(( ) =>
            withSettingsRestoreLock(enqueue)
        );
    }
    return onMessage(request, sender);
}

runtime.onMessage.addListener((request, sender, callback) => {
    if ( request.what.includes(':') ) { return; }
    dispatchMessage(request, sender).then(callback, reason => {
        const error = `${reason}`;
        ubolErr(`onMessage/${request.what}/${error}`);
        callback({ error });
    });
    return true;
});

if ( supportsUserScripts() && runtime.onUserScriptMessage ) {
    runtime.onUserScriptMessage.addListener((request, sender, callback) => {
        dispatchMessage(request, sender).then(callback, reason => {
            const error = `${reason}`;
            ubolErr(`onUserScriptMessage/${request.what}/${error}`);
            callback({ error });
        });
        return true;
    });
}

browser.permissions.onRemoved.addListener((...args) => {
    onPermissionsChanged('removed', ...args).catch(reason => {
        ubolErr(`permissions.onRemoved/${reason}`);
    });
});

browser.permissions.onAdded.addListener((...args) => {
    onPermissionsChanged('added', ...args).catch(reason => {
        ubolErr(`permissions.onAdded/${reason}`);
    });
});

browser.commands.onCommand.addListener((...args) => {
    ensureFullyInitialized().then(( ) =>
        withSettingsRestoreLock(( ) =>
            queueBackgroundMutation(async ( ) => {
                const journal = await localRead(
                    SETTINGS_RESTORE_JOURNAL_KEY
                );
                if ( journal instanceof Object ) { return; }
                return onCommand(...args);
            })
        )
    ).catch(reason => ubolErr(`commands.onCommand/${reason}`));
});

browser.alarms.onAlarm.addListener(alarm => {
    if ( alarm.name !== 'deferredJobs' ) { return; }
    ensureFullyInitialized().then(( ) =>
        withSettingsRestoreLock(( ) =>
            queueBackgroundMutation(async ( ) => {
                if (
                    process.wakeupRun === false &&
                    process.firstAlarm !== true
                ) {
                    process.firstAlarm = true;
                    return resetJobsAlarm();
                }
                const journal = await localRead(
                    SETTINGS_RESTORE_JOURNAL_KEY
                );
                if ( journal instanceof Object ) { return resetJobsAlarm(); }
                return processDueJobs(onMessage);
            })
        )
    ).catch(reason => ubolErr(`alarms.onAlarm/${reason}`));
});
