/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import { ubolErr } from './debug.js';

/******************************************************************************/

export async function fetchJSON(path) {
    try {
        const response = await fetch(`${path}.json`);
        if ( response.ok !== true ) {
            throw new Error(`HTTP ${response.status} for ${path}.json`);
        }
        const result = await response.json();
        if ( result === undefined || result === null ) {
            throw new Error(`Missing JSON data for ${path}.json`);
        }
        return result;
    } catch(reason) {
        ubolErr(`fetchJSON/${reason}`);
        throw reason;
    }
}
