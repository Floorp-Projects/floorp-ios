/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2026-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import {
    browser,
    localRead,
    localRemove,
    localWrite,
    runtime,
    supportsUserScripts,
} from './ext.js';

import {
    closeOffscreenDocument,
    createOffscreenDocument,
} from './ext-offscreen.js';

import {
    getAllCustomFilters,
    getSandboxFilters,
} from './filter-manager.js';

import {
    getEnabledImportedLists,
    getImportedListCompiledData,
    updateImportedListData,
} from './imported-lists.js';

import {
    isScriptlet,
    matchesFromHostnames,
} from './utils.js';

import { dnr } from './ext-compat.js';
import { getFilteringModeDetails } from './mode-manager.js';
import { supportsOffscreenDocument } from './ext-offscreen.js';
import { ubolLog } from './debug.js';

/******************************************************************************/

async function getUserList() {
    const customFilters = await getAllCustomFilters();
    const lines = [];
    for ( const [ hostname, selectors ] of customFilters ) {
        for ( const selector of selectors ) {
            if ( isScriptlet(selector) === false ) { continue; }
            lines.push(`${hostname}##${selector}`);
        }
    }
    const sandboxFilters = await getSandboxFilters();
    if ( sandboxFilters ) {
        lines.push(sandboxFilters);
    }
    return lines.join('\n').trim();
}

/******************************************************************************/

async function parseRawFilters() {
    const {
        promise: offscreenPromise,
        resolve: offscreenResolve,
        reject: offscreenReject,
    } = Promise.withResolvers();
    const handler = (request, sender, callback) => {
        if ( typeof request !== 'object' ) { return; }
        switch ( request?.what ) {
        case 'compileFilters:getResourceTypes':
            callback(Object.values(dnr.ResourceType));
            break;
        case 'compileFilters:getUserList':
            getUserList().then(text => {
                if ( text ) { ubolLog(`Compiling user filters`); }
                callback(text);
            }, offscreenReject);
            return true;
        case 'compileFilters:result':
            if ( request instanceof Object === false ) {
                offscreenReject(new Error('Invalid compiled-filter result'));
            } else {
                offscreenResolve(request);
            }
            break;
        case 'compileFilters:getEnabledImportedLists':
            getEnabledImportedLists().then(result => {
                if ( result?.length ) { ubolLog(`Compiling ${result.length} imported lists`); }
                callback(result);
            }, offscreenReject);
            return true;
        case 'compileFilters:getImportedListCompiledData':
            getImportedListCompiledData(request.listid).then(result => {
                if ( result?.serialized ) { ubolLog(`Reusing cached data for ${result.listid}`); }
                callback(result);
            }, offscreenReject);
            return true;
        case 'compileFilters:updateImportedListData':
            updateImportedListData(request.listid, request).then(result => {
                if ( result ) { ubolLog(`Updated cached data for ${result.listid}`); }
                callback(result);
            }, offscreenReject);
            return true;
        default:
            break;
        }
    };
    runtime.onMessage.addListener(handler);
    let timeoutId;
    const timeoutPromise = new Promise((resolve, reject) => {
        timeoutId = self.setTimeout(
            ( ) => reject(new Error('Compiling filters timed out')),
            60000
        );
    });
    try {
        await createOffscreenDocument('/js/offscreen/compile-filters.html');
        return await Promise.race([ offscreenPromise, timeoutPromise ]);
    } finally {
        self.clearTimeout(timeoutId);
        runtime.onMessage.removeListener(handler);
        await closeOffscreenDocument().catch(( ) => undefined);
    }
}

/******************************************************************************/

function prepareUserScripts(id, none, result) {
    const out = [];
    const excludeHostnames = none.has('all-urls') === false
        ? [ ...none ]
        : [];
    const excludeMatches = excludeHostnames.length !== 0
        ? matchesFromHostnames(excludeHostnames)
        : [];
    if ( result?.ISOLATED?.length ) {
        for ( const script of result.ISOLATED ) {
            const directive = {
                id: script.id,
                world: 'USER_SCRIPT',
                allFrames: true,
                js: [ { code: script.code } ],
                runAt: 'document_start',
                matches: matchesFromHostnames(script.hostnames),
            };
            if ( excludeMatches.length !== 0 ) {
                directive.excludeMatches = excludeMatches.slice();
            }
            out.push(directive);
        }
    }
    if ( result?.MAIN?.length ) {
        for ( const script of result.MAIN ) {
            const directive = {
                id: script.id,
                world: 'MAIN',
                allFrames: true,
                js: [ { code: script.code } ],
                runAt: 'document_start',
                matches: matchesFromHostnames(script.hostnames),
            };
            if ( excludeMatches.length !== 0 ) {
                directive.excludeMatches = excludeMatches.slice();
            }
            out.push(directive);
        }
    }
    return out;
}

/******************************************************************************/

async function saveRules(id, rules) {
    const storageId = `${id}Filters.dnrRules`;
    const beforeRules = await localRead(storageId);
    const afterRules = rules?.length && rules;
    const modified = JSON.stringify(afterRules) !== JSON.stringify(beforeRules);
    if ( modified === false ) { return false; }
    if ( Array.isArray(afterRules) ) {
        await localWrite(storageId, afterRules);
    } else {
        await localRemove(storageId);
    }
    return true;
}

/******************************************************************************/

async function saveUserScripts(result = {}) {
    return Promise.all([
        localWrite('sandboxFilters.userScripts', {
            ISOLATED: result.sandbox?.ISOLATED ?? [],
            MAIN: result.sandbox?.MAIN ?? [],
        }),
        localWrite('importedFilters.userScripts', {
            ISOLATED: result.imported?.ISOLATED ?? [],
            MAIN: result.imported?.MAIN ?? [],
        }),
    ]);
}

async function readUserScripts() {
    const [
        sandbox = {},
        imported = {},
    ] = await Promise.all([
        localRead('sandboxFilters.userScripts'),
        localRead('importedFilters.userScripts'),
    ]);
    return { sandbox, imported };
}

/******************************************************************************/

export async function reconcileUserScripts(userScripts, toAdd) {
    const normalize = scripts => scripts.map(script => ({
        id: script.id,
        world: script.world,
        allFrames: script.allFrames === true,
        js: script.js || [],
        runAt: script.runAt,
        matches: (script.matches || []).slice().sort(),
        excludeMatches: (script.excludeMatches || []).slice().sort(),
    })).sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
    const before = await userScripts.getScripts();
    if ( JSON.stringify(normalize(before)) === JSON.stringify(normalize(toAdd)) ) {
        return;
    }
    try {
        if ( before.length !== 0 ) {
            await userScripts.unregister();
            ubolLog(`Unregistered userscript ${before.map(a => a.id).join()}`);
        }
        if ( toAdd.length !== 0 ) {
            await userScripts.register(toAdd);
            ubolLog(`Registered userscript ${toAdd.map(v => v.id)}`);
        }
        const confirmed = await userScripts.getScripts();
        if ( JSON.stringify(normalize(confirmed)) !== JSON.stringify(normalize(toAdd)) ) {
            throw new Error('Registered user scripts did not match requested scripts');
        }
    } catch(reason) {
        const rollbackErrors = [];
        try {
            const current = await userScripts.getScripts();
            if ( current.length !== 0 ) {
                await userScripts.unregister();
            }
            if ( before.length !== 0 ) {
                await userScripts.register(before);
            }
            const restored = await userScripts.getScripts();
            if ( JSON.stringify(normalize(restored)) !== JSON.stringify(normalize(before)) ) {
                throw new Error('User-script rollback readback mismatch');
            }
        } catch(rollbackReason) {
            rollbackErrors.push(rollbackReason);
        }
        if ( rollbackErrors.length !== 0 ) {
            throw new AggregateError(
                [ reason, ...rollbackErrors ],
                'User-script update and rollback both failed'
            );
        }
        throw reason;
    }
}

async function register() {
    const [
        { none, basic },
        { sandbox, imported },
    ] = await Promise.all([
        getFilteringModeDetails(),
        readUserScripts(),
    ]);

    const toAdd = [];
    const sandboxScripts = await prepareUserScripts('sandbox',
        none,
        sandbox
    );
    if ( sandboxScripts.length ) {
        toAdd.push(...sandboxScripts);
    }
    const importedScripts = await prepareUserScripts('imported',
        new Set([ ...none, ...basic ]),
        imported
    );
    if ( importedScripts.length ) {
        toAdd.push(...importedScripts);
    }
    if ( supportsUserScripts() === false ) { return; }
    return reconcileUserScripts(browser.userScripts, toAdd);
}

/******************************************************************************/

async function update() {
    const [
        hasUserFilters,
        hasImportedLists,
    ] = await Promise.all([
        getUserList().then(a => Boolean(a)),
        getEnabledImportedLists().then(a => Boolean(a.length)),
    ]);

    let result;
    if ( hasUserFilters || hasImportedLists ) {
        result = await parseRawFilters();
        if ( result instanceof Object === false ) {
            throw new Error('Invalid compiled-filter result');
        }
    }

    await Promise.all([
        saveRules('sandbox', result?.sandbox?.dnrRules),
        saveRules('imported', result?.imported?.dnrRules),
        saveUserScripts(result),
    ]);
}

/******************************************************************************/

// This recompiles all sandbox and imported filters.

export async function updateCompiledFilters() {
    if ( supportsOffscreenDocument !== true ) { return false; }
    return queueCompiledFilterOperation(update);
}

/******************************************************************************/

// This registers previously compiled external filters, according to current
// filtering mode details.

export async function registerUserScripts() {
    // Registration itself does not require an offscreen compiler. Persisted
    // compiled scripts must still be reconciled on Safari wakes so an
    // eviction between unregister/register cannot leave protection absent.
    if ( supportsUserScripts() === false ) { return false; }
    return queueCompiledFilterOperation(register);
}

/******************************************************************************/

let pendingRegister = Promise.resolve();

function queueCompiledFilterOperation(operation) {
    const current = pendingRegister
        .catch(( ) => undefined)
        .then(operation);
    pendingRegister = current.catch(( ) => undefined);
    return current;
}
