/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import * as ut from './utils.js';

import {
    browser,
    localKeys, localRemove, localSnapshot, localWrite,
    sessionKeys, sessionRead, sessionRemove,
    webextFlavor,
} from './ext.js';
import { ubolErr, ubolLog } from './debug.js';

import { fetchJSON } from './fetch.js';
import { getEnabledRulesetsDetails } from './ruleset-manager.js';
import { getFilteringModeDetails } from './mode-manager.js';
import { registerCustomFilters } from './filter-manager.js';
import { registerJob } from './alarms.js';
import { registerPreventPopup } from './prevent-popup.js';
import { registerToolbarIconToggler } from './action.js';

/******************************************************************************/

const resourceDetailPromises = new Map();
const safariRegistrationSentinelId = 'floorp-safari-registration-sentinel';

const comparableRegistration = details => JSON.stringify({
    id: details.id,
    matches: details.matches || [],
    excludeMatches: details.excludeMatches || [],
    includeGlobs: details.includeGlobs || [],
    excludeGlobs: details.excludeGlobs || [],
    js: details.js || [],
    css: details.css || [],
    allFrames: details.allFrames === true,
    matchOriginAsFallback: details.matchOriginAsFallback === true,
    persistAcrossSessions: details.persistAcrossSessions !== false,
    runAt: details.runAt || 'document_idle',
    world: typeof details.world === 'string'
        ? details.world.toUpperCase()
        : 'ISOLATED',
});

function registrationMismatch(before, desired) {
    if ( before.length !== desired.length ) { return true; }
    const beforeById = new Map(before.map(details => [ details.id, details ]));
    return desired.some(details =>
        comparableRegistration(beforeById.get(details.id) || {}) !==
            comparableRegistration(details)
    );
}

// Safari scripting operations are not atomic: an API call can apply a prefix
// and still reject. Re-read and converge from the actual persistent state so a
// later attempt (including the next nonpersistent background wake) repairs it.
export async function reconcileSafariContentScripts(scripting, desired) {
    const sentinel = desired.find(
        details => details.id === safariRegistrationSentinelId
    );
    if ( sentinel === undefined ) {
        throw new Error('Missing Safari registration sentinel definition');
    }
    let lastError;
    for ( let attempt = 1; attempt <= 3; attempt++ ) {
        try {
            let before = await scripting.getRegisteredContentScripts();
            let currentSentinel = before.find(
                details => details.id === safariRegistrationSentinelId
            );
            if ( currentSentinel === undefined ) {
                await scripting.registerContentScripts([ sentinel ]);
                before = await scripting.getRegisteredContentScripts();
                currentSentinel = before.find(
                    details => details.id === safariRegistrationSentinelId
                );
            }
            if ( comparableRegistration(currentSentinel || {}) !==
                 comparableRegistration(sentinel) ) {
                throw new Error('Safari registration sentinel verification failed');
            }

            const beforeById = new Map(
                before.map(details => [ details.id, details ])
            );
            const desiredIds = new Set(desired.map(details => details.id));
            const toRegister = desired.filter(details =>
                details.id !== safariRegistrationSentinelId &&
                beforeById.has(details.id) === false
            );
            const toUpdate = desired.filter(details =>
                details.id !== safariRegistrationSentinelId &&
                beforeById.has(details.id) &&
                comparableRegistration(beforeById.get(details.id)) !==
                    comparableRegistration(details)
            );
            const removeIds = before
                .map(details => details.id)
                .filter(id => id !== safariRegistrationSentinelId &&
                    desiredIds.has(id) === false);

            if ( toRegister.length !== 0 ) {
                ubolLog(`Registered ${toRegister.map(v => v.id)} content (css/js)`);
                await scripting.registerContentScripts(toRegister);
            }
            if ( toUpdate.length !== 0 ) {
                ubolLog(`Updated ${toUpdate.map(v => v.id)} content (css/js)`);
                await scripting.updateContentScripts(toUpdate);
            }
            if ( removeIds.length !== 0 ) {
                ubolLog(`Unregistered ${removeIds} content (css/js)`);
                await scripting.unregisterContentScripts({ ids: removeIds });
            }

            const after = await scripting.getRegisteredContentScripts();
            if ( registrationMismatch(after, desired) ) {
                throw new Error('Safari content-script reconciliation did not converge');
            }
            return;
        } catch(reason) {
            lastError = reason;
            ubolErr(`reconcileSafariContentScripts/${attempt}/${reason}`);
            if ( attempt < 3 ) {
                await new Promise(resolve => {
                    setTimeout(resolve, 50 * attempt);
                });
            }
        }
    }
    throw lastError;
}

function getScriptletDetails() {
    let promise = resourceDetailPromises.get('scriptlet');
    if ( promise !== undefined ) { return promise; }
    promise = fetchJSON('/rulesets/scriptlet-details').then(entries => {
        if ( Array.isArray(entries) === false ) {
            throw new Error('Invalid scriptlet details resource');
        }
        return new Map(entries);
    });
    resourceDetailPromises.set('scriptlet', promise);
    promise.catch(( ) => {
        if ( resourceDetailPromises.get('scriptlet') === promise ) {
            resourceDetailPromises.delete('scriptlet');
        }
    });
    return promise;
}

function getGenericDetails() {
    let promise = resourceDetailPromises.get('generic');
    if ( promise !== undefined ) { return promise; }
    promise = fetchJSON('/rulesets/generic-details').then(entries => {
        if ( Array.isArray(entries) === false ) {
            throw new Error('Invalid generic details resource');
        }
        return new Map(entries);
    });
    resourceDetailPromises.set('generic', promise);
    promise.catch(( ) => {
        if ( resourceDetailPromises.get('generic') === promise ) {
            resourceDetailPromises.delete('generic');
        }
    });
    return promise;
}

/******************************************************************************/

const normalizeMatches = matches => {
    if ( matches.length <= 1 ) { return; }
    if ( matches.includes('<all_urls>') === false ) {
        if ( matches.includes('*://*/*') === false ) { return; }
    }
    matches.length = 0;
    matches.push('<all_urls>');
};

/******************************************************************************/

async function resetCSSCache() {
    const keys = await sessionKeys();
    return sessionRemove(keys.filter(a => a.startsWith('cache.css.')));
}

/******************************************************************************/

function registerGeneric(context, genericDetails) {
    const { filteringModeDetails, rulesetsDetails } = context;

    const excludedByFilter = [];
    const includedByFilter = [];
    const js = [];
    for ( const details of rulesetsDetails ) {
        const hostnames = genericDetails.get(details.id);
        if ( hostnames ) {
            if ( hostnames.unhide ) {
                excludedByFilter.push(...hostnames.unhide);
            }
            if ( hostnames.hide ) {
                includedByFilter.push(...hostnames.hide);
            }
        }
        const count = details.css?.generic || 0;
        if ( count === 0 ) { continue; }
        js.push(`/rulesets/scripting/generic/${details.id}.js`);
    }

    if ( js.length === 0 ) { return; }

    js.unshift('/js/scripting/css-api.js', '/js/scripting/isolated-api.js');
    js.push('/js/scripting/css-generic.js');

    const { none, basic, optimal, complete } = filteringModeDetails;
    const includedByMode = [ ...complete ];
    const excludedByMode = [ ...none, ...basic, ...optimal ];

    if ( complete.has('all-urls') === false ) {
        const matches = [
            ...ut.matchesFromHostnames(
                ut.subtractHostnameIters(includedByMode, excludedByFilter)
            ),
            ...ut.matchesFromHostnames(
                ut.intersectHostnameIters(includedByMode, includedByFilter)
            ),
        ];
        if ( matches.length === 0 ) { return; }
        const directive = {
            id: 'css-generic-some',
            js,
            allFrames: true,
            matches,
            runAt: 'document_idle',
        };
        context.toAdd.push(directive);
        return;
    }

    const excludeMatches = [
        ...ut.matchesFromHostnames(excludedByMode),
        ...ut.matchesFromHostnames(excludedByFilter),
    ];
    const directiveAll = {
        id: 'css-generic-all',
        js,
        allFrames: true,
        matches: [ '<all_urls>' ],
        runAt: 'document_idle',
    };
    if ( excludeMatches.length !== 0 ) {
        directiveAll.excludeMatches = excludeMatches;
    }
    context.toAdd.push(directiveAll);

    const matches = [
        ...ut.matchesFromHostnames(
            ut.subtractHostnameIters(includedByFilter, excludedByMode)
        ),
    ];
    if ( matches.length === 0 ) { return; }
    const directiveSome = {
        id: 'css-generic-some',
        js,
        allFrames: true,
        matches,
        runAt: 'document_idle',
    };
    context.toAdd.push(directiveSome);
}

/******************************************************************************/

async function registerCosmetic(context) {
    const { filteringModeDetails, rulesetsDetails } = context;

    {
        const keys = await localKeys();
        await localRemove(keys.filter(a => a.startsWith('css.specific.')));
        // TODO: remove after a few versions after 2026.516.1652
        await localRemove(keys.filter(a => a.startsWith('css.procedural.')));
    }

    const rulesetIds = [];
    for ( const rulesetDetails of rulesetsDetails ) {
        const count = rulesetDetails.css?.specific ?? 0;
        if ( count === 0 ) { continue; }
        rulesetIds.push(rulesetDetails.id);
    }
    if ( rulesetIds.length === 0 ) { return; }

    const { none, basic, optimal, complete } = filteringModeDetails;
    const matches = [
        ...ut.matchesFromHostnames(optimal),
        ...ut.matchesFromHostnames(complete),
    ];
    if ( matches.length === 0 ) { return; }

    {
        const promises = [];
        for ( const id of rulesetIds ) {
            promises.push(
                fetchJSON(`/rulesets/scripting/specific/${id}`).then(data => {
                    return localWrite(`css.specific.${id}`, data);
                })
            );
        }
        await Promise.all(promises);
    }

    normalizeMatches(matches);

    const js = rulesetIds.map(id => `/rulesets/scripting/specific/${id}.js`);
    js.unshift('/js/scripting/css-api.js', '/js/scripting/isolated-api.js');
    if ( webextFlavor === 'safari' ) {
        js.push('/js/scripting/css-procedural-api.js');
    }
    js.push('/js/scripting/css-specific.js');

    const excludeMatches = [];
    if ( none.has('all-urls') === false && basic.has('all-urls') === false ) {
        const toExclude = [
            ...ut.matchesFromHostnames(none),
            ...ut.matchesFromHostnames(basic),
        ];
        for ( const hn of toExclude ) {
            excludeMatches.push(hn);
        }
    }

    const directive = {
        id: 'css-specific',
        js,
        matches,
        allFrames: true,
        runAt: 'document_start',
    };
    if ( excludeMatches.length !== 0 ) {
        directive.excludeMatches = excludeMatches;
    }

    // register
    context.toAdd.push(directive);
}

/******************************************************************************/

function registerScriptlet(context, scriptletDetails) {
    const { filteringModeDetails, rulesetsDetails } = context;

    const hasBroadHostPermission =
        filteringModeDetails.optimal.has('all-urls') ||
        filteringModeDetails.complete.has('all-urls');

    const permissionRevokedMatches = [
        ...ut.matchesFromHostnames(filteringModeDetails.none),
        ...ut.matchesFromHostnames(filteringModeDetails.basic),
    ];
    const permissionGrantedHostnames = [
        ...filteringModeDetails.optimal,
        ...filteringModeDetails.complete,
    ];

    for ( const rulesetId of rulesetsDetails.map(v => v.id) ) {
        const worlds = scriptletDetails.get(rulesetId);
        if ( worlds === undefined ) { continue; }
        for ( const world of Object.keys(worlds) ) {
            const id = `${rulesetId}.${world.toLowerCase()}`;

            const matches = [];
            const excludeMatches = [];
            const hostnames = worlds[world];
            let targetHostnames = [];
            if ( hasBroadHostPermission ) {
                excludeMatches.push(...permissionRevokedMatches);
                targetHostnames = hostnames;
            } else if ( permissionGrantedHostnames.length !== 0 ) {
                if ( hostnames.includes('*') ) {
                    targetHostnames = permissionGrantedHostnames;
                } else {
                    targetHostnames = ut.intersectHostnameIters(
                        hostnames,
                        permissionGrantedHostnames
                    );
                }
            }
            if ( targetHostnames.length === 0 ) { continue; }
            matches.push(...ut.matchesFromHostnames(targetHostnames));
            normalizeMatches(matches);

            const directive = {
                id,
                js: [ `/rulesets/scripting/scriptlet/${world.toLowerCase()}/${rulesetId}.js` ],
                matches,
                allFrames: true,
                matchOriginAsFallback: true,
                runAt: 'document_start',
                world,
            };
            if ( excludeMatches.length !== 0 ) {
                directive.excludeMatches = excludeMatches;
            }

            // register
            context.toAdd.push(directive);
        }
    }
}

/******************************************************************************/

// Issue: Safari appears to completely ignore excludeMatches
// https://github.com/radiolondra/ExcludeMatches-Test

export async function registerContentScripts(throwOnError = false) {
    if ( browser.scripting === undefined ) {
        if ( throwOnError ) { throw new Error('scripting API unavailable'); }
        return false;
    }
    const operation = registerContentScripts.pendingOp.then(( ) =>
        registerContentScripts.register(throwOnError)
    );
    registerContentScripts.pendingOp = operation.catch(( ) => undefined);
    return operation;
}
registerContentScripts.pendingOp = Promise.resolve();

registerContentScripts.register = async function register(throwOnError = false) {
    const [
        filteringModeDetails,
        rulesetsDetails,
        scriptletDetails,
        genericDetails,
        localStorageSnapshot,
    ] = await Promise.all([
        getFilteringModeDetails(),
        getEnabledRulesetsDetails(true),
        getScriptletDetails(),
        getGenericDetails(),
        localSnapshot(),
    ]);
    // WebExtension APIs do not guarantee enabled-ruleset enumeration order.
    // Keep generated script arrays stable across cold starts and updates.
    rulesetsDetails.sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
    const toAdd = [];
    const context = {
        filteringModeDetails,
        rulesetsDetails,
        localStorageSnapshot,
        toAdd,
    };

    await Promise.all([
        registerScriptlet(context, scriptletDetails),
        registerCosmetic(context),
        registerGeneric(context, genericDetails),
        registerCustomFilters(context),
        registerPreventPopup(context),
        registerToolbarIconToggler(context),
    ]);

    if ( webextFlavor === 'safari' ) {
        // WebKit's updateContentScripts implementation deletes the database
        // before re-adding rows when every current script changes. Keep one
        // inert persistent row so a settings update never unlinks the live DB.
        toAdd.push({
            id: safariRegistrationSentinelId,
            matches: [ 'https://floorp.invalid/*' ],
            js: [ '/js/safari-registration-sentinel.js' ],
            persistAcrossSessions: true,
            runAt: 'document_start',
        });
    }

    try {
        if ( webextFlavor === 'safari' &&
             typeof browser.scripting.updateContentScripts === 'function' ) {
            // WebKit removes RegisteredContentScripts.db when the no-argument
            // unregister form clears every registration. Its background and
            // content processes can still hold SQLite handles at cold start.
            // Reconcile by ID so unchanged launches do not write the database,
            // while settings changes remain atomic at the individual-script level.
            await reconcileSafariContentScripts(browser.scripting, toAdd);
        } else {
            ubolLog(`Unregistered all content (css/js)`);
            await browser.scripting.unregisterContentScripts();
            if ( toAdd.length !== 0 ) {
                ubolLog(`Registered ${toAdd.map(v => v.id)} content (css/js)`);
                await browser.scripting.registerContentScripts(toAdd);
            }
        }
    } catch(reason) {
        ubolErr(`registerContentScripts/${reason}`);
        if ( webextFlavor === 'safari' || throwOnError ) { throw reason; }
    }

    await Promise.all([
        resetCSSCache(),
        registerJob('pruneCSSCache', Date.now() + 15 * 60 * 1000),
    ]);

    return true;
};

/******************************************************************************/

export async function getRegisteredContentScripts() {
    const scripts = await browser.scripting.getRegisteredContentScripts();
    return scripts.map(a => a.id);
}

/******************************************************************************/

export async function pruneCSSCache() {
    registerJob('pruneCSSCache', Date.now() + 15 * 60 * 1000);
    const MAX_CACHE_ENTRY_LOW = 256;
    const MAX_CACHE_ENTRY_HIGH = MAX_CACHE_ENTRY_LOW +
        Math.max(Math.round(MAX_CACHE_ENTRY_LOW / 8), 8);
    const keys = await sessionKeys() || [];
    const cacheKeys = keys.filter(a => a.startsWith('cache.css.'));
    if ( cacheKeys.length < MAX_CACHE_ENTRY_HIGH ) { return; }
    const entries = await Promise.all(cacheKeys.map(async a => {
        const entry = await sessionRead(a) || {};
        entry.key = a;
        return entry;
    }));
    entries.sort((a, b) => b.t - a.t);
    sessionRemove(entries.slice(MAX_CACHE_ENTRY_LOW).map(a => a.key));
}

/******************************************************************************/
