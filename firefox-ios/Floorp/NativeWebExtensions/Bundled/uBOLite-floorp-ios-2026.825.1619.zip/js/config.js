/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import {
    localRead, localWrite,
    sessionRead, sessionRemove, sessionWrite,
    webextFlavor,
} from './ext.js';

/******************************************************************************/

export const rulesetConfig = {
    version: '',
    enabledRulesets: [],
    autoReload: true,
    showBlockedCount: true,
    strictBlockMode: webextFlavor !== 'safari',
    popupBlockMode: true,
    developerMode: false,
    hasBroadHostPermissions: true,
};

export const defaultConfig = Object.assign({}, rulesetConfig);

export const process = {
    firstRun: false,
    wakeupRun: false,
};

let pendingOpPromise = Promise.resolve();
let durableRevision = 0;

const CONFIG_ENVELOPE_VERSION = 1;

function decodeStoredConfig(value) {
    if (
        value instanceof Object &&
        value.floorpFormat === CONFIG_ENVELOPE_VERSION &&
        Number.isSafeInteger(value.revision) &&
        value.config instanceof Object
    ) {
        return {
            config: value.config,
            revision: value.revision,
        };
    }
    return {
        config: value instanceof Object ? value : undefined,
        revision: 0,
    };
}

function encodeStoredConfig(config, revision) {
    return {
        floorpFormat: CONFIG_ENVELOPE_VERSION,
        revision,
        config,
    };
}

function normalizeStoredValue(value) {
    if ( Array.isArray(value) ) {
        return value.map(normalizeStoredValue);
    }
    if ( value instanceof Object ) {
        const out = {};
        for ( const key of Object.keys(value).sort() ) {
            out[key] = normalizeStoredValue(value[key]);
        }
        return out;
    }
    return value;
}

function storedValuesEqual(a, b) {
    return JSON.stringify(normalizeStoredValue(a)) ===
        JSON.stringify(normalizeStoredValue(b));
}

function assignRulesetConfig(config) {
    for ( const key of Object.keys(rulesetConfig) ) {
        delete rulesetConfig[key];
    }
    Object.assign(rulesetConfig, structuredClone(defaultConfig), config);
}

function queueConfigOperation(operation) {
    const current = pendingOpPromise
        .catch(( ) => undefined)
        .then(operation);
    pendingOpPromise = current.catch(( ) => undefined);
    return current;
}

/******************************************************************************/

async function _loadRulesetConfig() {
    const [ localValue, sessionValue ] = await Promise.all([
        localRead('rulesetConfig'),
        sessionRead('rulesetConfig'),
    ]);
    const localData = decodeStoredConfig(localValue);
    const sessionData = decodeStoredConfig(sessionValue);
    process.wakeupRun = sessionData.config !== undefined;

    if ( localData.config === undefined ) {
        assignRulesetConfig(defaultConfig);
        durableRevision = 0;
        await _saveRulesetConfig();
        process.firstRun = true;
        return;
    }

    // Local storage is the durable source of truth. Session storage is only a
    // cache and must never win after a process dies between a durable write
    // and the corresponding DNR/content-script update.
    assignRulesetConfig(localData.config);
    durableRevision = localData.revision;
    const expectedSession = encodeStoredConfig(
        structuredClone(rulesetConfig),
        durableRevision
    );
    if ( storedValuesEqual(sessionValue, expectedSession) === false ) {
        await sessionWrite('rulesetConfig', expectedSession);
    }
}

async function _saveRulesetConfig() {
    const revision = durableRevision + 1;
    const envelope = encodeStoredConfig(
        structuredClone(rulesetConfig),
        revision
    );
    // Commit the durable copy and verify it before publishing the same
    // revision to the disposable session cache.
    await localWrite('rulesetConfig', envelope);
    const confirmed = await localRead('rulesetConfig');
    if ( storedValuesEqual(confirmed, envelope) === false ) {
        throw new Error('Durable ruleset configuration readback mismatch');
    }
    durableRevision = revision;
    try {
        await sessionWrite('rulesetConfig', envelope);
    } catch(reason) {
        // A stale target in session storage is more dangerous than a cache
        // miss. A later wake always reloads the verified local revision.
        await sessionRemove('rulesetConfig').catch(( ) => undefined);
        throw reason;
    }
}

/******************************************************************************/

export function loadRulesetConfig() {
    return queueConfigOperation(_loadRulesetConfig);
}

export function saveRulesetConfig() {
    return queueConfigOperation(_saveRulesetConfig);
}
