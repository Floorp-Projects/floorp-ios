/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import {
    getImportedLists,
} from './imported-lists.js';

import { localRead, runtime, sendMessage } from './ext.js';
import { reconcileProtection } from './floorp-reconcile.js';

/******************************************************************************/

export async function backupToObject(currentConfig) {
    const out = {};
    const manifest = runtime.getManifest();
    out.version = manifest.versionName ?? manifest.version;
    const [
        defaultConfig,
        sandboxFilters,
    ] = await Promise.all([
        sendMessage({ what: 'getDefaultConfig' }),
        sendMessage({ what: 'getSandboxFilters' }).then(a => a?.trim() ?? ''),
    ]);
    if ( currentConfig.autoReload !== defaultConfig.autoReload ) {
        out.autoReload = currentConfig.autoReload;
    }
    if ( currentConfig.developerMode !== defaultConfig.developerMode ) {
        out.developerMode = currentConfig.developerMode;
    }
    if ( currentConfig.popupBlockMode !== defaultConfig.popupBlockMode ) {
        out.popupBlockMode = currentConfig.popupBlockMode;
    }
    if ( currentConfig.showBlockedCount !== defaultConfig.showBlockedCount ) {
        out.showBlockedCount = currentConfig.showBlockedCount;
    }
    if ( currentConfig.strictBlockMode !== defaultConfig.strictBlockMode ) {
        out.strictBlockMode = currentConfig.strictBlockMode;
    }
    const { enabledRulesets } = currentConfig;
    const customRulesets = [];
    for ( const id of enabledRulesets ) {
        if ( defaultConfig.rulesets.includes(id) ) { continue; }
        customRulesets.push(`+${id}`);
    }
    for ( const id of defaultConfig.rulesets ) {
        if ( enabledRulesets.includes(id) ) { continue; }
        customRulesets.push(`-${id}`);
    }
    if ( customRulesets.length !== 0 ) {
        out.rulesets = customRulesets;
    }
    out.filteringModes = await sendMessage({ what: 'getFilteringModeDetails' });
    const customFilters = await sendMessage({ what: 'getAllCustomFilters' });
    if ( customFilters.length !== 0 ) {
        out.customFilters = customFilters;
    }
    if ( sandboxFilters !== '' ) {
        out.sandboxFilters = sandboxFilters.split('\n');
    }
    const dnrRules = await localRead('userDnrRules');
    if ( typeof dnrRules === 'string' && dnrRules.length !== 0 ) {
        out.dnrRules = dnrRules.split(/\n+/);
    }
    return out;
}

/******************************************************************************/

async function applyFromObject(targetConfig, settingsRestoreId) {
    const defaultConfig = await sendMessage({ what: 'getDefaultConfig' });

    await sendMessage({
        what: 'setAutoReload',
        settingsRestoreId,
        state: targetConfig.autoReload ?? defaultConfig.autoReload
    });

    await sendMessage({
        what: 'setShowBlockedCount',
        settingsRestoreId,
        state: targetConfig.showBlockedCount ?? defaultConfig.showBlockedCount
    });

    await sendMessage({
        what: 'setDeveloperMode',
        settingsRestoreId,
        state: targetConfig.developerMode ?? defaultConfig.developerMode
    });

    await sendMessage({
        what: 'setStrictBlockMode',
        settingsRestoreId,
        state: targetConfig.strictBlockMode ?? defaultConfig.strictBlockMode
    });

    await sendMessage({
        what: 'setPopupBlockMode',
        settingsRestoreId,
        state: targetConfig.popupBlockMode ?? defaultConfig.popupBlockMode
    });

    const enabledRulesets = defaultConfig.rulesets;
    for ( const entry of targetConfig.rulesets || [] ) {
        const id = entry.slice(1);
        if ( entry.startsWith('+') ) {
            if ( enabledRulesets.includes(id) ) { continue; }
            enabledRulesets.push(id);
        } else if ( entry.startsWith('-') ) {
            const i = enabledRulesets.indexOf(id);
            if ( i === -1 ) { continue; }
            enabledRulesets.splice(i, 1);
        }
    }
    const importedLists = await getImportedLists();
    const importedListIds = importedLists.map(a => a.id);
    const reImport = /^[a-z-]+:\/\//;
    const importedListsToAdd = enabledRulesets.filter(a =>
        reImport.test(a) && importedListIds.includes(a) === false
    );
    const importedListsToRemove = importedListIds.filter(a =>
        enabledRulesets.includes(a) === false
    );
    await sendMessage({
        what: 'replaceSettingsRestoreImportedLists',
        settingsRestoreId,
        toAdd: importedListsToAdd,
        toRemove: importedListsToRemove,
    });
    await sendMessage({
        what: 'setFilteringModeDetails',
        settingsRestoreId,
        modes: targetConfig.filteringModes ?? defaultConfig.filteringModes,
    });

    const customFilterMap = new Map();
    const cosmeticFilters = targetConfig.cosmeticFilters;
    if ( Array.isArray(cosmeticFilters) ) {
        for ( const line of cosmeticFilters ) {
            const i = line.indexOf('##');
            if ( i === -1 ) { continue; }
            const hostname = line.slice(0, i);
            if ( hostname === '' ) { continue; }
            const selector = line.slice(i+2);
            if ( selector === '' ) { continue; }
            const selectors = customFilterMap.get(hostname) || [];
            if ( selectors.length === 0 ) {
                customFilterMap.set(hostname, selectors)
            }
            selectors.push(selector);
        }
    }
    const customFilters = targetConfig.customFilters;
    if ( Array.isArray(customFilters) ) {
        for ( const [ hostname, incomingSelectors ] of customFilters ) {
            const selectors = customFilterMap.get(hostname) || [];
            if ( selectors.length === 0 ) {
                customFilterMap.set(hostname, selectors);
            }
            for ( const selector of incomingSelectors ) {
                if ( selectors.includes(selector) ) { continue; }
                selectors.push(selector);
            }
        }
    }
    await sendMessage({
        what: 'replaceAllCustomFilters',
        settingsRestoreId,
        entries: Array.from(customFilterMap),
    });

    await sendMessage({
        what: 'setSandboxFilters',
        settingsRestoreId,
        text: targetConfig.sandboxFilters?.join('\n') ?? '',
    });

    await sendMessage({
        what: 'replaceUserDnrRules',
        settingsRestoreId,
        text: (targetConfig.dnrRules ?? []).join('\n'),
    });

    // Static rulesets are committed only after every background-owned setting
    // above succeeds. The commit message publishes this intent durably before
    // the foreground realm mutates WebKit DNR.
    return Array.from(enabledRulesets);
}

/******************************************************************************/

export async function restoreFromObject(targetConfig) {
    // Validate without opening a journal or mutating storage/DNR. The message
    // remains tracked by ext.sendMessage so a rejected import is surfaced by
    // the first options-page close handshake.
    await sendMessage({
        what: 'validateSettingsRestore',
        targetConfig,
    });
    let transaction = await sendMessage({ what: 'beginSettingsRestore' });
    if ( transaction?.foregroundReconciliationRequired === true ) {
        const reconciliation = await reconcileProtection({
            settingsRestoreId: transaction.settingsRestoreId,
        });
        if ( reconciliation.ready !== true ) {
            throw new Error(
                reconciliation.error ||
                'Interrupted settings rollback did not reconcile'
            );
        }
        transaction = await sendMessage({ what: 'beginSettingsRestore' });
    }
    if ( typeof transaction?.id !== 'string' || transaction.id === '' ) {
        throw new Error('Settings restore transaction response was invalid');
    }
    try {
        const enabledRulesets = await applyFromObject(
            targetConfig,
            transaction.id
        );
        let commit = await sendMessage({
            what: 'commitSettingsRestore',
            id: transaction.id,
            settingsRestoreId: transaction.id,
            enabledRulesets,
        });
        if ( commit?.foregroundReconciliationRequired === true ) {
            const reconciliation = await reconcileProtection({
                settingsRestoreId: commit.settingsRestoreId,
            });
            if ( reconciliation.ready !== true ) {
                throw new Error(
                    reconciliation.error ||
                    'Foreground settings restore did not reconcile'
                );
            }
            commit = reconciliation.committed === true
                ? { committed: true }
                : await sendMessage({
                    what: 'commitSettingsRestore',
                    id: transaction.id,
                    settingsRestoreId: transaction.id,
                    enabledRulesets,
                });
        }
        if ( commit?.committed !== true ) {
            throw new Error('Settings restore commit response was invalid');
        }
    } catch(reason) {
        try {
            let rollback = await sendMessage({
                what: 'rollbackSettingsRestore',
                id: transaction.id,
                settingsRestoreId: transaction.id,
            });
            if ( rollback?.foregroundReconciliationRequired === true ) {
                const reconciliation = await reconcileProtection({
                    settingsRestoreId: rollback.settingsRestoreId,
                });
                if ( reconciliation.ready !== true ) {
                    throw new Error(
                        reconciliation.error ||
                        'Foreground settings rollback did not reconcile'
                    );
                }
                // The finalizer auto-completes a rollingBack journal. Only
                // resend when it reports that no rollback was completed; the
                // same ID then preserves the transaction boundary.
                if ( reconciliation.rolledBack === true ) {
                    rollback = { rolledBack: true };
                } else {
                    rollback = await sendMessage({
                        what: 'rollbackSettingsRestore',
                        id: transaction.id,
                        settingsRestoreId: transaction.id,
                    });
                }
            }
            if ( rollback?.rolledBack !== true ) {
                throw new Error('Settings rollback response was invalid');
            }
            const readiness = await sendMessage({ what: 'floorpReadiness' });
            if ( readiness?.ready !== true ) {
                throw new Error(
                    readiness?.error || 'Settings rollback did not become ready'
                );
            }
        } catch(rollbackReason) {
            throw new AggregateError(
                [ reason, rollbackReason ],
                'Settings restore and rollback both failed'
            );
        }
        throw reason;
    }
}
