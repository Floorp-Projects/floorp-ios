/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import {
    browser,
    runtime,
} from './ext.js';

/******************************************************************************/

// https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/manifest.json/host_permissions#requested_permissions_and_user_prompts
// "Users can grant or revoke host permissions on an ad hoc basis. Therefore,
// most browsers treat host_permissions as optional."

export async function hasBroadHostPermissions() {
    return browser.permissions.getAll().then(permissions =>
        permissions.origins.includes('<all_urls>') ||
        permissions.origins.includes('*://*/*')
    ).catch(( ) => false);
}

/******************************************************************************/

export async function gotoURL(url, type, windowId, incognito) {
    const pageURL = new URL(url, runtime.getURL('/'));
    const query = {
        url: pageURL.href,
        windowType: type !== 'popup' ? 'normal' : 'popup',
    };
    if ( Number.isInteger(windowId) ) {
        query.windowId = windowId;
    }
    const queriedTabs = await browser.tabs.query(query);
    const tabs = Array.isArray(queriedTabs)
        ? queriedTabs.filter(tab =>
            typeof incognito !== 'boolean' || tab.incognito === incognito
        )
        : [];

    if ( tabs.length !== 0 ) {
        const { windowId: reusedWindowId, id } = tabs[0];
        await browser.tabs.update(id, { active: true });
        return { reused: true, tabId: id, windowId: reusedWindowId };
    }

    if ( type === 'popup' ) {
        const createdWindow = await browser.windows.create({
            type: 'popup',
            url: pageURL.href,
        });
        return { reused: false, windowId: createdWindow?.id };
    }

    if ( incognito === true && Number.isInteger(windowId) === false ) {
        throw new Error('Private tab creation requires a numeric source window ID');
    }
    const createdTab = await browser.tabs.create({
        active: true,
        url: pageURL.href,
        ...(Number.isInteger(windowId) ? { windowId } : {}),
    });
    if ( typeof incognito === 'boolean' && createdTab?.incognito !== incognito ) {
        throw new Error('Created tab privacy realm does not match the source tab');
    }
    return {
        reused: false,
        tabId: createdTab?.id,
        windowId: createdTab?.windowId,
    };
}
