/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

// WebKit 7622.1.22 accepts requestDomains next to regexFilter but omits the
// request-domain constraint when compiling the rule. Keep only audited rules
// whose complete, ID-independent source fingerprint is known. The expansion
// rules replace one host-language fragment with literal members of the
// original requestDomains set, so every generated regex is a strict subset of
// the source regex and cannot broaden blocking.

const textEncoder = new TextEncoder();

function canonicalJSON(value) {
    if ( Array.isArray(value) ) {
        return `[${value.map(canonicalJSON).join(',')}]`;
    }
    if ( value !== null && typeof value === 'object' ) {
        const entries = Object.keys(value).sort().map(key =>
            `${JSON.stringify(key)}:${canonicalJSON(value[key])}`
        );
        return `{${entries.join(',')}}`;
    }
    return JSON.stringify(value);
}

export async function fingerprintSafariRegexRule(rule) {
    const sourceRule = {};
    for ( const [ key, value ] of Object.entries(rule) ) {
        if ( key === 'id' ) { continue; }
        sourceRule[key] = value;
    }
    const subtle = globalThis.crypto?.subtle;
    if ( subtle === undefined ) {
        throw new Error('SHA-256 is unavailable for Safari regex rule validation');
    }
    const digest = await subtle.digest(
        'SHA-256',
        textEncoder.encode(canonicalJSON(sourceRule))
    );
    return Array.from(new Uint8Array(digest), byte =>
        byte.toString(16).padStart(2, '0')
    ).join('');
}

const exactRuleActions = new Map([
    [
        '132d68188f125457e5f9d6a29cd77bfa5c861f72eb5067bc35ef097ee3e15ed4',
        { type: 'removeRequestDomains' },
    ],
    [
        'a744442d047580734a5d8402478c111eed848aa7cd607ec216f1c0c024c12a9f',
        { type: 'removeRequestDomains' },
    ],
    [
        '33f951d5541d50a1c6a956386306f87a569697d82ae73332cbc9c5f96067e4b6',
        { type: 'removeRequestDomains' },
    ],
    [
        'e038ecfbf910e608d79990fe3da2d595709108836fb6422ac2f794c87fb7d05f',
        { type: 'removeRequestDomains' },
    ],
    [
        'c79ad4f2f5e8bec4f53bd70615a0bc684dfba227289353208d9ea1fcc1d57fad',
        {
            type: 'expandRequestDomains',
            hostFragment: '\\.[ci][on]m?\\/',
        },
    ],
    [
        '5ec1d43216d4c29664f47b2542d529560824272ae538c8f159a831cd4a49eba3',
        {
            type: 'expandRequestDomains',
            hostFragment: '\\.[cipx][nory][fmoz]?o?\\/',
        },
    ],
    [
        'a487428483433000581edf1d3683383d09f877d5898b97f817161ec685eda097',
        {
            type: 'expandRequestDomains',
            hostFragment: '\\.[cins][cehlo][imotu][cp]?k?\\/',
        },
    ],
    [
        '33888c98ea9d39f3b78e8f5dc59399dd7f70017255997f7ad89003397d382c3e',
        {
            type: 'expandRequestDomains',
            hostFragment: '\\.[a-z]+\\/',
        },
    ],
    [
        '9ff7f8e963f67cbb24d522870a4e9159fc862dc025417a9a588e4b1c37156ddf',
        {
            type: 'expandRequestDomains',
            hostFragment: '\\.[cr][ef][ds]t?\\/',
        },
    ],
    [
        '621123575633254bd0f40ab1f29ef058599268d05d4151f22106cde68cd14188',
        {
            type: 'expandRequestDomains',
            hostFragment: '\\.[cr][ef][ds]t?\\/',
        },
    ],
]);

function escapedDomainFragment(domain) {
    return `\\.${domain.replaceAll('.', '\\.')}\\/`;
}

/**
 * Return rules safe to submit to WebKit. Unknown request-domain conditions on
 * regex rules are deliberately omitted, and source objects are never modified.
 * IDs are excluded from the whitelist fingerprint because the ruleset manager
 * assigns dynamic IDs only after this normalization.
 */
export async function normalizeSafariRegexRequestDomains(
    rules,
    rejectedRules = []
) {
    const output = [];
    for ( const rule of rules ) {
        const { condition } = rule;
        const excludedRequestDomains = condition?.excludedRequestDomains;
        const hasUnsafeExcludedRequestDomains =
            excludedRequestDomains !== undefined &&
            (
                Array.isArray(excludedRequestDomains) === false ||
                excludedRequestDomains.length !== 0
            );
        if (
            condition?.regexFilter === undefined ||
            (
                condition.requestDomains === undefined &&
                hasUnsafeExcludedRequestDomains === false
            )
        ) {
            output.push(rule);
            continue;
        }

        // WebKit's generated ignore-following rule for excludedRequestDomains
        // uses an unanchored bare-domain urlFilter. It is not an exact request
        // hostname exclusion and can suppress unrelated blocking rules.
        if ( hasUnsafeExcludedRequestDomains ) {
            rejectedRules.push(rule);
            continue;
        }

        const fingerprint = await fingerprintSafariRegexRule(rule);
        const action = exactRuleActions.get(fingerprint);
        if ( action === undefined ) {
            rejectedRules.push(rule);
            continue;
        }

        const normalized = structuredClone(rule);
        if ( action.type === 'removeRequestDomains' ) {
            delete normalized.condition.requestDomains;
            output.push(normalized);
            continue;
        }

        const { regexFilter, requestDomains } = normalized.condition;
        if (
            regexFilter.split(action.hostFragment).length !== 2 ||
            Array.isArray(requestDomains) === false ||
            requestDomains.length === 0
        ) {
            rejectedRules.push(rule);
            continue;
        }
        for ( const domain of requestDomains ) {
            const expanded = structuredClone(normalized);
            expanded.condition.regexFilter = regexFilter.replace(
                action.hostFragment,
                escapedDomainFragment(domain)
            );
            delete expanded.condition.requestDomains;
            output.push(expanded);
        }
    }
    return output;
}

/******************************************************************************/
