/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/******************************************************************************/

const supportedActionTypes = new Set([
    'allow',
    'allowAllRequests',
    'block',
    'redirect',
    'upgradeScheme',
]);

const supportedConditionKeys = new Set([
    'domainType',
    'excludedInitiatorDomains',
    'excludedRequestDomains',
    'excludedRequestMethods',
    'excludedResourceTypes',
    'initiatorDomains',
    'isUrlFilterCaseSensitive',
    'regexFilter',
    'requestDomains',
    'requestMethods',
    'resourceTypes',
    'urlFilter',
]);

const supportedResourceTypes = new Set([
    'font',
    'image',
    'main_frame',
    'media',
    'other',
    'ping',
    'script',
    'stylesheet',
    'sub_frame',
    'websocket',
    'xmlhttprequest',
]);

const supportedRequestMethods = new Set([
    'connect',
    'delete',
    'get',
    'head',
    'options',
    'patch',
    'post',
    'put',
    'trace',
]);

const unsupportedIncludedConditionKeys = new Set([
    'requestHeaders',
    'responseHeaders',
    'tabIds',
    'topDomains',
]);

const unsupportedExcludedConditionKeys = new Set([
    'excludedRequestHeaders',
    'excludedResponseHeaders',
    'excludedTabIds',
    'excludedTopDomains',
]);

const includedDomainKeys = [
    'initiatorDomains',
    'requestDomains',
];

const excludedDomainKeys = [
    'excludedInitiatorDomains',
    'excludedRequestDomains',
];

const isRecord = value =>
    typeof value === 'object' && value !== null && Array.isArray(value) === false;

const owns = (object, key) =>
    Object.prototype.hasOwnProperty.call(object, key);

const sameArray = (a, b) =>
    Array.isArray(a) && Array.isArray(b) &&
    a.length === b.length && a.every((value, i) => value === b[i]);

function canonicalizeLegacyDomains(condition) {
    for ( const [ legacyKey, standardKey ] of [
        [ 'domains', 'initiatorDomains' ],
        [ 'excludedDomains', 'excludedInitiatorDomains' ],
    ] ) {
        if ( owns(condition, legacyKey) === false ) { continue; }
        if (
            owns(condition, standardKey) &&
            sameArray(condition[legacyKey], condition[standardKey]) === false
        ) {
            return `${legacyKey} conflicts with ${standardKey}`;
        }
        condition[standardKey] = condition[legacyKey];
        delete condition[legacyKey];
    }
}

function normalizeDomainArrays(condition) {
    for ( const key of includedDomainKeys ) {
        if ( owns(condition, key) === false ) { continue; }
        const values = condition[key];
        if (
            Array.isArray(values) === false ||
            values.length === 0 ||
            values.some(value =>
                typeof value !== 'string' ||
                value === '' ||
                /^[\x00-\x7F]*$/.test(value) === false
            )
        ) {
            return `${key} is invalid`;
        }
    }
    for ( const key of excludedDomainKeys ) {
        if ( owns(condition, key) === false ) { continue; }
        const values = condition[key];
        if ( Array.isArray(values) === false ) {
            return `${key} is invalid`;
        }
        if ( values.length === 0 ) {
            delete condition[key];
            continue;
        }
        if ( values.some(value =>
            typeof value !== 'string' ||
            value === '' ||
            /^[\x00-\x7F]*$/.test(value) === false
        ) ) {
            return `${key} is invalid`;
        }
    }
}

function normalizeIncludedEnumArray(condition, key, supportedValues) {
    if ( owns(condition, key) === false ) { return; }
    const before = condition[key];
    if ( Array.isArray(before) === false || before.length === 0 ) {
        return `${key} is invalid`;
    }
    const after = before.filter(value => supportedValues.has(value));
    if ( after.length === 0 ) {
        return `${key} has no Safari-supported values`;
    }
    condition[key] = after;
}

function normalizeExcludedEnumArray(condition, key, supportedValues) {
    if ( owns(condition, key) === false ) { return; }
    const values = condition[key];
    if ( Array.isArray(values) === false ) { return `${key} is invalid`; }
    if ( values.length === 0 ) {
        delete condition[key];
        return;
    }
    // Removing an excluded value broadens the rule. Unlike included arrays,
    // the only safe normalization is therefore an empty no-op deletion.
    if ( values.some(value => supportedValues.has(value) === false) ) {
        return `${key} contains values unsupported by Safari`;
    }
}

function normalizeAction(rule) {
    const { action } = rule;
    if ( isRecord(action) === false ) { return 'action is invalid'; }
    if ( supportedActionTypes.has(action.type) === false ) {
        return `action ${action.type || '(missing)'} is unsupported`;
    }
    if (
        owns(action, 'requestHeaders') ||
        owns(action, 'responseHeaders')
    ) {
        return 'header modification actions are unsupported';
    }
    const allowedKeys = action.type === 'redirect'
        ? new Set([ 'type', 'redirect' ])
        : new Set([ 'type' ]);
    if ( Object.keys(action).some(key => allowedKeys.has(key) === false) ) {
        return 'action contains unsupported fields';
    }
    if ( action.type === 'redirect' && isRecord(action.redirect) === false ) {
        return 'redirect action is invalid';
    }
}

function normalizeCondition(rule) {
    const { condition } = rule;
    if ( isRecord(condition) === false ) { return 'condition is invalid'; }

    const legacyError = canonicalizeLegacyDomains(condition);
    if ( legacyError !== undefined ) { return legacyError; }

    // Safari 26 has no equivalent for these constraints. An empty exclusion
    // is a no-op and can be removed; every other case must fail closed.
    for ( const key of Object.keys(condition) ) {
        if ( supportedConditionKeys.has(key) ) { continue; }
        if ( unsupportedIncludedConditionKeys.has(key) ) {
            return `${key} is unsupported`;
        }
        if ( unsupportedExcludedConditionKeys.has(key) ) {
            if ( Array.isArray(condition[key]) && condition[key].length === 0 ) {
                delete condition[key];
                continue;
            }
            return `${key} is unsupported`;
        }
        return `${key} is unsupported`;
    }

    if (
        owns(condition, 'urlFilter') &&
        typeof condition.urlFilter !== 'string'
    ) {
        return 'urlFilter is invalid';
    }
    if (
        owns(condition, 'regexFilter') &&
        (
            typeof condition.regexFilter !== 'string' ||
            condition.regexFilter === ''
        )
    ) {
        return 'regexFilter is invalid';
    }
    if ( owns(condition, 'urlFilter') && owns(condition, 'regexFilter') ) {
        return 'urlFilter and regexFilter are mutually exclusive';
    }
    for ( const key of [ 'urlFilter', 'regexFilter' ] ) {
        if (
            typeof condition[key] === 'string' &&
            /^[\x00-\x7F]*$/.test(condition[key]) === false
        ) {
            return `${key} is not ASCII`;
        }
    }
    if (
        owns(condition, 'isUrlFilterCaseSensitive') &&
        typeof condition.isUrlFilterCaseSensitive !== 'boolean'
    ) {
        return 'isUrlFilterCaseSensitive is invalid';
    }
    if (
        owns(condition, 'domainType') &&
        [ 'firstParty', 'thirdParty' ].includes(condition.domainType) === false
    ) {
        return 'domainType is invalid';
    }

    const domainError = normalizeDomainArrays(condition);
    if ( domainError !== undefined ) { return domainError; }

    if (
        owns(condition, 'resourceTypes') &&
        owns(condition, 'excludedResourceTypes')
    ) {
        return 'resourceTypes and excludedResourceTypes are mutually exclusive';
    }
    for ( const [ key, values, excluded ] of [
        [ 'resourceTypes', supportedResourceTypes, false ],
        [ 'excludedResourceTypes', supportedResourceTypes, true ],
        [ 'requestMethods', supportedRequestMethods, false ],
        [ 'excludedRequestMethods', supportedRequestMethods, true ],
    ] ) {
        const error = excluded
            ? normalizeExcludedEnumArray(condition, key, values)
            : normalizeIncludedEnumArray(condition, key, values);
        if ( error !== undefined ) { return error; }
    }

    if (
        owns(condition, 'regexFilter') &&
        (
            owns(condition, 'requestDomains') ||
            owns(condition, 'excludedRequestDomains')
        )
    ) {
        return 'regexFilter with request-domain conditions is unsupported';
    }

    if ( rule.action.type === 'allowAllRequests' ) {
        for ( const key of [
            'domainType',
            'requestDomains',
            'excludedRequestDomains',
            'initiatorDomains',
            'excludedInitiatorDomains',
            'requestMethods',
            'excludedRequestMethods',
        ] ) {
            if ( owns(condition, key) ) {
                return `allowAllRequests with ${key} is unsupported`;
            }
        }
        if ( condition.isUrlFilterCaseSensitive === false ) {
            delete condition.isUrlFilterCaseSensitive;
        } else if ( owns(condition, 'isUrlFilterCaseSensitive') ) {
            return 'case-sensitive allowAllRequests is unsupported';
        }
        if (
            sameArray(condition.resourceTypes, [ 'main_frame' ]) === false
        ) {
            return 'allowAllRequests supports only main_frame';
        }
    }

    if (
        rule.action.type === 'redirect' &&
        owns(rule.action.redirect, 'regexSubstitution') &&
        owns(condition, 'regexFilter') === false
    ) {
        return 'regexSubstitution requires regexFilter';
    }
}

/**
 * Clone and canonicalize rules into the exact subset that Safari 26 can
 * represent. Rejected rules are omitted so ignored constraints never broaden
 * matching, and callers can build desired state from the same objects sent to
 * WebKit.
 */
export function normalizeSafariDNRRules(rules, rejectedRules = []) {
    if ( Array.isArray(rules) === false ) { return; }
    const out = [];
    for ( const sourceRule of rules ) {
        if ( isRecord(sourceRule) === false ) {
            rejectedRules.push({ rule: sourceRule, reason: 'rule is invalid' });
            continue;
        }
        const rule = structuredClone(sourceRule);
        const reason = normalizeAction(rule) || normalizeCondition(rule);
        if ( reason !== undefined ) {
            rejectedRules.push({ rule: sourceRule, reason });
            continue;
        }
        out.push(rule);
    }
    return out;
}

/******************************************************************************/
