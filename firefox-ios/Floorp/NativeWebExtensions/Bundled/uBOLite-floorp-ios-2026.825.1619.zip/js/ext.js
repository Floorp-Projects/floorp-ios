/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import {
    runStorageOperation,
    safariLocalStorageSentinelKey,
    webext,
} from './ext-compat.js';

/******************************************************************************/

export const browser = webext;
export const i18n = browser.i18n;
export const runtime = browser.runtime;

export const webextFlavor = (( ) => {
    const extURL = runtime.getURL('');
    if ( extURL.startsWith('safari-web-extension:') ) { return 'safari'; }
    return extURL.startsWith('moz-extension:') ? 'firefox' : 'chromium';
})();

const notAnObject = a => typeof a !== 'object' || a === null;

export function supportsUserScripts() {
    try { browser.userScripts.getScripts(); }
    catch { return false; }
    return true;
}

/******************************************************************************/

// Safari may resolve a message whose async background listener rejected with
// an explicit `{ error }` object. Treat that exactly like a rejected message:
// callers must not interpret the object as a successful scalar/config result.

export function assertSuccessfulMessageResponse(response) {
    if (
        response instanceof Object &&
        typeof response.error === 'string' &&
        response.error !== ''
    ) {
        const reason = new Error(response.error);
        reason.response = response;
        throw reason;
    }
    return response;
}

const pendingOptionsOperations = new Set();
let pendingOptionsOperationError;

export function trackOptionsOperation(operation) {
    const promise = Promise.resolve(operation);
    pendingOptionsOperations.add(promise);
    promise.then(
        ( ) => pendingOptionsOperations.delete(promise),
        reason => {
            pendingOptionsOperations.delete(promise);
            pendingOptionsOperationError ??= reason;
        }
    );
    return promise;
}

export async function settleOptionsOperations() {
    for (;;) {
        const pending = Array.from(pendingOptionsOperations);
        if ( pending.length === 0 ) { break; }
        await Promise.allSettled(pending);
    }
    const reason = pendingOptionsOperationError;
    pendingOptionsOperationError = undefined;
    if ( reason === undefined ) { return { ready: true }; }
    const error = reason instanceof Error ? reason.message : `${reason}`;
    return { ready: false, error };
}

export function sendMessage(msg) {
    const operation = (async ( ) => {
        try {
            const response = await runtime.sendMessage(msg);
            return assertSuccessfulMessageResponse(response);
        } catch(reason) {
            console.error(reason);
            throw reason;
        }
    })();
    return trackOptionsOperation(operation);
}

/******************************************************************************/

export async function localRead(key) {
    if ( notAnObject(browser?.storage?.local) ) { return; }
    try {
        const bin = await runStorageOperation('local', ( ) =>
            browser.storage.local.get(key)
        );
        if ( notAnObject(bin) ) { return; }
        return bin[key] ?? undefined;
    } catch(reason) {
        if ( webextFlavor === 'safari' ) { throw reason; }
    }
}

export async function localWrite(key, value) {
    if ( notAnObject(browser?.storage?.local) ) { return; }
    return runStorageOperation('local', ( ) =>
        browser.storage.local.set({ [key]: value })
    );
}

export async function localRemove(keys) {
    if ( notAnObject(browser?.storage?.local) ) { return; }
    return runStorageOperation('local', ( ) =>
        browser.storage.local.remove(keys)
    );
}

export async function localKeys() {
    if ( notAnObject(browser?.storage?.local) ) { return; }
    if ( browser.storage.local.getKeys ) {
        const keys = await runStorageOperation('local', ( ) =>
            browser.storage.local.getKeys()
        );
        return keys.filter(key => key !== safariLocalStorageSentinelKey);
    }
    const bin = await runStorageOperation('local', ( ) =>
        browser.storage.local.get(null)
    );
    if ( notAnObject(bin) ) { return; }
    return Object.keys(bin).filter(
        key => key !== safariLocalStorageSentinelKey
    );
}

export async function localSnapshot(excludedKeys = []) {
    if ( notAnObject(browser?.storage?.local) ) { return {}; }
    const bin = await runStorageOperation('local', ( ) =>
        browser.storage.local.get(null)
    );
    if ( notAnObject(bin) ) { return {}; }
    const excluded = new Set([
        safariLocalStorageSentinelKey,
        ...excludedKeys,
    ]);
    return Object.fromEntries(
        Object.entries(bin).filter(([ key ]) => excluded.has(key) === false)
    );
}

export async function localReplace(snapshot, preservedKeys = []) {
    if ( notAnObject(browser?.storage?.local) ) { return; }
    if ( notAnObject(snapshot) ) {
        throw new Error('Invalid local-storage snapshot');
    }
    const preserved = new Set([
        safariLocalStorageSentinelKey,
        ...preservedKeys,
    ]);
    return runStorageOperation('local', async ( ) => {
        const current = await browser.storage.local.get(null);
        const replacement = Object.fromEntries(
            Object.entries(snapshot).filter(([ key ]) => preserved.has(key) === false)
        );
        const removeKeys = Object.keys(current).filter(key =>
            preserved.has(key) === false &&
            Object.prototype.hasOwnProperty.call(replacement, key) === false
        );
        if ( removeKeys.length !== 0 ) {
            await browser.storage.local.remove(removeKeys);
        }
        if ( Object.keys(replacement).length !== 0 ) {
            await browser.storage.local.set(replacement);
        }
    });
}

/******************************************************************************/

export async function sessionRead(key) {
    if ( notAnObject(browser?.storage?.session) ) { return; }
    try {
        const bin = await runStorageOperation('session', ( ) =>
            browser.storage.session.get(key)
        );
        if ( notAnObject(bin) ) { return; }
        return bin[key] ?? undefined;
    } catch(reason) {
        if ( webextFlavor === 'safari' ) { throw reason; }
    }
}

export async function sessionWrite(key, value) {
    if ( notAnObject(browser?.storage?.session) ) { return; }
    return runStorageOperation('session', ( ) =>
        browser.storage.session.set({ [key]: value })
    );
}

export async function sessionRemove(keys) {
    if ( notAnObject(browser?.storage?.session) ) { return; }
    return runStorageOperation('session', ( ) =>
        browser.storage.session.remove(keys)
    );
}

export async function sessionClear() {
    if ( notAnObject(browser?.storage?.session) ) { return; }
    return runStorageOperation('session', ( ) =>
        browser.storage.session.clear()
    );
}

export async function sessionKeys() {
    if ( notAnObject(browser?.storage?.session) ) { return; }
    if ( browser.storage.session.getKeys ) {
        return runStorageOperation('session', ( ) =>
            browser.storage.session.getKeys()
        );
    }
    const bin = await runStorageOperation('session', ( ) =>
        browser.storage.session.get(null)
    );
    if ( notAnObject(bin) ) { return; }
    return Object.keys(bin);
}

export async function sessionAccessLevel(level) {
    try {
        return await runStorageOperation('session', ( ) =>
            browser.storage.session.setAccessLevel(level)
        );
    } catch(reason) {
        if ( webextFlavor === 'safari' ) { throw reason; }
    }
    
}

/******************************************************************************/

export async function adminRead(key) {
    if ( browser?.storage?.managed instanceof Object === false ) { return; }
    try {
        const bin = await browser.storage.managed.get(key);
        if ( notAnObject(bin) ) { return; }
        return bin[key] ?? undefined;
    } catch {
    }
}

/******************************************************************************/
