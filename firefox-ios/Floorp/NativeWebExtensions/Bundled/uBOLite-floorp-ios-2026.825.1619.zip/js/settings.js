/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2014-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import {
    assertSuccessfulMessageResponse,
    browser,
    i18n,
    recordOptionsOperationError,
    sendMessage,
    trackOptionsOperation,
} from './ext.js';
import { dom, qs$ } from './dom.js';
import { hashFromIterable } from './dashboard.js';
import { renderFilterLists } from './filter-lists.js';

/******************************************************************************/

function renderAdminRules() {
    const { disabledFeatures: forbid = [] } = self.cachedRulesetData;
    if ( forbid.length === 0 ) { return; }
    dom.body.dataset.forbid = forbid.join(' ');
    if ( forbid.includes('dashboard') ) {
        dom.body.dataset.pane = 'about';
    }
}

function runtimeErrorText(reason) {
    return reason instanceof Error ? reason.message : `${reason}`;
}

function showRuntimeError(reason) {
    dom.text('#runtimeError', runtimeErrorText(reason));
}

function clearRuntimeError() {
    dom.text('#runtimeError', '');
}

/******************************************************************************/

function renderWidgets() {
    const data = self.cachedRulesetData;
    if ( data.firstRun ) {
        dom.cl.add(dom.body, 'firstRun');
    }

    renderDefaultMode();

    qs$('#autoReload input[type="checkbox"]').checked = data.autoReload;

    {
        const input = qs$('#showBlockedCount input[type="checkbox"]');
        if ( data.canShowBlockedCount ) {
            input.checked = data.showBlockedCount;
        } else {
            input.checked = false;
            dom.attr(input, 'disabled', '');
        }
    }

    {
        const input = qs$('#strictBlockMode input[type="checkbox"]');
        const canStrictBlock = data.hasOmnipotence;
        input.checked = canStrictBlock && data.strictBlockMode;
        dom.attr(input, 'disabled', canStrictBlock ? null : '');
    }

    {
        const input = qs$('#popupBlockMode input[type="checkbox"]');
        input.checked = data.popupBlockMode;
    }

    {
        const state = Boolean(data.developerMode) &&
            data.disabledFeatures?.includes('develop') !== true;
        dom.body.dataset.develop = `${state}`;
        dom.prop('#developerMode input[type="checkbox"]', 'checked', state);
    }
}

/******************************************************************************/

function renderDefaultMode() {
    const defaultLevel = self.cachedRulesetData.defaultFilteringMode;
    if ( defaultLevel !== 0 ) {
        qs$(`.filteringModeCard input[type="radio"][value="${defaultLevel}"]`).checked = true;
    } else {
        dom.prop('.filteringModeCard input[type="radio"]', 'checked', false);
    }
}

/******************************************************************************/

export async function onFilteringModeChange(ev, messageSender = sendMessage) {
    const input = ev.target;
    const newLevel = parseInt(input.value, 10);
    const data = self.cachedRulesetData;
    const previousLevel = data.defaultFilteringMode;
    let succeeded = false;
    clearRuntimeError();

    try {
        switch ( newLevel ) {
        case 1: {
            const actualLevel = assertSuccessfulMessageResponse(
                await messageSender({
                    what: 'setDefaultFilteringMode',
                    level: newLevel,
                })
            );
            if ( Number.isInteger(actualLevel) === false ) {
                throw new Error('Invalid filtering-mode response');
            }
            data.defaultFilteringMode = actualLevel;
            succeeded = true;
            break;
        }
        case 2:
        case 3: {
            const granted = await browser.permissions.request({
                origins: [ '<all_urls>' ],
            });
            if ( granted ) {
                const actualLevel = assertSuccessfulMessageResponse(
                    await messageSender({
                        what: 'setDefaultFilteringMode',
                        level: newLevel,
                    })
                );
                if ( Number.isInteger(actualLevel) === false ) {
                    throw new Error('Invalid filtering-mode response');
                }
                data.defaultFilteringMode = actualLevel;
                data.hasOmnipotence = true;
                succeeded = true;
            }
            break;
        }
        default:
            break;
        }
    } catch(reason) {
        data.defaultFilteringMode = previousLevel;
        showRuntimeError(reason);
    } finally {
        renderWidgets();
    }
    return succeeded;
}

dom.on('#defaultFilteringMode',
    'change',
    '.filteringModeCard input[type="radio"]',
    ev => { trackOptionsOperation(onFilteringModeChange(ev)); }
);

/******************************************************************************/

async function backupSettings() {
    const api = await import('./backup-restore.js');
    const data = await api.backupToObject(self.cachedRulesetData);
    if ( data instanceof Object === false ) { return; }
    const json = JSON.stringify(data, null, 2)  + '\n';
    const a = document.createElement('a');
    a.href = `data:text/plain;charset=utf-8,${encodeURIComponent(json)}`;
    dom.attr(a, 'download', 'my-ubol-settings.json');
    dom.attr(a, 'type', 'application/json');
    a.click();
}

export async function restoreSettingsFromObject(
    targetConfig,
    restore = async config => {
        const api = await import('./backup-restore.js');
        return api.restoreFromObject(config);
    }
) {
    clearRuntimeError();
    dom.cl.add(dom.body, 'busy');
    try {
        await restore(targetConfig);
        Object.assign(
            self.cachedRulesetData,
            await sendMessage({ what: 'getOptionsPageData' })
        );
        renderWidgets();
        await renderFilterLists(true);
        return true;
    } catch(reason) {
        // This public helper deliberately returns a boolean for dashboard UI
        // callers. Preserve the rejected operation for Floorp's close
        // handshake even though the outer tracked promise resolves `false`.
        recordOptionsOperationError(reason);
        showRuntimeError(reason);
        try {
            Object.assign(
                self.cachedRulesetData,
                await sendMessage({ what: 'getOptionsPageData' })
            );
            renderWidgets();
            await renderFilterLists(true);
        } catch {
        }
        return false;
    } finally {
        dom.cl.remove(dom.body, 'busy');
    }
}

async function restoreSettings() {
    const targetConfig = await new Promise(resolve => {
        const input = qs$('section[data-pane="settings"] input[type="file"]');
        input.onchange = ev => {
            input.onchange = null;
            const file = ev.target.files[0];
            if ( file === undefined || file.name === '' ) { return resolve(); }
            const fr = new FileReader();
            fr.onload = ( ) => {
                fr.onload = null;
                if ( typeof fr.result !== 'string' ) { return resolve(); }
                let data;
                try {
                    data = JSON.parse(fr.result);
                } catch {
                }
                if ( data instanceof Object === false ) { return resolve(); }
                resolve(data);
            };
            fr.readAsText(file);
        };
        input.oncancel = ( ) => {
            resolve();
        };
        // Reset to empty string, this will ensure a change event is properly
        // triggered if the user pick a file, even if it's the same as the last
        // one picked.
        input.value = '';
        input.click();
    });
    if ( targetConfig instanceof Object === false ) { return false; }
    return restoreSettingsFromObject(targetConfig);
}

async function resetSettings() {
    const response = self.confirm(i18n.getMessage('resetToDefaultConfirm'));
    if ( response !== true ) { return; }
    return restoreSettingsFromObject({});
}

/******************************************************************************/

async function commitBooleanSetting(ev, property, what) {
    const input = ev.target;
    const data = self.cachedRulesetData;
    const before = Boolean(data[property]);
    const after = input.checked;
    clearRuntimeError();
    try {
        await sendMessage({ what, state: after });
        data[property] = after;
        return true;
    } catch(reason) {
        input.checked = before;
        showRuntimeError(reason);
        return false;
    }
}

dom.on('#autoReload input[type="checkbox"]', 'change', ev => {
    trackOptionsOperation(commitBooleanSetting(ev, 'autoReload', 'setAutoReload'));
});

dom.on('#showBlockedCount input[type="checkbox"]', 'change', ev => {
    trackOptionsOperation(commitBooleanSetting(ev, 'showBlockedCount', 'setShowBlockedCount'));
});

dom.on('#strictBlockMode input[type="checkbox"]', 'change', ev => {
    trackOptionsOperation(commitBooleanSetting(ev, 'strictBlockMode', 'setStrictBlockMode'));
});

dom.on('#popupBlockMode input[type="checkbox"]', 'change', ev => {
    trackOptionsOperation(commitBooleanSetting(ev, 'popupBlockMode', 'setPopupBlockMode'));
});

dom.on('#developerMode input[type="checkbox"]', 'change', ev => {
    const state = ev.target.checked;
    const operation = commitBooleanSetting(ev, 'developerMode', 'setDeveloperMode').then(succeeded => {
        if ( succeeded ) {
            dom.body.dataset.develop = `${state}`;
        }
    });
    trackOptionsOperation(operation);
});

dom.on('section[data-pane="settings"] button:has([data-i18n="backupButton"])', 'click', ( ) => {
    backupSettings();
});

dom.on('section[data-pane="settings"] button:has([data-i18n="restoreButton"])', 'click', ( ) => {
    trackOptionsOperation(restoreSettings());
});

dom.on('section[data-pane="settings"] button:has([data-i18n="resetToDefaultButton"])', 'click', ( ) => {
    trackOptionsOperation(resetSettings());
});

/******************************************************************************/

function listen() {
    const bc = new self.BroadcastChannel('uBOL');
    bc.onmessage = listen.onmessage;
}

listen.onmessage = ev => {
    const message = ev.data;
    if ( message instanceof Object === false ) { return; }
    const local = self.cachedRulesetData;
    let render = false;
    let renderLists = false;

    if ( message.hasOmnipotence !== undefined ) {
        if ( message.hasOmnipotence !== local.hasOmnipotence ) {
            local.hasOmnipotence = message.hasOmnipotence;
            render = true;
        }
    }

    if ( message.defaultFilteringMode !== undefined ) {
        if ( message.defaultFilteringMode !== local.defaultFilteringMode ) {
            local.defaultFilteringMode = message.defaultFilteringMode;
            render = true;
        }
    }

    if ( message.autoReload !== undefined ) {
        if ( message.autoReload !== local.autoReload ) {
            local.autoReload = message.autoReload;
            render = true;
        }
    }

    if ( message.showBlockedCount !== undefined ) {
        if ( message.showBlockedCount !== local.showBlockedCount ) {
            local.showBlockedCount = message.showBlockedCount;
            render = true;
        }
    }

    if ( message.strictBlockMode !== undefined ) {
        if ( message.strictBlockMode !== local.strictBlockMode ) {
            local.strictBlockMode = message.strictBlockMode;
            render = true;
        }
    }

    if ( message.popupBlockMode !== undefined ) {
        if ( message.popupBlockMode !== local.popupBlockMode ) {
            local.popupBlockMode = message.popupBlockMode;
            render = true;
        }
    }

    if ( message.developerMode !== undefined ) {
        if ( message.developerMode !== local.developerMode ) {
            local.developerMode = message.developerMode;
            render = true;
        }
    }

    if ( message.adminRulesets !== undefined ) {
        if ( hashFromIterable(message.adminRulesets) !== hashFromIterable(local.adminRulesets) ) {
            local.adminRulesets = message.adminRulesets;
            renderLists = true;
        }
    }

    if ( message.enabledRulesets !== undefined ) {
        local.enabledRulesets = message.enabledRulesets;
        renderLists = true;
    }

    if ( render ) {
        renderWidgets();
    }
    if ( renderLists ) {
        renderFilterLists(true);
    }
};

/******************************************************************************/

self.cachedRulesetData = {};

sendMessage({
    what: 'getOptionsPageData',
}).then(data => {
    if ( !data ) { return; }
    self.cachedRulesetData = data;
    const supports = []
    if ( data.supportsUserScripts ) {
        supports.push('user-scripts');
    }
    if ( data.supportsCompiledFilters ) {
        supports.push('compiled-filters');
    }
    dom.body.dataset.supports = supports.join(' ');
    try {
        renderAdminRules();
        renderWidgets();
    } catch(reason) {
        console.error(reason);
    } finally {
        dom.cl.remove(dom.body, 'loading');
    }
    listen();
}).catch(reason => {
    console.error(reason);
    showRuntimeError(reason);
    dom.cl.remove(dom.body, 'loading');
});

/******************************************************************************/
