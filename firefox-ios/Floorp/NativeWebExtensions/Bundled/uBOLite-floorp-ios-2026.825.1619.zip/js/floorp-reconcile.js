/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Home: https://github.com/gorhill/uBlock
*/

import {
    assertSuccessfulMessageResponse,
    runtime,
} from './ext.js';

import {
    loadRulesetConfig,
    rulesetConfig,
    saveRulesetConfig,
} from './config.js';

import {
    enabledRulesetsMatch,
    enableRulesets,
    patchDefaultRulesets,
} from './ruleset-manager.js';

let reconciliationTail = Promise.resolve();

async function reconcileProtectionNow(options = {}) {
    await loadRulesetConfig();
    const version = runtime.getManifest().version;
    if ( rulesetConfig.version !== version ) {
        rulesetConfig.version = version;
        await patchDefaultRulesets();
    }
    if ( Array.isArray(options.enabledRulesets) ) {
        rulesetConfig.enabledRulesets = options.enabledRulesets.slice();
    }

    // Durable intent is committed before the WebKit static DNR mutation. If
    // this page is evicted at any later await, the next foreground probe sees
    // the same target and resumes the idempotent reconciliation.
    await saveRulesetConfig();
    const result = await enableRulesets(
        rulesetConfig.enabledRulesets,
        true,
        true
    );
    if ( result.error ) { throw new Error(result.error); }
    if ( result.foregroundReconciliationRequired ) {
        throw new Error('Foreground static ruleset reconciliation did not run');
    }
    if ( Array.isArray(result.enabledRulesets) === false ) {
        throw new Error('Enabled static ruleset readback was unavailable');
    }
    rulesetConfig.enabledRulesets = result.enabledRulesets;
    await saveRulesetConfig();
    if ( await enabledRulesetsMatch(rulesetConfig.enabledRulesets) === false ) {
        throw new Error('Foreground static ruleset readback mismatch');
    }

    const finalized = assertSuccessfulMessageResponse(
        await runtime.sendMessage({
            what: 'floorpFinalizeForegroundReconciliation',
        })
    );
    if ( finalized?.ready !== true ) {
        throw new Error(
            finalized?.error || 'Background protection reconciliation failed'
        );
    }
    return {
        ready: true,
        version,
        foregroundReconciliationRequired: false,
        rolledBack: finalized?.rolledBack === true,
    };
}

export function reconcileProtection(options = {}) {
    const operation = reconciliationTail
        .catch(( ) => undefined)
        .then(( ) => reconcileProtectionNow(options));
    reconciliationTail = operation.catch(( ) => undefined);
    return operation.catch(reason => ({
        ready: false,
        version: runtime.getManifest().version,
        foregroundReconciliationRequired: true,
        error: reason instanceof Error ? reason.message : `${reason}`,
    }));
}

globalThis.floorpReconcileProtection = reconcileProtection;
