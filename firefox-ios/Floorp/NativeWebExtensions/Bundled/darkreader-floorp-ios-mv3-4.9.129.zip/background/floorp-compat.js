/*
 * Floorp iOS compatibility primitives for Dark Reader.
 *
 * WKWebExtension can transiently fail otherwise valid storage calls with an
 * "unknown error" while its backing database is being opened.  Dark Reader's
 * upstream callback wrappers treat some of those failures as empty storage,
 * which can replace the user's settings with defaults.  Keep this shim small
 * and independent from Dark Reader internals so the upstream bundle remains
 * easy to audit and update.
 */
(() => {
    "use strict";

    const SENTINEL_KEY = "__floorp_darkreader_storage_ready_v1";
    const UNKNOWN_ERROR = /unknown error/i;
    const RETRY_DELAYS = [50, 100, 200, 400];

    function createFloorpDarkReaderCompat(
        webExtension,
        {
            setTimeoutFn = globalThis.setTimeout.bind(globalThis),
            clearTimeoutFn = globalThis.clearTimeout.bind(globalThis),
            retryDelays = RETRY_DELAYS
        } = {}
    ) {
        const handled = (promise) => {
            promise.catch(() => undefined);
            return promise;
        };
        const asError = (reason) => {
            if (reason instanceof Error) {
                return reason;
            }
            if (reason && typeof reason.message === "string") {
                return new Error(reason.message);
            }
            return new Error(String(reason));
        };
        const delay = (milliseconds) =>
            new Promise((resolve) => setTimeoutFn(resolve, milliseconds));

        async function retryUnknown(operation) {
            let attempt = 0;
            while (true) {
                try {
                    return await operation();
                } catch (reason) {
                    const error = asError(reason);
                    if (
                        !UNKNOWN_ERROR.test(error.message) ||
                        attempt >= retryDelays.length
                    ) {
                        throw error;
                    }
                    await delay(retryDelays[attempt++]);
                }
            }
        }

        function createRecoveringQueue() {
            let tail = Promise.resolve();
            let lastError = null;
            let revision = 0;

            const enqueue = (operation) => {
                revision++;
                const result = tail.then(operation);
                tail = result.then(
                    () => {
                        lastError = null;
                    },
                    (reason) => {
                        lastError = asError(reason);
                    }
                );
                return handled(result);
            };
            const drain = async () => {
                while (true) {
                    const observed = tail;
                    await observed;
                    if (observed === tail) {
                        return;
                    }
                }
            };
            const flush = async () => {
                await drain();
                if (lastError) {
                    throw lastError;
                }
            };

            return {
                enqueue,
                drain,
                flush,
                getLastError: () => lastError,
                getRevision: () => revision
            };
        }

        function createFlushableDebounce(milliseconds, operation) {
            const execution = createRecoveringQueue();
            let timer = null;
            let pending = null;

            const launch = () => {
                if (!pending) {
                    return null;
                }
                if (timer !== null) {
                    clearTimeoutFn(timer);
                    timer = null;
                }
                const batch = pending;
                pending = null;
                const result = execution.enqueue(() =>
                    operation(...batch.arguments)
                );
                result.then(
                    (value) =>
                        batch.waiters.forEach(({resolve}) => resolve(value)),
                    (reason) =>
                        batch.waiters.forEach(({reject}) => reject(reason))
                );
                return result;
            };
            const schedule = (...args) => {
                if (!pending) {
                    pending = {arguments: args, waiters: []};
                } else {
                    pending.arguments = args;
                }
                const result = new Promise((resolve, reject) => {
                    pending.waiters.push({resolve, reject});
                });
                if (timer !== null) {
                    clearTimeoutFn(timer);
                }
                timer = setTimeoutFn(launch, milliseconds);
                return handled(result);
            };
            schedule.flush = async () => {
                while (true) {
                    if (pending) {
                        launch();
                    }
                    try {
                        await execution.flush();
                    } catch (reason) {
                        if (pending) {
                            continue;
                        }
                        throw reason;
                    }
                    if (!pending) {
                        return;
                    }
                }
            };
            schedule.getLastError = execution.getLastError;
            schedule.getRevision = execution.getRevision;
            return schedule;
        }

        function invokeStorage(areaName, method, argument) {
            return new Promise((resolve, reject) => {
                const area = webExtension.storage?.[areaName];
                if (!area || typeof area[method] !== "function") {
                    reject(
                        new Error(
                            `Storage area ${areaName}.${method} is unavailable`
                        )
                    );
                    return;
                }
                try {
                    area[method](argument, (value) => {
                        const lastError = webExtension.runtime?.lastError;
                        if (lastError) {
                            reject(asError(lastError));
                            return;
                        }
                        resolve(value);
                    });
                } catch (reason) {
                    reject(asError(reason));
                }
            });
        }

        const storageQueues = new Map();
        let localSentinelReady = false;
        const getStorageQueue = (areaName) => {
            if (!storageQueues.has(areaName)) {
                storageQueues.set(areaName, createRecoveringQueue());
            }
            return storageQueues.get(areaName);
        };
        const ensureLocalSentinel = async () => {
            if (localSentinelReady) {
                return;
            }
            await retryUnknown(() =>
                invokeStorage("local", "set", {[SENTINEL_KEY]: true})
            );
            localSentinelReady = true;
        };
        const runStorage = (areaName, operation) =>
            getStorageQueue(areaName).enqueue(async () => {
                if (areaName === "local") {
                    await ensureLocalSentinel();
                }
                return await retryUnknown(operation);
            });
        const stripSentinel = (areaName, value) => {
            if (
                areaName !== "local" ||
                value === null ||
                typeof value !== "object" ||
                !(SENTINEL_KEY in value)
            ) {
                return value;
            }
            const copy = {...value};
            delete copy[SENTINEL_KEY];
            return copy;
        };
        const get = (areaName, keys) =>
            runStorage(areaName, async () =>
                stripSentinel(
                    areaName,
                    await invokeStorage(areaName, "get", keys)
                )
            );
        const set = (areaName, values) =>
            runStorage(areaName, () =>
                invokeStorage(areaName, "set", values)
            );
        const remove = (areaName, keys) =>
            runStorage(areaName, () =>
                invokeStorage(areaName, "remove", keys)
            );
        const flushStorage = async () => {
            while (true) {
                const queues = Array.from(storageQueues.values());
                const revisions = queues.map((queue) => queue.getRevision());
                await Promise.all(queues.map((queue) => queue.drain()));
                if (
                    queues.length === storageQueues.size &&
                    queues.every((queue, index) =>
                        queue.getRevision() === revisions[index]
                    )
                ) {
                    return;
                }
            }
        };
        const equal = (left, right) => {
            const normalize = (value) => {
                if (Array.isArray(value)) {
                    return value.map(normalize);
                }
                if (value && typeof value === "object") {
                    return Object.fromEntries(
                        Object.keys(value)
                            .sort()
                            .map((key) => [key, normalize(value[key])])
                    );
                }
                return value;
            };
            return (
                JSON.stringify(normalize(left)) ===
                JSON.stringify(normalize(right))
            );
        };

        return Object.freeze({
            sentinelKey: SENTINEL_KEY,
            get,
            set,
            remove,
            flushStorage,
            equal,
            retryUnknown,
            createRecoveringQueue,
            createFlushableDebounce
        });
    }

    globalThis.floorpCreateDarkReaderCompat = createFloorpDarkReaderCompat;
    globalThis.floorpDarkReaderCompat =
        createFloorpDarkReaderCompat(globalThis.chrome);
})();
